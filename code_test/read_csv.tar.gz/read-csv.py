# 读取示波器保存的数据，得到幅值
import csv
# with open('F0000CH1.CSV', newline='') as f_csv:
    # read_csv = csv.reader(f_csv, delimiter=',', quotechar=',')
    # for i, row in enumerate(read_csv):
        # if i == 10:break
        # print(row)

with open('F0000CH1.CSV') as f_csv:
    data=[]
    for i, row in enumerate(f_csv):
        s=row.split(',')
        try:
            data.append(float(s[-2]))
        except:
            print(i)
            break



import matplotlib.pyplot as plt
plt.plot(data)
plt.show()
