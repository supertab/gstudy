clear all;clc
I=imread('ԭͼ.jpg');
I=rgb2gray(I);
subplot(221);imshow(I);
I2=imnoise(I,'salt & pepper',0.2);
subplot(222);imshow(I2);
f=double(I2);
k=fft2(f);
g=fftshift(k);
[N1,N2]=size(g);
n=2;
d0=25;
u0=round(N1/2);
v0=round(N2/2);
for i=1:N1
    for j=1:N2
        d=sqrt((i-u0)^2+(j-v0)^2);
        h=1/(1+0.414*(d/d0)^(2*n));
        y(i,j)=h*g(i,j);
    end
end
y=ifftshift(y);
E1=ifft2(y);
E2=uint8(real(E1));
subplot(223);imshow(E2);