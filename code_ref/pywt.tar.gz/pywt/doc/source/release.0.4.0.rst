.. include:: ../release/0.4.0-notes.rst
