.. include:: ../release/1.0.0-notes.rst
