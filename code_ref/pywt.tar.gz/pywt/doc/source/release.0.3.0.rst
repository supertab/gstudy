.. include:: ../release/0.3.0-notes.rst
