.. include:: ../release/0.5.0-notes.rst
