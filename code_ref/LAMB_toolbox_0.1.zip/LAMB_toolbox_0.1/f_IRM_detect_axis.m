function [ax,ax_name] = f_IRM_detect_ax(x,y,z)
% Detect plotting ax for a given line.
% 
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    20/12/2008


 delta = 10^-8; % Level of variation detection in axis coords.

 [a b] = size(x);
if ((a == 1) && (b > 1)) || ((a > 1) && (b == 1))
    %---------------------------------------------------------------------------------------------------------------
    % Detection of lines
    if f_round(abs(mean(diff(x))),delta,0) && (~f_round(abs(mean(diff(y))),delta,0)) && (~f_round(abs(mean(diff(z))),delta,0))
        % X-line.
             ax = x;
        ax_name = 'X';
        ax_type = 1;
    elseif (~f_round(abs(mean(diff(x))),delta,0)) && f_round(abs(mean(diff(y))),delta,0) && (~f_round(abs(mean(diff(z))),delta,0))
        % Y-line.
             ax = y;
        ax_name = 'Y';
        ax_type = 2;
    elseif (~f_round(abs(mean(diff(x))),delta,0)) && (~f_round(abs(mean(diff(y))),delta,0)) && f_round(abs(mean(diff(z))),delta,0)
        % Z-line.
             ax = z;
        ax_name = 'Z';
        ax_type = 3;
    elseif (~f_round(abs(mean(diff(z))),delta,0))
        % X-Y line.
        if f_round(abs(mean(diff(x))),delta,0) >= f_round(abs(mean(diff(y))),delta,0)
            ax = x; % Major variation in X-ax.
       ax_name = 'Xy';
       ax_type = 4;
        else
            ax = y; % Major variation in Y-ax.
       ax_name = 'xY';
       ax_type = 5;
        end
    elseif (~f_round(abs(mean(diff(y))),delta,0))
        % X-Z line.
        if f_round(abs(mean(diff(x))),delta,0) >= f_round(abs(mean(diff(z))),delta,0)
            ax = x; % Major variation in X-ax.
       ax_name = 'Xz';
       ax_type = 6;
        else
            ax = z; % Major variation in Z-ax.
       ax_name = 'xZ';            
       ax_type = 7;
        end
    elseif (~f_round(abs(mean(diff(x))),delta,0))
        % Y-Z line.
        if f_round(abs(mean(diff(y))),delta,0) >= f_round(abs(mean(diff(z))),delta,0)
            ax = y; % Major variation in Y-ax.
       ax_name = 'Yz';
       ax_type = 8;
        else
            ax = z; % Major variation in Z-ax.
       ax_name = 'yZ';
       ax_type = 9;
        end
    else
        % X-Y-Z Space line.
        [m,ii] = max([abs(mean(diff(x))) abs(mean(diff(y))) abs(mean(diff(z)))])
        if ii == 1
            ax = x; % Major variation in X-ax.
       ax_name = 'Xyz';
       ax_type = 10;
        elseif ii == 2
            ax = y; % Major variation in Y-ax.
       ax_name = 'xYz';
       ax_type = 11;
        else
            ax = z; % Major variation in Z-ax.
       ax_name = 'xyZ';
       ax_type = 12;
        end
    end
    %---------------------------------------------------------------------------------------------------------------
else
    %---------------------------------------------------------------------------------------------------------------
    % Detection of planes.
    if (f_round(abs(mean(mean(diff(z)))),delta,0) == 0) && (f_round(abs(mean(mean(diff(z')))),delta,0) == 0)
        % X-Y plane.
        ax(:,:,1) = x;
        ax(:,:,2) = y;
        ax_name = ['X' 'Y'];
    elseif (f_round(abs(mean(mean(diff(y)))),delta,0) == 0) && (f_round(abs(mean(mean(diff(y')))),delta,0) == 0)
        % X-Z plane.
        ax(:,:,1) = x;
        ax(:,:,2) = z;
        ax_name = ['X' 'Z'];
    elseif (f_round(abs(mean(mean(diff(x)))),delta,0) == 0) && (f_round(abs(mean(mean(diff(x')))),delta,0) == 0)
        % Y-Z plane.
        ax(:,:,1) = y;
        ax(:,:,2) = z;
        ax_name = ['Y' 'Z'];
    else
        % Space oriented plane.        
        a = abs(mean(mean(diff(x)))); 
        b = abs(mean(mean(diff(y)))); 
        c = abs(mean(mean(diff(z)))); 
        [aa,ii] = sort([a b c]); % Detect max. variarion by ordering in ascending list.
            n = 1;
        for k = 3:-1:2
            if ii(k) == 1
                ax(:,:,n) = x;
                ax_name(n) = 'X';
            elseif ii(k) == 2
                ax(:,:,n) = y;
                ax_name(n) = 'Y';
            else
                ax(:,:,n) = z;
                ax_name(n) = 'Z';
            end
            n = n+1;
        end
        
    end
end