function [recta] = f_recta_P0_m(O_ref,Pk,m,dist)
% Funcion que calcula un segmento de recta que parte de un punto 'Pk', 
% tiene una pendiente dada 'm' y pasa x un punto auxiliar 'j' que dista 
% en: 'dist' unidades de 'Pk'.
% Obs,: formato de la esrecta:
%                             recta = [x1  y1
%                                     x2  y2]
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0      02/03/2004
% ver 2.0      11/01/2009     En pruebas x ahora...y posible vectorizacion.
% ver 2.1      22/02/2009     Reference origin 'O_ref' added.


% Reference points to given Origin 'O'
        Pk = Pk - O_ref;
       x_j = Pk(1) + dist/(sqrt(1+m^2));  % Coord. 'x'  del punto auxiliar j

         b = Pk(2) - m*Pk(1);             % Ordenada al origen
       y_j = m*x_j + b;
     recta = [Pk(1) Pk(2); x_j y_j];      % Puntos que definen la recta
     
recta(1,:) = recta(1,:) + O_ref;          % Referir recta a 'O_ref'.
recta(2,:) = recta(2,:) + O_ref;          % Referir recta a 'O_ref'.






