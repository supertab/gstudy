function [s] = f_s_sinus(s_amp,f0,t,P0)
% This function computes a single sinusoidal signal.
% Where:
%          s_amp = Signal's amplitude; typicaly in [Pa].
%             f0 = Bandwidth's (BW) central frequency.
%              t = Time axis [s].
%             P0 = Initial phase [Rad].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   06/07/2005   
% ver 2.0   05/01/2008    English version!
% ver 2.1   21/02/2008    Initial phase parameter added 'P0'.
% ver 2.2   15/01/2009    Simplified conversion to column vector added.

t = t(:);   % Convert row vector in column vector.

w = 2*pi*f0;
s = s_amp*sin(w.*t + P0);  % se elije asi p/que v(t) sea senoidal y tenga sentido fisico






