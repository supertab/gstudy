function [u,U,V,W,num_u,num_v] = f_cal_coord_shell(ele_order,P_field,R,phi,psi,uw,vw,us,vs)
% This function finds the coordinates poins in a shell type grid region (cylindrical or spherical). 
% Parameters:
%                 ele_order ~= 0 -> 1st. element of 1D reception array to the right side.
%                            = 0 -> Then invert order of coordinates (from array's front view).
%                    P_field = [x y z] Cental point in shell grid.
%                        phi = Angle of aperture of shell in X-Z plane [Deg.].
%                        psi =        "          "        in Y-Z [Deg.].
%
%                        x_w = Width of shell type grid defined for X-axis [m].
%                        y_w = The same but defined for Y-axis [m].
%           
%                        x_s = Step between grid points following X-axis [m].
%                        y_s = The same but in Y-axis [m].
%            
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
% 
% ver 1.0    13/12/2008
% ver 1.1    04/01/2009     Non exact division results solved by redundant 'round' added.
% ver 2.0    09/01/2009     Adaptation to change on reception field dimensions: Ps3 = zeros(Nx,Ny,N).
% ver 3.0    17/01/2009     Using tentative new code for spherical shell!
% ver 4.0    27/11/2009     Adaptation for LAMB program ver 0.1 'ele_order' parameter added.


if R <= 0
    disp('(o_o) Warning: Using r_type = 3 with null or negative radius... ')
    disp(' Using 1 point for reception field shell :( ')
        U = P_field(1);  V = P_field(2);  W = P_field(3);
        u = U;       num_u = 1;       num_v = 1;        L_arc = 0;       L_arc2 = 0;
else
    if (phi == 0) && (psi == 0)
        disp('(o_o) Warning: Using r_type = 3 with null apertures angles: phy,psi ')
        disp(' Using 1 point for reception field shell :( ')
        U = P_field(1);  V = P_field(2);  W = P_field(3);
        u = U;       num_u = 1;       num_v = 1;        L_arc = 0;       L_arc2 = 0;
        
    elseif (phi > 0) && (psi == 0)
        %--------------------------------------------------------------------------------
        %--------------------------------------------------------------------------------
        % 1. Cylindrical shell type grid defined along Y-axis.
        %--------------------------------------------
        % 1.1. Define number of elements along Y-axis.
        disp(' 1. Displaying cylindrical shell along Y-axis')
        if vw == 0  
            v = 0; w = R;
            num_v = 1;
        else
            remainder_v = f_impar(vw,vs);
            if remainder_v               % Fraction remainder?
                num_v = fix(vw/vs);      % Yes! Then define number of points...
                vw = num_v*vs;           % along Y-axis using Y-width 'vw' with Y-step 'vs'.
            else
                num_v = round(vw/vs);    % No, ok! Then it is no necesary to change this dimension.
            end
            v_min = -(vw/2);   
            v_max = (vw/2);      
                v = v_min+(0:num_v - 1)*(v_max - v_min)/floor(num_v);
                v = [v v_max];
            num_v = max(size(v));
        end
        %--------------------------------------------
        % 1.2. Define number of elements along shell arc.
            phi_r = phi*pi/180;
            L_arc = phi_r*R;     
      remainder_u = f_impar(L_arc,us);
        if remainder_u               % Fraction remainder?
            num_u = round(L_arc/us);   % Yes! Then define number of points...
           L_arc2 = num_u*us;        % along X-axis using X-width 'vw' with X-step 'us'.
        else
            num_u = round(L_arc/us); % No, ok! Then it is no necesary to change this dimension.
           L_arc2 = L_arc;
        end
        %----------------------------------------
        fprintf('n_ele = %i',num_u);  pause(2.0)
        %----------------------------------------
 [ang_ele] = f_cal_ang_eles(ele_order,num_u,us,R);
                u = R*sin(-ang_ele);
                w = R*cos(ang_ele);
        %--------------------------------------------
        U = u*ones(1,num_v) + P_field(1);
        V = ones(num_u,1)*v + P_field(2);
        W = w*ones(1,num_v) - R + P_field(3);
        u = L_arc2;  % Return longitude of final arc.
        
    elseif (phi == 0) && (psi > 0)
        %--------------------------------------------------------------------------------
        %--------------------------------------------------------------------------------
        % 2. Cylindrical shell type grid defined along X-axis.
        %--------------------------------------------
        % 2.1. Define number of elements along X-axis.
        disp(' 2. Displaying cylindrcial shell along X-axis')
        if uw == 0  
            u = 0; w = R;
            num_u = 1;
        else
            remainder_u = f_impar(uw,us);
            if remainder_u               % Fraction remainder?
                num_u = fix(uw/us);      % Yes! Then define number of points...
                   uw = num_u*us;        % along Y-axis using Y-width 'uw' with Y-step 'us'.
            else
                num_u = round(uw/us);    % No, ok! Then it is no necesary to change this dimension.
            end
            u_min = -(uw/2);   
            u_max = (uw/2);      
                u = u_min+(0:num_u - 1)*(u_max - u_min)/floor(num_u);
                u = [u u_max]';
            num_u = max(size(u));
        end
        %--------------------------------------------
        % 2.2. Define number of elements along shell arc.
            psi_r = psi*pi/180;
            L_arc = psi_r*R;     
      remainder_v = f_impar(L_arc,vs);
        if remainder_v               % Fraction remainder?
            num_v = round(L_arc/vs);   % Yes! Then define number of points...
           L_arc2 = num_v*vs;        % along X-axis using X-width 'vw' with X-step 'vs'.
        else
            num_v = round(L_arc/vs); % No, ok! Then it is no necesary to change this dimension.
           L_arc2 = L_arc;
        end
        [ang_ele] = f_cal_ang_eles(ele_order,num_v,vs,R);
                v = R*sin(-ang_ele');
                w = R*cos(ang_ele');
        %--------------------------------------------
        U = u*ones(1,num_v) + P_field(1);
        V = ones(num_u,1)*v + P_field(2);
        W = ones(num_u,1)*w - R + P_field(3);
        u = L_arc2;  % Return longitude of final arc.        
    elseif (phi > 0) && (psi > 0)
        %--------------------------------------------------------------------------------
        %--------------------------------------------------------------------------------
        % 3. Espherical shell grid!
        %--------------------------------------------
        % 3.1. Define shell number of elements along arc in X-Z plane.
        disp(' 3. Displaying espherical shell!')
            phi_r = phi*pi/180;
            L_arc = phi_r*R;     
      remainder_u = f_impar(L_arc,us);
        if remainder_u               % Fraction remainder?
            num_u = round(L_arc/us);   % Yes! Then define number of points...
          L_arc_u = num_u*us;        % along X-axis using X-width 'vw' with X-step 'us'.
        else
            num_u = round(L_arc/us); % No, ok! Then it is no necesary to change this dimension.
          L_arc_u = L_arc;
        end
      [ang_ele_u] = f_cal_ang_eles(ele_order,num_u,us,R);
                u = R*sin(-ang_ele_u');
        %--------------------------------------------
        % 3.2. Define shell number of elements along arc in Y-Z plane.
            psi_r = psi*pi/180;
            L_arc = psi_r*R;     
      remainder_v = f_impar(L_arc,vs);
        if remainder_v               % Fraction remainder?
            num_v = round(L_arc/vs);   % Yes! Then define number of points...
          L_arc_v = num_v*vs;        % along X-axis using X-width 'vw' with X-step 'vs'.
        else
            num_v = round(L_arc/vs); % No, ok! Then it is no necesary to change this dimension.
          L_arc_v = L_arc;
        end
      [ang_ele_v] = f_cal_ang_eles(ele_order,num_v,vs,R);
                v = R*sin(-ang_ele_v');
        %--------------------------------------------
%         U = u'*ones(1,num_v) + P_field(1);
%         V = ones(num_u,1)*v + P_field(2);
%         W = R*cos(ang_ele_u)*cos(ang_ele_v') - R + P_field(3); 
        %--------------------------------------------
        % Tentative new code for a spherical cap!
        disp('(O_O) Warning: Using tentative new code...')
        U = R*sin(-ang_ele_u)*ones(1,num_v) + P_field(1);
        V = R*cos(ang_ele_u)*sin(-ang_ele_v') + P_field(2);
        W = R*cos(ang_ele_u)*cos(ang_ele_v') - R  + P_field(3);
        pause;
        %--------------------------------------------
        
    L_arc = L_arc_u; 
   L_arc2 = L_arc_v;
        u = [L_arc L_arc2];  % Return longitude of final arcs.
    %--------------------------------------------------------------------------------    
    end
end


%--------------------------------------------
fprintf(' L_arc = %.4f \n',L_arc);
fprintf('L_arc2 = %.4f \n',L_arc2);
fprintf(' num_u = %i    num_v = %i \n',num_u,num_v);
%--------------------------------------------
%caxis([0 P_field(3)*1.25])