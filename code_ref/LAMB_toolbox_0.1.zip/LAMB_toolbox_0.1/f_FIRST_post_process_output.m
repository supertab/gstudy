function [N2,t2,Ps2,p_max] = f_FIRST_post_process_output(r_type,N,t,t_min,t_max,fs_IRM,fs,X,Ps,p_max,f_norm_ps,f_pause,f_plot,f_handle,f_font)
% Rearrange final field matrix format & dowsample IRM data for THS method.
% Parameters:
%        r_type = Region type
%                 0. Square/Rectangular zone: 'rectangle filled'.
%                 1. Square/Rectangular: 'circle filled'.
%                 2. Circular/Ellipse:   'circle filled'.
%            
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
%
% ver 1.0    06/12/2009    


fprintf(' Post-processing IRM output... \n');
%--------------------------------------------------------------------------
% 1.0.7.1 Re-arranging final field matrix 'Ps'.
if (r_type == 1) || (r_type == 2)
    [ni,nj] = size(X);
    if (ni > 1) && (nj == 1)  % Ok, X is a column vector.
        Ps_1(:,:) = Ps(:,1,:); % Arrage 2D matrix.
        clear Ps;              % Clear old data.
        Ps1 = Ps_1';           % Reassing by transposing field matrix (signals by columns).
        clear Ps_1;            % Clear auxiliar buffer.
    elseif (ni == 1) && (nj == 1)  % Ok, X is a simple point.
        Ps_1(:,:) = Ps(:,1,:); % Arrage 2D matrix.
        clear Ps;              % Clear old data.
        Ps1 = Ps_1(:);         % Reassing by transposing field matrix (signals by columns).
        clear Ps_1;            % Clear auxiliar buffer.        
    else
        fprintf(':( Error: bad X vector format for: "f_FIRST_post_process_output"...')
        fprintf('   Check vector size.  r_type = %i \n',r_type);
        error(' ');
    end
else
    fprintf(':( Error: bad Ps matrix format for: "f_FIRST_post_process_output"...')
    fprintf('   Check parameter: r_type = %i \n',r_type);
    error(' ');
end


%--------------------------------------------------------------------------
% 1.0.7.2 Down-sample IRM output to original THS sampling frequency values.
fprintf('1.0.7.2 ');
 t_2 = (min(t):1/fs:max(t))';  % New down-sampled time vector.
 N_2 = max(size(t_2));
Ps_2 = f_resample_data(N,N_2,fs_IRM,fs,t,t_2,Ps1,0);

%--------------------------------------------------------------------------
% 1.0.7.3 Adjust IRM trace longitudes to THS values [t_min t_max].
fprintf('1.0.7.3 Adjusting IRM traces... \n');
  t = (t_min:1/fs:t_max-(1/fs))'; % THS time vector.
 t2 = t + min(t_2);               % Down-sampled & adjusted final time vector.
 N2 = max(size(t2));              % Number of points in temporal traces.

if N2 <= N_2
    fprintf(' Cutting output: N� = %i -> N = %i \n',N_2,N2);
   Ps2 = Ps_2(1:N2,:);
else
    fprintf(' Padding output w/0�s  N� = %i --> N = %i \n',N_2,N2);
    Ps2 = zeros(N2,ni);
    Ps2(1:N_2,:) = Ps_2;
end

%--------------------------------------------------------------------------
% 1.0.7.4 Determinate absolute maximum excitation pressure.
   ps_max = max(max(Ps2));
[N,nro_p] = size(Ps2);
if f_norm_ps
    for j =1:nro_p
        Ps2(:,j) = Ps2(:,j)*(p_max/ps_max);
    end
    fprintf('1.0.7.4 Using p_max = %.1f Pa \n',p_max);
else
    p_max = ps_max;
    fprintf('1.0.7.4 Max. pressure: p_max = %.1f Pa \n',p_max);
end

%--------------------------------------------------------------------------
% Check time window: plot 1st. and last 'Ps' signals. 
if f_plot
    figure(f_handle); hold on; grid on;
    plot(t2,Ps2(:,1),'b');              
    plot(t2,Ps2(:,ni),'r');
       M = cell(2,1);
    M{1} = '1st signal';
    M{2} = 'last signal';
    xlabel('t [s]','FontSize',f_font);  
    ylabel('Ps-signals [Pa]','FontSize',f_font);
    legend(M,'FontSize',f_font)
    if f_pause, disp(' Program paused. Press any key to continue...'); pause;
    else        pause(2); 
    end
end





