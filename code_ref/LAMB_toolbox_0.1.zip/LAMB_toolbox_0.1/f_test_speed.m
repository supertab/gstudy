function [N,t,s] = f_test_speed(N3,N4,t3,t4,s3,s4)
% Choose longitude of signals by testing their 'fft' speed.
%            
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
%
% ver 1.0    21/12/2008    
% ver 1.1    02/12/2009


n_trials = 20;
     cs3 = ones(N3,1);  A3 = ones(N3,1);
     cs4 = ones(N4,1);  A4 = ones(N4,1);
fprintf(' FFT speed test in progress @%i trials...\n',n_trials);
%--------------------------------
tic      
for i = 1:n_trials
    cs3 = f_conv_met2(N3,s3,s3,A3);
end
et3 = toc;
%--------------------------------
tic      
for i = 1:n_trials
    cs4 = f_conv_met2(N4,s4,s4,A4);
end
et4 = toc;
%--------------------------------
fprintf(' N3 = %i  &  et3 = %.2f s \n',N3,et3);
fprintf(' N4 = %i  &  et4 = %.2f s \n',N4,et4);
if et3 < et4
    N = N3; t = t3(:); s = s3(:); % Choose original longidude!
    fprintf(' Choosing:   N3 = %i  :) \n',N3);
else
    N = N4; t = t4(:); s = s4(:); % Choose longitude mulple of 2^N.    
    fprintf(' Choosing:  N4 = %i  :) \n',N4);
end
    









