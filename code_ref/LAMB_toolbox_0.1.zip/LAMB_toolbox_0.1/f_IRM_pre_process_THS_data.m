function [a,b,N4,t4,f4,f_s4,Nf4,S_a] = f_IRM_pre_process_THS_data(c,N,f_min,f_max,fs,fs_IRM,t2,N2,Nx2,Ny2,P_field_2,x_w2,y_w2,x_s2,y_s2,R_3,D3_min,D3_max,P_field_3,a_3,b_3,Nt,num_modes,S_z,f_D)
% This function prepares the THS output data to be input to IRM routines.
%
%      P_field_2 = [x y z]  Central point in plate emission field region [m].     
%           x_w2 = Width of emission field in X axis [m].
%           y_w2 = Width in Y axis [m].
%
%           x_s2 = Step between points in X axis [m].
%           y_s2 = In Y axis [m].
% 
%             fs = THS sampling frequency [Hz].
%         fs_IRM = Sampling frequency for IRM [Hz].
%
%             Nx = Number of points in X-axis of emission grid.
%             Ny = Number of points in Y-axis of emission grid.
%             Nx = Number of incident angles (theta) of THS excitation field.
%      num_modes = Number of modes present in THS output data-structure.
%
%            S_z = THS output data-structure (cell array);  S_z = cell{Nt,num_modes}(Nx,Ny,N);
%
%      P_field_3 = [x y z]  Central point (in air) of reception field region [m].
%            
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
%
% ver 1.0    17/12/2008     Using IRM-2D core: 'Main_FIRST_2D_2v3' (17/04/2008)
% ver 2.0    08/01/2009     Change on reception field dimensions: [Nx Ny]=size(X_field) --> S_z = zeros(Nx,Ny,N)


disp(' 2.4. Preprocessing input data...');

%--------------------------------------------------------------------------
% Determing sizes of acoustic emission elements (half dimessions used by IRM).
disp('2.4.1. Determing size of emission elements... ok')
a = x_s2/2;  % Half width [m].
b = y_s2/2;  % Half high [m].
%fprintf('  x_width = %d \n   y_high = %d \n',a,b);

%--------------------------------------------------------------------------
% Compose IRM input data from THS:  S_z = cell{Nt,num_modes}(Nx,Ny,N);
if num_modes > 1
    fprintf('2.4.2. Composing input data for %d incident angle(s)... \n',Nt);
    fprintf('      with: %d Lamb modes present. \n',num_modes);
         U = zeros(Nx2,Ny2,N);
    for k2 = 1:Nt
        for i2 = 1:Nx2       
            for j2 = 1:Ny2
                % Compose total signal at every point in X-Y grid.
                U(i2,j2,:)= f_THS_compose_total_signal(num_modes,N,S_z,k2,i2,j2); % S_z = cell{Nt,num_modes}(Nx,Ny,N);
            end   
        end
        S_z{k2,1} = U;
        for n = 2:num_modes
            S_z{k2,n} = [];    % Clean used data ...to save memory.
        end
    end
else
    fprintf('2.4.2. Single Lamb mode at %d incident angle(s) on input data... \n',Nt);
    fprintf('    ...no data to compose. \n');
end
%--------------------------------------------------------------------------
% Re-struct data to clean []...
     S_a = cell(Nt,1);
S_a(:,1) = S_z(:,1);
clear U S_z;

%--------------------------------------------------------------------------
% Obtain aceleration signals and padd traces with '0' for IRM.
fprintf('2.4.3. Obtaining vertical acelerations... \n');
fprintf('    ...and padding traces with %i "0" for IRM. \n',N2-N);    
    u = zeros(N,1);
   A2 = zeros(Nx2,Ny2,N2);
for k2 = 1:Nt
    for i2 = 1:Nx2       
        for j2 = 1:Ny2
                   u = S_a{k2,1}(i2,j2,:);        % Extract signal at field point (i,j).
     A2(i2,j2,2:N-1) = (fs^2)*diff(diff(u(:)));   % Obtain and save aceleration with (N2-N) '0' padding.
        end   
    end
    S_a{k2,1} = A2;
end
clear u;
clear A2;

%--------------------------------------------------------------------------
% Test fft speed versus trace longitude.
fprintf('2.4.4. Testing fft speed... \n')
     t3 = (t2(1):1/fs_IRM:t2(N2))';    % Oversample time axis from fs --> fs_IRM.
     N3 = length(t3);
[N4,t4] = f_cal_t_power_2 (fs_IRM,t3); % Aproximate N3 lenght to -> '2^n' multiple for IRM speed-up... 
 s(:,:) = S_a{1,1}(1,1,:);
     s3 = interp1(t2,s,t3,'cubic'); 
     s4 = interp1(t2,s,t4,'cubic'); 
[N4,t4] = f_test_speed(N3,N4,t3,t4,s3,s4);
%--------------------------------------------------------------------------
% Test available memory; maximum size of continuos block = 1015.56 MB.
fprintf('2.4.5.');
N_limit = 905*1024*1024;
[N_total] = f_IRM_check_memory(N_limit,Nx2,Ny2,N4);

%--------------------------------------------------------------------------
% Over sample THS data signals to get accuracy in IRM calculations.
fprintf('2.4.6.');
[S_a] = f_resample_data(N2,N4,fs,fs_IRM,t2,t4,S_a,1);

%--------------------------------------------------------------------------
% Dermine frequencies in signal bandwidth (BW).
f_s4 = fs_IRM/N4;           % Frequency spacing 'steps' between frequency points in signals [Hz].
  f4 = (f_min:f_s4:f_max)'; % Signals frequency operating vector BW [Hz].  
 Nf4 = max(size(f4));       % Number of frequencies in BW.  

%--------------------------------------------------------------------------
% Check emission element-min.wavelenght ratio.
%--------------------------------------------------------------------------
% Obs. from G.Kino book (Ch.3 pp.157):
% ...We note that far from the origin, where kR >> 1, the wave impedance approaches Z. 
% However, for a small source near the origin (kR << 1). the wave impedance becomes 
% imaginary and there is very little real power flow. Because there is very little 
% real power flow near the source, it is difficult to excite acoustic waves from a 
% source much smaller than a wavelength in diameter.... These conclusions also hold 
% for the plane transducer and other transducer shapes. 
% "The transducer size (in this case its diameter) must be of the order of half a wavelength 
% or more to obtain efficient excitation of acoustic waves".

lambda_air_max = c/f_min;
     e_ratio_a = (2*a)/(lambda_air_max/2);
     e_ratio_b = (2*b)/(lambda_air_max/2);
       
if (e_ratio_a < 1) || (e_ratio_b < 1)
   fprintf(' :( \n'); 
   fprintf('---------------------------------------------------------------------\n');
      disp('(o_o) Warning: Using too small emission elements... ');
   fprintf('      Field calculations may loose accuracy. Ele_ratio should be > 1 \n');
   fprintf('e_ratio_a = %.1f  e_ratio_b = %.1f \n',e_ratio_a,e_ratio_b);
   fprintf('---------------------------------------------------------------------\n');
   disp('Program paused. Press any key to continue...')
   pause;
end
%--------------------------------------------------------------------------
fprintf('2.4 IRM Final data: \n');
fprintf('         N = %i    Nf = %i   f_s = %.1f Hz \n',N4,Nf4,f_s4);
fprintf(' Emission element parameters: \n');
fprintf('        2a = %.2f mm    e_ratio_a = %.1f \n',2*a*1000,e_ratio_a);
fprintf('        2b = %.2f mm    e_ratio_b = %.1f \n',2*b*1000,e_ratio_b);
fprintf('lambda_air_max = %.2f mm \n',lambda_air_max*1000);

fprintf(' P_field_2 = [%.3g %.3g %.3g] \n',P_field_2(1),P_field_2(2),P_field_2(3));
% u = [P_field_2 - P_field_2o];  % Cal. in plane offset vector.
% if norm(u) > 0   fprintf(' -> [%.3g %.3g %.3g] \n',P_field_2o(1),P_field_2o(2),P_field_2o(3));
% else             fprintf(' \n');   end;
fprintf(' P_field_3 = [%.3g %.3g %.3g] \n',P_field_3(1),P_field_3(2),P_field_3(3));
fprintf('    D3_min = %.1f mm      D3_max = %.1f mm \n',D3_min*1000,D3_max*1000);

if R_3 > 0
    fprintf('       R_3 = %.2g m \n',R_3);
end
if f_D 
    fprintf(' Directivity: On'); 
    if a_3 == b_3 
        fprintf('  @r3 = %.1f mm \n\n',a_3*1000);
    else
        fprintf('...\n\n');
    end;
else
    fprintf(' Directivity: Off \n\n'); 
end;

fprintf(' Memory use: %.1f %% \n',100*N_total/N_limit);






