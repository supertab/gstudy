function [Ps] = f_apo_triang(level,r_type,num_p,num_s,num_p_s,O,x_w,y_w,X,Y,Ps)
% This function applies a triangle type apodizing factors to a given 
% field excitation matrix 'Ps'.
% For square type regions, it applies only 1D apodizations through X-axis.
% While for cicular/elliptical regions, 1D X-axis profile is rotated through
% field origin for getting a 2D surface apodization.
% Parameters:
%             level = Minimum Y-amplitude value 4 initial triangular window.
%            r_type = Region type.
%             num_p = Total number of points in field matrix 'Ps'.
%             num_s = Number of strips composing excitation field.
%           num_p_s = Number of 'points' per strip line.
%                 O = Central point of excitation field.
%               x_w = Width of reception field in X axis [m].
%               y_w = Width in Y axis [m].
%             [X,Y] = Coordinates matrix of field.
%                Ps = Pressure signal's matrix [Pa].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    10/02/2008

switch(r_type)
    case 1 
        %------------------------------------------------------------------
        % 1. Square/rectangular region.
            w = f_w_triang(num_s,level);
            w = w/max(w);  % Window amplitude normalization.
            if y_w == 0
                for i = 1:num_s
                    Ps(:,i) = w(i).*Ps(:,i);
                end
            else
                n = 0;
                for i = 1:num_s
                    for j = 1:num_p_s(i)
                        Ps(:,j+n) = w(i)*Ps(:,j+n);
                    end
                    n = n + num_p_s(i)
                end
            end
    case 2 
        %------------------------------------------------------------------
        % 2. Circular/elliptical region.
        if x_w >= y_w
            R = x_w/2;
        else
            R = y_w/2;
        end
           Rs = 0.0001;
            x = (-R:Rs:R)';
           nx = max(size(x));  % Nuber of points in generating window.
            y = f_w_triang(nx,level);
            w = zeros(num_p,1);
        for j = 1:num_p
        [Theta(j) Ro(j)] = cart2pol(X(j),Y(j));
                    w(j) = interp1(x,y,Ro(j)); % Interpolate apo. value for distance Ro(j).
        end
        w = w/max(w);  % Normalize final apodization coefficients.
        for j = 1:num_p
            Ps(:,j) = w(j).*Ps(:,j);           % Apodice time signal for point 'j' of 'num_p'.
        end
    otherwise
        error('Unrecongnized excitation region type: "r_type"')
end











