function f_IRM_plot_3(f_4D_plot,Ps_feature_type,Ps_delay_type,N3,Z0,fs_IRM,t3,Ps3,X3,Y3,Z3,r3_type,Nt,theta,ang_alfa,ang_beta,ang_gamma,a,p_max,num_p,f_title,axis_font,f_delete_figs,Ps_movie,movie_delay,f_save_movie,d_factor,f_pause)
% Plot features for: 3) Reception plane with "theta" incidence angles :)
% Parameters:
%      f_4D_plot = 1 -> Activate color surfaces             0 -> Use common 3D surfs. 
%Ps_feature_type = 0 -> Maximum.  
%                  1 -> Pick-to-pick value.
%                  2 -> Energy.                                
%              value -> Time instant 'photo' (index between 1:N).
%  Ps_delay_type = 0 -> Extraction of signal delays from (+)Pick.
%                  1 ->      "          "       but from (-)Pick.
%                  2 -> Delay extraction from signals envelope.
%             N3 = Number of points in signal traces.
%             Z0 = c*ro. Air characteristic impedance in [N.s/m^3] or [Rayls].
%         fs_IRM = IRM Sampling frequency [Hz].
%             t3 = Signal's temporal axis [s].
%            Ps3 = IRM output cell array data 'structure'. ->  Ps3 = cell(Nt,1)(Nx3,Ny3,N3).
%       X3,Y3,Z3 = Reception field coodinates of simulated IRM acoustic field [m].
%        r3_type = Acoustic reception region type:
%                  0 -> "Rectangular" region. This include: single point; line and plane (Plane).
%                  1 -> Square/Rectangular circle filled (Plane).
%                  2 -> Circular/Ellipse circle filled (Plane).
%                  3 -> Cylindrical/spherical Shell!
%             Nt = Number of incidence angles (theta).  In case of 3D-map --> Nt = Ncph.
%          theta = Plane wave incidence angle vector [Deg].
%       ang_alfa = Rotation of plane 'Ps' around axis 'X3'.Ej.90� -> plane 'X3-Z3'
%       ang_beta = Rotation following axis 'Y3' It's orientation have to be studied later...
%      ang_gamma = Rotation following axis 'Z3'.
%              a = Radius of excitation 'points' [m].
%          p_max = Maximun excitation pressure [Pa].
%          num_p = Number of THS excitation 'points'.
%        f_title = 1 -> Activate title plot.                0 -> Do not.
%      axis_font = Title & axis font size.
%  f_delete_figs = 1 -> Deletes figures before quit.        0 -> Do not delete figures.
%       Ps_movie = 1 -> Display movie feature.              0 -> Do not. 
%    movie_delay = Delay between movie frames [s].
%   f_save_movie = 1 -> Save movie into a file '*.avi'.     0 -> Do not.
%       d_factor = Downsample frequency factor (fs2 = fs/d_factor) to speed-up movies.
%        f_pause = 1 -> Activate program pause.             0 -> Do not.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    25/12/2008
% ver 1.1    08/01/2009     External downsample variable added: 'd_factor'.
% ver 1.1.1  17/01/2009     Error correction of conversion of Ps_delay to [us].
% ver 1.2    17/02/2009     Inter program 'f_pause' flag added.


[Nx3 Ny3] = size(X3);      % Number of points of reception field.
if (r3_type == 0) || (r3_type == 3)
    fprintf('2.4.3. Plane reception region with  Nt = %i incidence angle(s) :) \n',Nt)
    %---------------------------------        
    % Detect plane of given line field.
     [Ax,Ax_name] = f_IRM_detect_axis(X3,Y3,Z3);
%     Ps3
else
    fprintf(':( Error: Using wrong "r_type" parameter w/Line-Arc region type \n');
    fprintf('Nx3 = %i   Ny3 = %i   r3_type =',Nx3,Ny3,r3_type);   error(' ');
end


if ~Ps_movie
    %---------------------------------------------------------------------------------------------------------------    
    % 3.1 Plot features of pressure signals.
    h1 = figure(50020); hold on; grid on; 
    set(gcf,'Renderer','zbuffer')  % Use Z buffer to speed up the plotting.
    set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
    xlabel([Ax_name(1) ' [m]'],'FontSize',axis_font);
    ylabel([Ax_name(2) ' [m]'],'FontSize',axis_font);
    if f_title     
        title(['Feature of pressure signals in a plane ',Ax_name,' @p-max = ',num2str(p_max),'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p)],'FontSize',f_title); 
    end
   %---------------------------------        
   % Plot feature of pressure signals.
   h2 = figure(50021); hold on; grid on; 
   set(gcf,'Renderer','zbuffer')  % Use Z buffer to speed up the plotting.
   set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
   xlabel([Ax_name(1) ' [m]'],'FontSize',axis_font);
   ylabel([Ax_name(2) ' [m]'],'FontSize',axis_font);
   if f_title     
       title(['Pressure signals delay [us] in a plane ',Ax_name,' @p-max = ',num2str(p_max),'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p)],'FontSize',f_title);
   end
   
   %---------------------------------        
   for k = 1:Nt
       [Ps_feature,Ps_delay] = f_cal_Ps_feature(Ps_feature_type,Ps_delay_type,Z0,N3,fs_IRM,t3,theta(k),Ps3{k},h1,h2,Ax(:,:,1),Ax(:,:,2),axis_font);
       if f_4D_plot
           figure(h1);   surf(X3,Y3,Z3,Ps_feature,'tag','S1');     axis equal;  shading interp;  if r3_type == 3  view(30,50); end;
           figure(h2);   surf(X3,Y3,Z3,Ps_delay*10^6,'tag','S2');       axis equal;  shading interp;  if r3_type == 3  view(30,50); end;
       else
           figure(h1);   surf(Ax(:,:,1),Ax(:,:,2),Ps_feature);     axis tight;  shading interp;  if r3_type == 3  view(30,50); end;
           figure(h2);   surf(Ax(:,:,1),Ax(:,:,2),Ps_delay*10^6);  axis tight;  shading interp;  if r3_type == 3  view(30,50); end;
       end
       [Ps_max,ii] = max(Ps_feature);   ii = ii(1);
       [Ps_max,jj] = max(max(Ps_feature));
       text(Ax(ii,jj,1),Ax(ii,jj,2),Ps_max,[num2str(theta(k)),'�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',12);
       fprintf(' theta = %i� \n',theta(k))
       drawnow;  if f_pause  pause;  end;
       if f_4D_plot && (Nt > 1) && (k < Nt)
           delete(findobj(h1,'Tag','S1')); % Delete plotted surfaces :)
           delete(findobj(h2,'Tag','S2')); 
       end
   end
else
    %---------------------------------------------------------------------------------------------------------------
    % 3.2 Display movie for surface reception field!!!
    if     d_factor <= 0  fprintf('(o_o) Warning: d_factor must be >= 1 \n'); d_factor = 1
    elseif d_factor > 1   fprintf(' d_factor On! @ %.1f \n',d_factor);  end;
     fs4 = fs_IRM/d_factor;
  t4_min = t3(1);
[t4_max] = f_round(t3(N3),1/fs4,0);
      t4 = (t4_min:1/fs4:t4_max)';    % Downsample time axis from:  fs_IRM --> fs_IRM/d_factor.
      N4 = length(t4);
   [Ps3] = f_over_sample_data(N3,N4,fs_IRM,fs4,t3,t4,Ps3);
    fprintf('(o_o) Warning: displaying movie for 1st. incidence angle only \n');
       k = 1;          [Nx,Ny,nt] = size(Ax);      fprintf(' theta: %d�... \n',theta(k));       
    xmin = min(min(X3));     xmax = max(max(X3));
    ymin = min(min(Y3));     ymax = max(max(Y3));
    zmin = -(max(max(max(Ps3{k}(:,:,:)))));   zmax = -zmin;
    for n = 1:N4
        h1 = figure(50022); %  set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
        surf(Ax(:,:,1),Ax(:,:,2),Ps3{k}(:,:,n));  
        axis([xmin xmax ymin ymax zmin zmax zmin zmax]);  
        set(gcf,'Renderer','zbuffer')  % Use Z buffer to speed up the plotting.
        view(25,50);  shading interp; %view(16,30); %view(170,42); 
        title(['Acoustic pressure @p-max = ',num2str(p_max),'Pa; a = ',num2str(a*1000),' mm  � J.L.Prego-Borges'],'FontSize',12);
        xlabel([Ax_name(1),' [m]'],'FontSize',axis_font);  ylabel([Ax_name(2),' [m]'],'FontSize',axis_font); zlabel('[Pa]','FontSize',axis_font);
        F(n) = getframe(h1);
        pause(movie_delay);
        if ~f_save_movie clear F; end;  % In not save file...then release memory!
    end        
    if f_save_movie
        file = input('file_name ?','s');
        fprintf('Saving data to "%s.avi"  file.\n',file)
        movie2avi(F,file,'compression','Cinepak','quality',65)
        disp(' :)  Done!')
    end
end    

    
    
%--------------------------------
if f_delete_figs && f_pause
    pause;  
    delete(figure(h1)); 
    if ~Ps_movie  delete(figure(h2)); end;
elseif f_delete_figs
    delete(figure(h1)); 
    if ~Ps_movie  delete(figure(h2)); end;
end


