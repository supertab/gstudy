function f_THS_plot(f_delete_figs,f_cph_mapping,f_movie,f_view_spectra,f_feature_type,num_modes,mode_type,a,p_max,Z0,Nf,Nt,N,theta,c_ph,f,k,t,x_w,y_w,Nx,Ny,X_field,Y_field,Ps,S_z,fs,x_s2,y_s2,f_pause,f_font,f_title)
% Plotting function for THS data features.
%
% Parameters:
%  f_delete_figs = 1 -> Deletes THS figures before quit.                  0 -> Do not delete figures.
%  f_cph_mapping = 1 -> Enable 3D F-Cph_mapping.                          0 -> Disable.
%        f_movie = 1 -> Display movie feature.                            0 -> Do not. 
% f_view_spectra = 1 -> Activate spectrum view (only 4 lines & surfaces). 0 -> De-activate feature.
% f_feature_type = 0 -> Maximum.  
%                  1 -> Pick-to-pick value.
%                  2 -> Energy.                                
%              value -> Time instant 'photo' (index between 1:N).
%      num_modes = Number of Lamb waves modes simulated.
%      mode_type = 0 -> Simmeric modes.
%                  1 -> Anti-simmeric modes.
%              a = Radius of excitation 'points' [m].
%          p_max = Maximun excitation pressure [Pa].
%             Z0 = c*ro. Air characteristic impedance in [N.s/m^3] or [Rayls].
%             Nf = Number of frequencies to compute of Lamb wave time signals.
%             Nt = Number of incidence angles (theta).  In case of 3D-map --> Nt = Ncph.
%              N = Number of points in signal traces.
%          theta = Plane wave incidence angle vector [Deg].
%           c_ph = Phase velocities vector for 3D-map [m/s].
%              f = Frequency vector [Hz].
%              k = Wavenumber vector [Rad./m].
%              t = Signal's temporal axis [s].
%        x_w,y_w = X-axis width & Y-axis width of  excitation region [m].
%          Nx,Ny = Number of 'points' by axis in excitation region.
%      X,Y_field = Coodinates of THS simulated field [m].
%             Ps = Input excitation signal data matrix:  Ps = zeros(N,Nx);
%            S_z = THS data cell array:  S_z = cell{Nt,num_modes}(Nx,Ny,N);
%      x_s2,y_s2 = Step between points for simulated field following X & Y axis resp. [m].
%             fs = Sampling frequency [Hz].
%        f_pause = 1 -> Activate program pause.                           0 -> Do not.
%         f_font = Axis labels font size eg. 14.
%        f_title = Plot Title w/font size 14,etc.                         0 -> Do not plot titles.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    06/12/2008     The same as 'f_THS_plot_main' (v2.0 12/05/2008) but with callback modularity.
% ver 1.1    11/10/2008     Delete figures flag added.
% ver 1.2    08/01/2009     Add of external variables [Nx Ny]=size(X_field); with change on recept.field dims: 1st.X-dim then Y-dim.
% ver 1.3    15/01/2009     Air characteristic impedance parameter added.
% ver 1.4    17/02/2009     Inter program 'f_pause' added.


 movie_delay = 0;  %0.02       % Delay between movie frames [s].
 
f_save_movie = 0;              % 1 -> Save movie into a file '*.avi'.
                               % 0 -> No.
                               
disp('1.4. Plotting THS results...');
if f_cph_mapping
    %----------------------------------------------------------------------------------------------------------------
    % 1) Process data for 3D-mapping feature: F,Cph.
    %----------------------------------------------------------------------------------------------------------------
    [F,Cph,Mode_max] = f_THS_plot_1(num_modes,f,c_ph,S_z,a,p_max,f_title,f_font,f_delete_figs,f_pause);
else
    %----------------------------------------------------------------------------------------------------------------
    % 2) Plot features for reception field.
    %----------------------------------------------------------------------------------------------------------------
    if (Ny == 1) && (Nx == 1) 
        if Nt == 1
            %------------------------------------------------------------------
            % 2.1) Single reception point at 1 incidence angle :)
            theta_index = 1 % Because of single incidence angle.
            [u,v,U,V] = f_THS_plot_2_1(num_modes,N,fs,t,S_z,theta_index,a,p_max,f_title,f_font,f_delete_figs,f_pause);
        else
            %------------------------------------------------------------------
            % 2.2) Single reception point with several incidence angles!
            [S] = f_THS_plot_2_2(f_view_spectra,f_feature_type,num_modes,t,N,Nt,fs,S_z,theta,a,p_max,Z0,Ps,f_title,f_font,f_delete_figs,f_pause);
        end    
        %------------------------------------------------------------------
    elseif (Ny == 1) && (Nx > 1) 
        %------------------------------------------------------------------        
        % 2.3) X-line reception region.
        [Uz] = f_THS_plot_2_3(f_movie,movie_delay,f_save_movie,f_view_spectra,f_feature_type,num_modes,t,N,Nt,Nx,fs,S_z,X_field,x_s2,theta,a,p_max,Z0,f_title,f_font,f_delete_figs,f_pause);
    elseif (Ny > 1) && (Nx == 1)
        %------------------------------------------------------------------
        % 2.4) Y-line reception region.
        [Uz] = f_THS_plot_2_4(f_movie,movie_delay,f_save_movie,f_view_spectra,f_feature_type,num_modes,t,N,Nt,Ny,fs,S_z,Y_field,y_s2,theta,a,p_max,Z0,f_title,f_font,f_delete_figs,f_pause);
    else
        %------------------------------------------------------------------
        % 2.5) X-Y reception field grid.
        if f_view_spectra == 1 
            fprintf('(o_o) Warning: "f_view_spectra" flag seems to be active... \n'); 
            fprintf('... But no action is taken in this case  :| \n\n');
        end;
        [U] = f_THS_plot_2_5(f_movie,movie_delay,f_save_movie,f_feature_type,num_modes,t,N,Nt,Nx,Ny,fs,S_z,X_field,Y_field,theta,a,p_max,Z0,f_title,f_font,f_delete_figs,f_pause);
    end
end
fprintf(' Done... THM finish!  :) \n\n')



%  [M] = f_max(S_z) % Detect maximum value in calculated data structure.

