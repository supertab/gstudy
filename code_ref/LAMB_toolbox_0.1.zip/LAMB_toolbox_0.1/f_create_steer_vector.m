function [steer_ang,Ns] = f_create_steer_vector(steer_data)
% This funtion creates a stearing angle vector used in a radiation radiagram. 
% Parameters:
%            steer_data = [Min. Max. step] values of reception steering angles [Deg].           
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    04/02/2009    
% ver 1.1    17/02/2009     Change in name:  'f_FRM_steer_ang'  -->  'f_create_steer_vector'.


if abs(steer_data(1)) > 60
    disp('(o_o) Warning:  1st steering angle over  > 60�');
    disp('                Setting:  1st_steer_ang = 60�');
    steer_data(1) = 60;
end
if abs(steer_data(2)) > 60
    disp('(o_o) Warning:  2nd steering angle over  > 60�');
    disp('                Setting:  2nd_steer_ang = 60�');
    steer_data(2) = 60;
end
if steer_data(3) <= 0
    disp('(o_o) Warning:  null steering angle step...');
    disp('                Setting:  steer_step = 1�');
    steer_data(3) = 1;
end


if steer_data(1) > steer_data(2)
    steer_ang = (steer_data(1): -steer_data(3):steer_data(2))';
else
    steer_ang = (steer_data(2): -steer_data(3):steer_data(1))';
end

Ns = length(steer_ang);
fprintf(' Ns = %i steering angles. \n',Ns);
    









