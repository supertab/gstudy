function [c_ph1] = f_fsearch_1_cph(Nl,d,Ro,Alfa,Beta,f_min,c_ph,c_ph_fs)
%  This function performs the 1st. step of fine search in 'c_ph' sweep.
%
% Units:    
%                                       Frequency 'f' = [Hz]
%                             Mode phase-speed 'c_ph' = [m/s]
%     Long.& shear bulk-wave velocities 'Alfa'/'Beta' = [m/s]
%                                        Density 'ro' = [Kgr/m^3]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     16/06/2007   


%------------------------------------------------------------------
% Sweep in phase velocity         
   w_min =  2*pi*f_min;
        
       k = w_min/c_ph;              % 'k' at initial 'c_ph'
     k_p = w_min/(c_ph + c_ph_fs);  % Valuate 'k' at: 'c_ph + delta_c_ph'
     k_m = w_min/(c_ph - c_ph_fs);  % Valuate 'k' at: 'c_ph - delta_c_ph'        
    
 [det_S] = f_cal_determinant(Nl,d,w_min,k,Ro,Alfa,Beta);    % Calculate determiant at initial point
[det_Sp] = f_cal_determinant(Nl,d,w_min,k_p,Ro,Alfa,Beta);  % Then calculate determiant
[det_Sm] = f_cal_determinant(Nl,d,w_min,k_m,Ro,Alfa,Beta);  % Then calculate determiant
      
       a = log10(abs(det_S));
     a_p = log10(abs(det_Sp));    
     a_m = log10(abs(det_Sm));

%--------------------------------------------------------------------------
% Choose direction of decreasing determinats. 
    if a_p > a_m
        delta =  -c_ph_fs;  % The determinat decreses into the right (<-) see figure(10)
    elseif a_p < a_m
        delta =  c_ph_fs;   % The determinat decreses into the left  (->) see figure(10)
    elseif a_p == a_m
        disp('Ops! Troubles in  "f_fsearch_1_cph"  function...')
        disp('Absolute val. of determinants are iqual at distinct locations during fine search.')
        pause        
    end    
%--------------------------------------------------------------------------
% Find minimun determinat 
          j = 1;
    not_end = 1;
    while not_end
             k_j = w_min/(c_ph + j*delta);
        [det_S1] = f_cal_determinant(Nl,d,w_min,k_j,Ro,Alfa,Beta);
             a_1 = log10(abs(det_S1));
        if a_1 > a
         not_end = 0;
        else            
               k = k_j;    % Resume pointer to new value.
               a = a_1;   
               j = j + 1;  
               
% c_ph1 = w_min/k_j; 
% figure(10)
% plot(c_ph1,a_1,'c.')

% % figure(200)
% % plot(real(det_S1),imag(det_S1),'b.')
        end
    end
%--------------------------------------------------------------------------
c_ph1 = w_min/k;   % Conversion to phase speed.

figure(10)
plot(c_ph1,a,'b.')



    
    
    