function [k1,f1] = f_fsearch_2_fk(Nl,d,Ro,Alfa,Beta,k1,f1,f_fs,delta_f_limit)
%  This function performs the 2nd. step of fine search in a 'frequency'
% sweep at constant phase velocity: 'c_ph_max'
%  The final notation '_fk' means that the frequency and wave number
% are variated; keeping the phase velocity constant.
%
% Units:    
%                                       Frequency 'f' = [Hz]
%                             Mode phase-speed 'c_ph' = [m/s]
%     Long.& shear bulk-wave velocities 'Alfa'/'Beta' = [m/s]
%                                        Density 'ro' = [Kgr/m^3]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     17/06/2007
% ver 2.0     19/06/2007    Change input parameter:  c_ph -> k
% ver 3.0     20/08/2007    Vectoriced version!

       k = ones(5,1);
      k2 = zeros(5,1);
   det_S = zeros(5,1);
       a = zeros(5,1);
       w = zeros(5,1);
%--------------------------------------------------------------------------
% Sweep in frequency at fixed phase velocity 'c_ph_max'
 not_end = 1;
      w1 = 2*pi*f1;
   delta = 2*pi*f_fs;     % Frequency increment
    w(3) = w1;            % 'w_center' starting value
    w(1) = w1 + delta;    % 'w_left'
    w(5) = w1 - delta;    % 'w_right'
    
c_ph_max = w1/k1;         % Constant phase velocity [m/s]

n_f2 = 1;
while not_end  
    %----------------------------------------------------------------------
    % Calculate intermidiate points
    w(2) = w1 + 0.5*delta;         % 'w_left_2'
    w(4) = w1 - 0.5*delta;         % 'w_right_2'
       k = w/c_ph_max;             % Corresponding 'k' vector
    %----------------------------------------------------------------------
    % Evaluate determinants
    det_S = f_cal_determinant(5,Nl,d,w,k,Ro,Alfa,Beta);
        a = log10(abs(det_S));
    %----------------------------------------------------------------------
    % Detect minimum and update freqncy 'w1' to new value.
    [a_min,index] = min(a);          
               w1 = w(index); % If  not_end = 0  -> this is the final value of frequency
        
        if delta <= delta_f_limit
          not_end = 0;  % Stop serch if:  delta <= 0.1Hz!!! 
        else
    %----------------------------------------------------------------------
    % Update  'delta', 'k_center', 'k_left' and 'k_right' to new values
     delta = delta/2;
        w2 = w;
      w(3) = w2(index);
      w(1) = w2(index - 1);
      w(5) = w2(index + 1);
      
        a2 = a;
      a(3) = a2(index);
      a(1) = a2(index - 1);
      a(5) = a2(index + 1);
      n_f2 = n_f2 + 1;
      
%    f = w/(2*pi); 
%    figure(100)
%    plot(f(1),a(1),'g.')
%    plot(f(3),a(3),'b.')
%    plot(f(5),a(5),'r.')
%    drawnow
   
    end
end
%f2 = w1/(2*pi); 
%
% figure(100)
% plot(f2,min(a),'mo')
% 
% n_f2
% n_f2;




