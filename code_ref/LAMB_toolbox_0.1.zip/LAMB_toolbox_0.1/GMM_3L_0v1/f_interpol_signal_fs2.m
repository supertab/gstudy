function [s2] = f_interpol_signal_fs2(fs,fs2,s)
% Esta funcion interpola una se�al dada, cambiando su frecuencia de muestreo
% de 'fs' --> 'fs2'. Por el momento asume que:   fs <= fs2
% Asi mismo, asume que de una traza de se�al de 'N' puntos, los 1eros 'n' 
% no son nulos, y los toma como nueva se�al. Esto es asi p/ acelerar el cal.
% de puntos nulos en la cola de la se�al original.
%
% 1) fs <= fs2  -> Interpolar puntos en la se�al.
% 2) fs >  fs2  -> Diezmar puntos de la se�al de entrada POR LO MOMENTO NO IMPLENTADA..!!
%
% ver 1.0   06/08/2005

  
 ts = 1/fs;
ts2 = 1/fs2;
  r = fs/fs2  % relacion entre las frec. de muestreo de:  entrada/salida 

if fs == fs2
    s2 = s;  % no hay cambio alguno de la se�al
else
    if fs < fs2
        disp('Interpolando se�al de entrada...')    
        %[si,sj,s] = find(s);  % trunca parte nula de la se�al (cola).
                               % Eliminado x ecualiz. de 's2' c/long.vector de entrada 's'
            n = max(size(s));  % long. original de la traza de se�al
           n2 = n/r;           % long. nueva de la se�al con 'fs2' interpolada
           s2 = zeros(1,n2);
        s2(1) = s(1);
            k = 2;
          t2k = ts2;
        for i = 1:n-1
           ti = (i-1)*ts;
            while t2k <= ti+ts
                if t2k < ti+ts
                s2(k) = ((t2k-ti)*fs*(s(i+1)-s(i))) + s(i);  % interpolado de la muestra de la s2(k)
                    k = k + 1;
                  t2k = t2k + ts2;
                else
                s2(k) = s(i+1);
                    k = k + 1;
                  t2k = t2k + ts2;
                end
            end
            i;
        end
    else
        disp('Ups! Diezmado de puntos de v(t): fs > fs2.  No implementado aun.....')
        pause
    end
end


% t = 0:1/fs:(n-1)/fs;
% t2 = 0:1/fs2:(n2-1)/fs2;
% 
% figure(10)
% plot(t,s)
% hold
% plot(t',s,'ro')
% grid          
% plot(t2',s2,'b.')
