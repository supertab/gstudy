function [A] = f_cal_wave_amplitudes(Nl,d,theta,w,k,Ro,Alfa,Beta,A_ref)
% This function calculates the amplitudes of the bulk waves in the layer system
% resolving the ecuation:
%
%         [S2].[A2] = [B].[A1]
%
%                   | 
%                   V
%
%              [A2] = [S2]^-1.[B].[A1]
%
% Where:    
%       Nl  =  Number of layers in the system.
%      [A1] =  Known wave amplitudes column vector. Typically [0 0 1 0]
%      [S2] =  Modified system matrix 'S'.
%       [B] =  Right handed transposed complementary terms of matrix 'S'.
%      [A2] =  Amplitude column vector to find.
%       [A] =  Matrix array with row layer vectors of wave amplitudes 'A2'.
%              Convention of row 'i':   [AL_+ AL_- AS_+ AS_-]
%                                        |                 | 
%                                        |<-- layer 'i' -->| 
% 
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0    09/07/2007   
% ver 2.0    11/11/2007    Multiple precision added! --> Using the 'mp_toolbox'.
% ver 2.1    15/11/2007    Conversion to 'k1' component added.

mp_dontmakeall={'Nl','n'};
mp_makeall
theta_r = theta*pi/180;
      k = k*cos(theta_r);
 
 n = 4*(Nl-1);
S2 = mp(zeros(n,n));
 B = mp(zeros(n,n));
A1 = mp(zeros(n,1));
 A = mp(zeros(Nl,4));
switch Nl
    case 2
        %--------------------------------------------------------------------------
        % Ensamble component matrix for 2-layer system.
            N = 1;   % Number of 'w;k' points to calculate.            
        [D1b] = f_ensamble_mp_Db_matrix(N,0,w,k,Ro(1),Alfa(1),Beta(1));
        [D2t] = f_ensamble_mp_Dt_matrix(N,0,w,k,Ro(2),Alfa(2),Beta(2));
        
  S2(1:4,1:2) = [D1b(:,2) D1b(:,4)];
  S2(1:4,3:4) = -[D2t(:,1) D2t(:,3)];
        %--------------------------------------------------------------------------
        % Loading excitation reference wave amplitude value in layer-2.
         A1(3) = A_ref;   % <- 'AL_2m'  Longitudinal(-) wave.
        %--------------------------------------------------------------------------
   B(1:4,1:2) = -[D1b(:,1) D1b(:,3)];
   B(1:4,3:4) = [D2t(:,2) D2t(:,4)];
        %--------------------------------------------------------------------------
        % Calculate remaining wave amplitude for 3-layer system
            A2 = S2\(B*A1);   
        %--------------------------------------------------------------------------
        % Ensamble final matrix of wave amplitudes 4 semi-infinite half-space 
        % with Longitudinal(-) excitation.                         
        A(1,:) = [0 A2(1) 0 A2(2)];      % Layer-1
        A(2,:) = [A2(3) A_ref A2(4) 0];  % Layer-2

    case 3
        %--------------------------------------------------------------------------
        % Ensamble component matrix for 3-layer system.
            N = 1;   % Number of 'w/k' points to calculate.
        [D1b] = f_ensamble_mp_Db_matrix(N,0,w,k,Ro(1),Alfa(1),Beta(1));
        [D2t] = f_ensamble_mp_Dt_matrix(N,d,w,k,Ro(2),Alfa(2),Beta(2));
        [D2b] = f_ensamble_mp_Db_matrix(N,d,w,k,Ro(2),Alfa(2),Beta(2));
        [D3t] = f_ensamble_mp_Dt_matrix(N,0,w,k,Ro(3),Alfa(3),Beta(3));
        
  S2(1:4,1:2) =  [D1b(:,2) D1b(:,4)];
  S2(1:4,3:6) = -D2t;
  S2(5:8,3:6) =  D2b;
  S2(5:8,7:8) = -[D3t(:,1) D3t(:,3)];
        %--------------------------------------------------------------------------
        % Loading excitation vector
        % Reference wave amplitude value: 'AL_3m'           
        A1(7) = A_ref;      
        %--------------------------------------------------------------------------
   B(1:4,5:6) = -[D1b(:,1) D1b(:,3)];
   B(5:8,7:8) =  [D3t(:,2) D3t(:,4)];
        %--------------------------------------------------------------------------
        % Calculate remaining wave amplitude for 3-layer system
            A2 = S2\(B*A1);                
        %--------------------------------------------------------------------------
        % Ensamble final matrix of wave amplitudes 4 semi-infinite half-space 
        % with Longitudinal(-) excitation.                         
        A(1,:) = [0 A2(1) 0 A2(2)];
        A(2,:) = A2(3:6)';   
        A(3,:) = [A2(7) A_ref A2(8) 0];
    otherwise
        %--------------------------------------------------------------------------
        disp('System matrix not defined yet: "f_cal_wave_amplitudes" ...')
        pause
end

%A2

     
