function [c_ph1] = f_fsearch_2_cph(Nl,d,Ro,Alfa,Beta,f_min,c_ph1,c_ph_fs,delta_c_ph_limit)
%  This function performs the 2nd. step of the fine search in 'c_ph' sweep.
%
% Units:    
%                                       Frequency 'f' = [Hz]
%                             Mode phase-speed 'c_ph' = [m/s]
%     Long.& shear bulk-wave velocities 'Alfa'/'Beta' = [m/s]
%                                        Density 'ro' = [Kgr/m^3]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     17/06/2007

      k = ones(5,1);
     k2 = zeros(5,1);
  det_S = zeros(5,1);
      a = zeros(5,1);
%------------------------------------------------------------------
  delta = c_ph_fs;
not_end = 1;
  w_min = 2*pi*f_min;
   k(3) = w_min/c_ph1;            % 'k_center' starting value
   k(1) = w_min/(c_ph1 + delta);  % 'k_left'
   k(5) = w_min/(c_ph1 - delta);  % 'k_right' 

      j = 1;
while not_end  
    %----------------------------------------------------------------------
    % Calculate intermidiate points
    k(2) = w_min/(c_ph1 + 0.5*delta);  % 'k_left_2'
    k(4) = w_min/(c_ph1 - 0.5*delta);  % 'k_right_2'
        
    %----------------------------------------------------------------------
    % Evaluate determinants
    for i = 1:5
         det_S(i) = f_cal_determinant(Nl,d,w_min,k(i),Ro,Alfa,Beta);
             a(i) = log10(abs(det_S(i)));
    end
    %----------------------------------------------------------------------
    % Detect minimum and update speed 'c_ph1' to new value.
    [a_min,index] = min(a);
            c_ph1 = w_min./k(index);      

%----------------------------------------------------------------------
% Excluded code... only to verify angle between consecutive solutions
%    det_S2(j) = det_S(index);
%     if j > 1
%         angle0 = (180/pi)*atan2(imag(det_S2(j)),real(det_S2(j-1)));
%         angle1 = (180/pi)*atan2(imag(det_S2(j)),real(det_S2(j)));
%         dif_ang = angle1 - angle0
%     end
    %----------------------------------------------------------------------
    if delta <= delta_c_ph_limit
        not_end = 0;  % Stop serch if e.g:  delta <= 1um/s!!! 
    else
    %----------------------------------------------------------------------
    % Update  'delta', 'k_center', 'k_left' and 'k_right' to new values

     delta = delta/2;
        k2 = k;
      k(3) = k2(index);
      k(1) = k2(index - 1);
      k(5) = k2(index + 1);
      
        a2 = a;
      a(3) = a2(index);
      a(1) = a2(index - 1);
      a(5) = a2(index + 1);
      
%    c_ph = w_min./k; 
%    figure(10)
%    plot(c_ph(1),a(1),'g.')
%    plot(c_ph(3),a(3),'b.')
%    plot(c_ph(5),a(5),'r.')

% % figure(200)
% % plot(real(det_S),imag(det_S),'r.')
    j = j +1;
    end
end

figure(10)
plot(c_ph1,min(a),'b*')
