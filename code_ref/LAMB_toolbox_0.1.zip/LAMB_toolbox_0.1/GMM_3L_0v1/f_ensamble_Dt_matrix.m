function [Dt] = f_ensamble_Dt_matrix(N,x2,w,k1,ro,alfa,beta)
% This function ensables the field matrix 'D_top' of the method. See Ref.(1) in main.
% Where:    
%                  Dt = D_top
%
%  Lame-consts. units = [Pa] 
%        Density (ro) = [Kgr/m^3]
%           alfa/beta = Long. & shear bulk wave velocities [m/s]
%                  x2 = Layer through thickness dimension: [mm]
%                   s = Snell constant = sin(theta_L)/alfa = sin(theta_S)/beta
%                   w = frequency vector!   Dimension = 1 x 1 x N.
%                  k1 = wavenumber vector!  Dimension = 1 x 1 x N.
%                   N = number of elements of vector 'w' and 'k1'.
%
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     05/06/2007   
% ver 1.01    13/06/2007    Cambio de signos en matrices segun T.P.Pialucha
% ver 1.02    14/06/2007    Cambio de signos en matrices segun J.L.Prego-Borges
% ver 1.03    15/06/2007    Uso de matrices s/paper Lowe
% ver 2.0     20/08/2007    Vectoriced version!

     Dt = zeros(4,4,N);
     
 C_alfa = sqrt(((w./alfa).^2) - (k1.^2));
 C_beta = sqrt(((w./beta).^2) - (k1.^2));
 g_alfa = exp(i*C_alfa.*x2);
 g_beta = exp(i*C_beta.*x2);
      B = (w.^2) - 2*(beta^2)*(k1.^2);

%------------------------------------------     
% D_top matrix
Dt(1,1,:) = k1;
Dt(2,1,:) = C_alfa;
Dt(3,1,:) = i*ro.*B;
Dt(4,1,:) = (2*i*ro*(beta^2)*C_alfa).*k1;

Dt(1,2,:) = k1.*g_alfa;
Dt(2,2,:) = -C_alfa.*g_alfa;
Dt(3,2,:) = (i*ro).*B.*g_alfa;
Dt(4,2,:) = (-2*i*ro*(beta^2)).*C_alfa.*g_alfa.*k1;

Dt(1,3,:) = C_beta;
Dt(2,3,:) = -k1;
Dt(3,3,:) = (-2*i*ro*(beta^2)).*C_beta.*k1;
Dt(4,3,:) = i*ro.*B;

Dt(1,4,:) = -C_beta.*g_beta;
Dt(2,4,:) = -k1.*g_beta;
Dt(3,4,:) = (2*i*ro*(beta^2)).*C_beta.*g_beta.*k1;
Dt(4,4,:) = (i*ro).*B.*g_beta;
%------------------------------------------     



