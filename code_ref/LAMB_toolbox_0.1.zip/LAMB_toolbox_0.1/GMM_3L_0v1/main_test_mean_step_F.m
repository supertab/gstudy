% Prog de test paso medio entre puntos de Frec.
% 25-08-2007

clear
clc

%load   matlab_data_1mm_Ti_water_curves
%load   matlab_data_1mm_Ti_vacuum_curves
load   matlab_data_1mm_Ti_vacuum_curves_2

n = min(size(K))  % Numero de modos

for i=1:n
              ii = find(K(:,i));
    m_index(i,1) = max(ii);
end
M = max(m_index);

DF = zeros(M-1,n);
for i = 1:n
         DF(:,i) = diff(F(1:M,i));
   m_f_step(i,1) = mean(DF(1:m_index(i)-1,i));   
end
m_f_step   % Paso medio de frecuencia entre puntos de las curvas.
%----------------------------
figure(900); hold; grid;
figure(910); hold; grid;
figure(920); hold; grid;
figure(930); hold; grid;
figure(940); hold; grid;

     c0 = 344  %1500
    f_s = 1*10^3
  f_max = 10*10^6

      N = zeros(n,1);
  f_min = zeros(n,1);
    K_1 = cell(n,1);
    F_1 = cell(n,1);
  Cph_1 = cell(n,1);
Theta_1 = cell(n,1);
for i = 1:n    
      F_0{i} = F(1:m_index(i),i);
      K_0{i} = K(1:m_index(i),i);
    Cph_0{i} = 2*pi.*F_0{i}./real(K_0{i});    
     Cg_0{i} = (2*pi)*diff(F_0{i})./diff(real(K_0{i}));   % Velocidad de grupo de los modos.
     k_air_0 = (2*pi/c0).*F_0{i};                         % Vector c/ numeros de onda p/aire (original)
  Theta_0{i} = asin(real(K_0{i})./k_air_0);               % Angulo original del modo(i)
  Theta_0{i} = (180/pi)*Theta_0{i};                       % Conversion de: Rad -> Deg.�
    
    f_min(i) = 1000*(round(F(1,i)/1000));                 % Frec. minima nueva del modo(i)
      F_1{i} = (f_min(i):f_s:f_max)';                     % Cell array c/vectores de frecuencia nuevos p/c modo.
      K_1{i} = interp1(F_0{i},K_0{i},F_1{i},'spline');    % Nuevos numeros de onda interpolados.
    Cph_1{i} = interp1(F_0{i},Cph_0{i},F_1{i},'spline');     
     Cg_1{i} = (2*pi)*diff(F_1{i})./diff(real(K_1{i}));   % Velocidad de grupo de los modos.
     k_air_1 = (2*pi/c0).*F_1{i};                         % Vector c/ numeros de onda nuevos p/aire.
  Theta_1{i} = asin(real(K_1{i})./k_air_1);               % Angulo interpolado de c/modo!
  Theta_1{i} = (180/pi)*Theta_1{i};                       % Conversion de: Rad -> Deg.�
        N(i) = max(size(F_1{i}));                         % Longitud de puntos nueva p/c traza de modo.
    
       resto = f_impar(i,2);
    if resto
        figure(900)
        plot(F_0{i},Cph_0{i},'bo')
        plot(F_1{i},Cph_1{i},'g')
        plot(F_1{i},Cph_1{i},'g.')
       
        figure(910)
        plot(F_0{i},real(K_0{i}),'bo')
        plot(F_1{i},real(K_1{i}),'g')
        plot(F_1{i},real(K_1{i}),'g.')
       
        figure(920)
        plot(F_0{i},imag(K_0{i}),'bo')
        plot(F_1{i},imag(K_1{i}),'g')
        plot(F_1{i},imag(K_1{i}),'g.')
       
        figure(930)
        plot(F_0{i},Theta_0{i},'bo')
        plot(F_1{i},Theta_1{i},'g')
        plot(F_1{i},Theta_1{i},'g.')
        
        f0 = F_0{i};
        f0 = f0(2:m_index(i));
        f1 = F_1{i};
        f1 = f1(2:N(i));        
        figure(940)
        plot(f0,Cg_0{i},'bo')
        plot(f1,Cg_1{i},'g')
        plot(f1,Cg_1{i},'g.')
    else
        figure(900)
        plot(F_0{i},Cph_0{i},'bo')
        plot(F_1{i},Cph_1{i},'r')
        plot(F_1{i},Cph_1{i},'r.')
       
        figure(910)
        plot(F_0{i},real(K_0{i}),'bo')
        plot(F_1{i},real(K_1{i}),'r')
        plot(F_1{i},real(K_1{i}),'r.')
       
        figure(920)
        plot(F_0{i},imag(K_0{i}),'bo')
        plot(F_1{i},imag(K_1{i}),'r')
        plot(F_1{i},imag(K_1{i}),'r.')
       
        figure(930)
        plot(F_0{i},Theta_0{i},'bo')
        plot(F_1{i},Theta_1{i},'r')
        plot(F_1{i},Theta_1{i},'r.')
        
         f0 = F_0{i};
         f0 = f0(2:m_index(i));
         f1 = F_1{i};
         f1 = f1(2:N(i));        
        figure(940)
        plot(f0,Cg_0{i},'bo')
        plot(f1,Cg_1{i},'r')
        plot(f1,Cg_1{i},'r.')
    end
    drawnow
end
N


