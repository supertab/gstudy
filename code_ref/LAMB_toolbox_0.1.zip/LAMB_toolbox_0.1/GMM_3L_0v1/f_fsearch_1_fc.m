function [f1] = f_fsearch_1_fc(Nl,d,Ro,Alfa,Beta,k,f,f_fs)
%  This function performs the 1st. step of fine search in a 'frequency'
% sweep at constant wave number 'k'.
%  The final notation '_fc' means that the frequency and phase-velocity
% are variated if needed; keeping the wavenumber 'k' constant.
%
% Units:    
%                          Coarse frequency point 'f' = [Hz]
%                          Frequency fine step 'f_fs' = [Hz]
%                             Mode phase-speed 'c_ph' = [m/s]
%     Long.& shear bulk-wave velocities 'Alfa'/'Beta' = [m/s]
%                                        Density 'ro' = [Kgr/m^3]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     19/06/2007   
% ver 1.1     06/07/2007    Check if minimum already reatched at begining...
% ver 2.0     20/08/2007    Vectoriced version!

   n_fc1 = 1;
%------------------------------------------------------------------
% Sweep in frequency at fixed wave numver 'k'
    w_fs = 2*pi*f_fs;
       w = 2*pi*f;
      w1 = [(w - w_fs); w; (w + w_fs)];
      k1 = [k;k;k];
      
 [det_S] = f_cal_determinant(3,Nl,d,w1,k1,Ro,Alfa,Beta);    % Calculate determiant at initial point
       a = log10(abs(det_S));
 [aa,ii] = min(a);

%--------------------------------------------------------------------------
% Choose direction of decreasing determinats. 
if (a(1) == a(2)) || (a(1) == a(3)) || (a(2) == a(3))
    disp('Ops! Troubles in  "f_fsearch_1_fc"  function...')
    disp('Absolute val. of determinants are iqual at distinct locations during fine search.')
    pause
elseif a <= -20         % Absolute determinant limit reatched?
    f1 = w1(ii)/(2*pi); % Yes! Then nothing to do.. Exit.
    not_end = 0;        
elseif ii == 2          % Absolute minimum reatched?
    f1 = f;             % Nothing to do... Exit.
    not_end = 0;
elseif ii == 1          % Go to right?
      delta = -w_fs;    % Yes, determinants are decresing into the right.
      a_old = a(1);
    not_end = 1;
elseif ii == 3          % Go to left?  
      delta = w_fs;     % Yes, determinants are decresing to the left.
      a_old = a(3);
    not_end = 1;
end
%--------------------------------------------------------------------------
% Find minimun determinat 
while not_end
             w_j = w + delta;
       [det_S_j] = f_cal_determinant(1,Nl,d,w_j,k,Ro,Alfa,Beta);
             a_j = log10(abs(det_S_j));
             if a_j > a_old
                 f1 = w/(2*pi);  % Yes! Convert 'w' -> 'frequency and exit!
                 not_end = 0;    % Exit -> minimum determinant founded.
             else    
                 w = w_j;
             a_old = a_j;
             n_fc1 = n_fc1 + 1;
                 
% f_j = w_j/(2*pi);
% figure(100)
% plot(f_j,a_j,'c.')
% drawnow            
             end
end
%--------------------------------------------------------------------------

% figure(100)
% plot(f1,a,'m.')
% n_fc1
% n_fc1;


    
    
    