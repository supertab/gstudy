function [det_S] = f_cal_determinant(N,Nl,d,w,k1,Ro,Alfa,Beta)
%  This function ensamble the global matrix of the system;
% and calculates its determinant.
%
% Units:    
%                                       Frequency 'f' = [Hz]
%                             Mode phase-speed 'c_ph' = [m/s]
%     Long.& shear bulk-wave velocities 'Alfa'/'Beta' = [m/s]
%                                        Density 'Ro' = [Kgr/m^3]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     16/06/2007   
% ver 1.01    20/06/2007    Speed improvement.
% ver 2.0     10/07/2007    Two layered system added.
% ver 3.0     20/08/2007    Vectoriced version!

      top = 0;
   bottom = 1;

switch Nl
    case 2
        %--------------------------------------------------------------------------
        % Ensamble components matrix for 2-layer system.
        [Dm_1b] = f_ensamble_Dm_matrix(N,bottom,0,w,k1,Ro(1),Alfa(1),Beta(1));
        [Dp_2t] = f_ensamble_Dp_matrix(N,top,0,w,k1,Ro(2),Alfa(2),Beta(2));
        %--------------------------------------------------------------------------
        % Ensamble final system matrix
                   n = 4*(Nl-1);
                   S = zeros(n,n,N);
        S(1:4,1:2,:) = Dm_1b;
        S(1:4,3:4,:) = -Dp_2t;     
        
    case 3
        %--------------------------------------------------------------------------
        % Ensamble components matrix for 3-layer system.
        [Dm_1b] = f_ensamble_Dm_matrix(N,bottom,0,w,k1,Ro(1),Alfa(1),Beta(1));
          [D2t] = f_ensamble_Dt_matrix(N,d,w,k1,Ro(2),Alfa(2),Beta(2));
          [D2b] = f_ensamble_Db_matrix(N,d,w,k1,Ro(2),Alfa(2),Beta(2));
        [Dp_3t] = f_ensamble_Dp_matrix(N,top,0,w,k1,Ro(3),Alfa(3),Beta(3));
        %--------------------------------------------------------------------------
        % Ensamble final system matrix
                   n = 4*(Nl-1);
                   S = zeros(n,n,N);
        S(1:4,1:2,:) = Dm_1b;
        S(1:4,3:6,:) = -D2t;
        S(5:8,3:6,:) = D2b;
        S(5:8,7:8,:) = -Dp_3t;
        
    otherwise
        %--------------------------------------------------------------------------
        disp('System matrix not defined yet... See:  "f_cal_determinant" ...')
        pause
end

det_S = zeros(N,1);
for n = 1:N
    det_S(n) = det(S(:,:,n));      % Calculate determinant
    if det_S(n) == 0
        det_S(n) = 10^-20;  % Check to avoid possible '0' of determinant.
    end
end
%1



