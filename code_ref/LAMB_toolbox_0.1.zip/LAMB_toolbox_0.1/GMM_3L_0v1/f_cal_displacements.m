function [U] = f_cal_displacements_2(d,theta,w,k,x,A,ro,alfa,beta,t)
% This function calculates the displacements fields (u1,u2) of waves
% at a given possition (x1,x2) in the layer system.
%
% Where:  
%      A(1) =>  A_lp  Possitive travelling logitudinal wave amplitude.
%      A(2) =>  A_ln  Negative travelling logitudinal wave amplitude.
%      A(3) =>  A_sp  Possitive travelling shear wave amplitude.
%      A(4) =>  A_sn  Negative travelling negative shear wave amplitude.
%
%        Nl = Number of layers in the system.
%        w  = Frequency [rad/seg.].
%        k  = Wavenumber [rad/m]. 
%        t  = Time instant [seg.].
%        s  = Snell constant = 1/c_ph  [1/m/seg.].
%        x  = [x1;x2] vector possition [m].
%        A  = Is the wave amplitudes column vector for the layer.
% alfa,beta = Laminar material bulk wave velocities [m/s].
%        ro = Material density.
%
%         U =  Displacement/stress matrix versus coordinate vector 'x'.
%    U(:,1) = 'x1'  -> Horizontal displacement [m].
%    U(:,2) = 'x2'  -> Vertical displacement [m].
%    U(:,3) = 's22' -> Normal stress [Pa].
%    U(:,4) = 's12' -> Shear stress [Pa].
%
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0    30/07/2007   
% ver 2.0    12/11/2007     Change in 'D' matrix according to number of layers.
% ver 2.1    12/11/2007     Multiple precision added! ... Using 'mp' toolbox.

mp_dontmakeall={'N','n'};
mp_makeall

k = k*cos(theta)   % Conversion to 'k1' component!

[N,aux] = size(x);
C_alfa = sqrt(((w./alfa)^2) - k^2);
C_beta = sqrt(((w./beta)^2) - k^2);
     B = (w^2) - (2*(beta^2)*(k^2));
     U = mp(zeros(4,N));

    for n = 1:N
        g_alfa_p = exp(i.*C_alfa.*x(n,2));
        g_alfa_n = exp(i.*C_alfa.*(d-x(n,2)));
    
        g_beta_p = exp(i.*C_beta.*x(n,2));
        g_beta_n = exp(i.*C_alfa.*(d-x(n,2)));
        
        %%         F = exp(i*(k*x(n,1) - w*t))   % <--- Propagation term.
        %--------------------------------------------------------------------------
        % Field matrix (by columns).
             D = mp(zeros(4,4));
        D(1,1) = k.*g_alfa_p;
        D(2,1) = C_alfa.*g_alfa_p;
        D(3,1) = i.*ro.*B.*g_alfa_p;
        D(4,1) = 2.*i.*ro.*k.*(beta^2).*C_alfa.*g_alfa_p;
       
        D(1,2) = k.*g_alfa_n;
        D(2,2) = -C_alfa.*g_alfa_n;
        D(3,2) = i.*ro.*B.*g_alfa_n;
        D(4,2) = -2.*i.*ro.*k.*(beta^2).*C_alfa.*g_alfa_n;
    
        D(1,3) = C_beta.*g_beta_p;
        D(2,3) = -k.*g_beta_p;
        D(3,3) = -2.*i.*ro.*k.*(beta^2).*C_beta.*g_beta_p;
        D(4,3) = i.*ro.*B.*g_beta_p;
    
        D(1,4) = -C_beta.*g_beta_n;
        D(2,4) = -k.*g_beta_n;
        D(3,4) = 2.*i.*ro.*k.*(beta^2).*C_beta.*g_beta_n;
        D(4,4) = i.*ro.*B.*g_beta_n;

        %--------------------------------------------------------------------------
        % Final displacement & stress vector
        U(:,n) = D*A;
    end
U = U';





