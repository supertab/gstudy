function [s_fil] = f_ideal_bp_filter(s,f_ci,f_cs,fs)
% This function applies an ideal Band-pass filtering to
% a given signal 's' sampled at 'fs' Hz.
% The low and high frequencies of the filter are: 'f_ci' y 'f_cs' respectively.
%
% Obs.: Signals are taken by columns.
%
% ver 1.0   10/02/2005
% ver 2.0   31/11/2007    Change fft of 'N' points to -> fft of '2N' points 
%                         to avoid circular convolutions!!
% ver 3.0   3/12/2007     Frequency vector and filtered spectrum corrected!!!
% ver 3.1   6/04/2008     Detection of empty frequency vector indexs.
% ver 3.2  17/08/2008     Correction in location indexs f3 & f4 by 1 sample to -> fs.

[N1,nro_s] = size(s);
        N = 2*N1;                   % Increase signal longitude to avoid circular convolutions 
                                    % (zero padding).
        y = zeros(N,nro_s);         % Output matrix of filtered signals.
%--------------------------------------------------------------------------
% 1. Create ideal band-pass filter response.
        H = zeros(N,nro_s);
        f = (0:N-1)'*(fs/N);        % Define frequency vector
 index_f1 = find(f >= f_ci);        % Find index in vector 'f' correspondig to 'f_ci'.
 index_f2 = find(f > f_cs);         % The same for 'f_cs'.
 index_f3 = find(f > fs - f_ci);    % The same for 'f_ci' image.
 index_f4 = find(f >= fs - f_cs);   % The same for 'f_cs' image.

if isempty(index_f1) || isempty(index_f2) || isempty(index_f3) || isempty(index_f4)
    disp(' :(  Error: filter window not properly set up.'); disp(' Try to:');
    disp(' 1) Increase "fs" ');
    disp(' 2) Increase the number of points of signal "N"');
    disp(' 3) Reduce filtering BW.'); disp(' ');
    error(' ')
end 
 
H(index_f1(1):index_f2(1)-1,:) = 1; % Create ideal response between frequencies.
H(index_f4(1):index_f3(1)-1,:) = 1;  

%--------------------------------------------------------------------------
% 2. Compute filtered signals matrix 'y'.
        S = fft(s,N,1);             % Compute matrix signal's 'fft' @Npoints by columns.
        Y = H.*S;                   % Filter signal's spectrum.
    s_fil = real(ifft(Y,N,1));      % Compute time domain filtered signal.
    s_fil = s_fil(1:N1,:);          % Discard added points.
        
%-------------------------- 
% 3. Parseval theorem check.
          E = sum((abs(s)).^2,1);       % Energy of input signals.
      E_fil = sum((abs(s_fil)).^2,1);   % Energy of output signals.
E_fil_ratio = (E_fil./E)'
%--------------------------          


