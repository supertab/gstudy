function [f_next,k_next] = f_cal_extrapolation(f,k,delta_k)
% This function calculates the extrapolation point in frequency 
% for the next point in the mode curves.
%
% Obs.: If the change in frequency step execeeds a certain level (around 20%)
% the quadratic strapolation strategy is abandoned, for a linear sheme.
%
%
% Units:    
%                 Actual mode 5-point frequency vector 'f' = [Hz]
%                            Current mode wave number  'k' = [rad/m]
%          Fix wave number increment for tracing 'delta_k' = [rad/m]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     06/07/2007   


 f_next = f(1) - 3*f(3) + 3*f(5);   % Quadratic extrapolation frequency scheme
 k_next = k + 2*delta_k;
  
%      f2 = [f;f_next]
%      fd = diff(f2)                  % Last frequency steps between last 6 points
% fd_mean = mean(fd(1:4))             % Average step of last 5 points
% fd_next = fd(5)                     % Step corresponding extrapolated point 'f_next'
% 
% if fd_next > 1.2*fd_mean   
%     f_next = f(5) + fd_mean         % Linear extrapolation frequency scheme
%     k_next = k + delta_k;           % Aprox. linear extrapolation wave vector value in 'k,f' space
% else
%     k_next = k + 2*delta_k;         % Aprox. quadratic  extrapolation wave vector value in 'k,f' space
% end

  
  
  
