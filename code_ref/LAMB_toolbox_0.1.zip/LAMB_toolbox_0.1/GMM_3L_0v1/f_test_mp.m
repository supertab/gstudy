function [A,B,c,d,pi2] = f_test_mp(a,b)

mp_makeall

A = a*b';
B = a.*b;

c = pi*1;
d = A + B*B';

pi2 = mp_pi;

default_precision


