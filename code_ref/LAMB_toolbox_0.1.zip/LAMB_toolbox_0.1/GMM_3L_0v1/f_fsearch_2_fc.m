function [f1] = f_fsearch_2_fc(Nl,d,Ro,Alfa,Beta,k1,f1,f_fs,delta_f_limit)
%  This function performs the 1st. step of fine search in a 'frequency'
% sweep at constant wave number 'k'.
%
% Units:    
%                          Coarse frequency point 'f' = [Hz]
%                          Frequency fine step 'f_fs' = [Hz]
%                             Mode phase-speed 'c_ph' = [m/s]
%     Long.& shear bulk-wave velocities 'Alfa'/'Beta' = [m/s]
%                                        Density 'ro' = [Kgr/m^3]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     19/06/2007   
% ver 2.0     20/08/2007    Vectoriced version!

   n_fc2 = 1;       
      k2 = zeros(5,1);
   det_S = zeros(5,1);
       w = zeros(5,1);
       a = ones(5,1);
%--------------------------------------------------------------------------
% Sweep in frequency at fixed wave numver 'k'
 not_end = 1;
       k = k1*ones(5,1);
      w1 = 2*pi*f1;
   delta = 2*pi*f_fs;     % Frequency increment
    w(3) = w1;            % 'w_center' starting value
    w(1) = w1 + delta;    % 'w_left'
    w(5) = w1 - delta;    % 'w_right'

while not_end  
    %----------------------------------------------------------------------
    % Calculate intermidiate points
    w(2) = w1 + 0.5*delta;         % 'w_left_2'
    w(4) = w1 - 0.5*delta;         % 'w_right_2'
    %----------------------------------------------------------------------
    % Evaluate determinants
    det_S = f_cal_determinant(5,Nl,d,w,k,Ro,Alfa,Beta);
        a = log10(abs(det_S));
    if a <= -20
        f1 = w(index)/(2*pi);     % Zero determinant reached... exit!
        not_end = 0;
    else
        %----------------------------------------------------------------------
        % Update frequency 'w1' to new value.
        [a_min,index] = min(a);
        if (delta <= delta_f_limit) % Frequency limit of 0.1Hz reached?
            f1 = w(index)/(2*pi);   % Yes! Stop searching and return final frequency value.
            not_end = 0; 
        else
        %----------------------------------------------------------------------
        % Update  'delta', 'k_center', 'k_left' and 'k_right' to new values
       delta = delta/2;
          w2 = w;
        w(3) = w2(index);
        w(1) = w2(index - 1);
        w(5) = w2(index + 1);
      
          a2 = a;
        a(3) = a2(index);
        a(1) = a2(index - 1);
        a(5) = a2(index + 1);

       n_fc2 = n_fc2 + 1;
% f = w/(2*pi); 
% figure(100)
% plot(f(1),a(1),'g.')
% plot(f(3),a(3),'b.')
% plot(f(5),a(5),'r.')
% drawnow
        end
    end
end
% figure(100)
% plot(f1,min(a),'k.')
%  n_fc2
%  n_fc2;

