function [k_next,f_next] = f_tmode_2_quad(Nl,d,Ro,Alfa,Beta,f_fs,f,k,delta_k,delta_k_r,delta_k_r_limit,delta_f_limit)
%  This function performs a single point calculation for the mode curves,
%  based in a quadratic strapolation scheme.
%
% Units:    
%                 Actual mode 5-point frequency vector 'f' = [Hz]
%             Fine search algorithm frequency step  'f_fs' = [Hz]
%                            Current mode wave number  'k' = [rad/m]
%      Real fix wavenumber increment for tracing 'delta_k' = [rad/m]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     19/06/2007   
% ver 2.0     05/08/2007    Atenuation curves algorithm added.


%--------------------------------------------------------------------------
%%%%[f_next,k_next] = f_cal_extrapolation(f,k,delta_k);

  f_next = f(1) - 3*f(3) + 3*f(5);               % Quadratic extrapolation frequency scheme.
k_i_next = imag(k(1) - 3*k(3) + 3*k(5));         % Quadratic extrapolation for wavenumber.
  k_next = real(k(5) + 2*delta_k) + i*k_i_next;  % Aprox. corresponding wavevector in 'k,f' space
  
%--------------------------------------------------------------------------
% Find final frequency value for  'k + 2*delta_k'
     f_1 = f_fsearch_1_fc(Nl,d,Ro,Alfa,Beta,k_next,f_next,f_fs);
  f_next = f_fsearch_2_fc(Nl,d,Ro,Alfa,Beta,k_next,f_1,f_fs,delta_f_limit);  % Adjust & save final freq. value for 'k_next'

%--------------------------------------------------------------------------
% Find final attenuation value for 'k + 2*delta_k'
[k_next_1,n_delta_k] = f_fsearch_1_atte_im(Nl,d,Ro,Alfa,Beta,delta_k_r,k_next,f_next);
            k_next_2 = f_fsearch_2_atte_im(Nl,d,Ro,Alfa,Beta,n_delta_k,delta_k_r_limit,k_next_1,f_next);
              k_next = k_next_2;
                  
% c_ph = (2*pi*f_next)/real(k_next);
% figure(300)
% plot(f_next,c_ph)
% plot(f_next,c_ph,'b.')
% drawnow
%      
% figure(400)
% plot(f_next,imag(k_next)/1000)
% plot(f_next,imag(k_next)/1000,'g.')
% drawnow




