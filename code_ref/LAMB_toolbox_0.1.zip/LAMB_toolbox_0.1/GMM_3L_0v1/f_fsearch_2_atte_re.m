function [k1] = f_fsearch_2_atte_re(Nl,d,Ro,Alfa,Beta,delta,delta_k_r_limit,k1,f1)
%  This function performs the 2nd. step of fine search in 'attenmuation'
% with frequency sweep at constant phase velocity: 'c_ph_max'
%
% Units:    
% Long.& shear bulk-wave velocities 'Alfa'/'Beta' = [m/s]
%                                    Density 'ro' = [Kgr/m^3]
%                                         delta_k = Wave number increment about: k1*10^-6;
%
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     01/08/2007
% ver 2.0     11/08/2007    Algorithm error correction.
% ver 3.0     20/08/2007    Vectoriced version!

    n_r2 = 1;    
       k = zeros(5,1);
      k2 = zeros(5,1);
   det_S = zeros(5,1);
       a = zeros(5,1);
%--------------------------------------------------------------------------
% Sweep in frequency at fixed phase velocity 'c_ph_max'
      w1 = 2*pi*f1*ones(5,1);

 not_end = 1;
 D_limit = delta*delta_k_r_limit;    % Attenuation search End-step limit.
    k(3) = k1;                       % 'k_center' starting value
    k(1) = k1 + delta;               % 'k_left'
    k(5) = k1 - delta;               % 'k_right'
      
while not_end  
    %----------------------------------------------------------------------
    % Calculate intermidiate points
    k(2) = k1 + 0.5*delta;           % 'k_left_2'
    k(4) = k1 - 0.5*delta;           % 'k_right_2'
    %----------------------------------------------------------------------
    % Evaluate determinants
    det_S = f_cal_determinant(5,Nl,d,w1,k,Ro,Alfa,Beta);
        a = log10(abs(det_S));
    %----------------------------------------------------------------------
    % Detect minimum and update frequency 'w1' to new value.
    [a_min,index] = min(a);          
               k1 = k(index); % If  not_end = 0  -> this is the final value of frequency
        
    if abs(delta) <= abs(D_limit)
       not_end = 0;        % Stop serch if:  delta <= 0.1Hz!!! 
    else
    %----------------------------------------------------------------------
    % Update  'delta', 'k_center', 'k_left' and 'k_right' to new values
     delta = delta/2;
        k2 = k;
      k(3) = k2(index);
      k(1) = k2(index - 1);
      k(5) = k2(index + 1);
      
        a2 = a;
      a(3) = a2(index);
      a(1) = a2(index - 1);
      a(5) = a2(index + 1);
      
%   figure(80)
%   plot(real(k(1)),a(1),'go')
%   plot(real(k(3)),a(3),'co')
%   plot(real(k(5)),a(5),'ro')
%   drawnow
    n_r2 = n_r2 + 1;
    end
end

% figure(80)
% plot(real(k1),min(a),'k*')

% figure(10)
% plot(w1/real(k1),min(a),'k*')   
% 
% figure(100)
% plot(w1/(2*pi),min(a),'k*')
% 
% n_r2
%n_r2;
