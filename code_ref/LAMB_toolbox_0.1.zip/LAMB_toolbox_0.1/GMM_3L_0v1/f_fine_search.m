function [k3,f3] = f_fine_search(Nl,d,Ro,Alfa,Beta,f_min,f_0,f_fs,c_ph_max,c_ph_0,c_ph_fs,delta_c_ph_limit,delta_f_limit,delta_k_r,delta_k_r_limit)
% This function performs the fine search over previous encountered starting points. 
% It returns final points in (freq./phase-speed plane) for curve tracing algorithm.
%
% Units:    
%                                       Frequency 'f' = [Hz]
%                             Mode phase-speed 'c_ph' = [m/s]
%     Long.& shear bulk-wave velocities 'Alfa'/'Beta' = [m/s]
%                                        Density 'ro' = [Kgr/m^3]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     16/06/2007   
% ver 2.0     10/07/2007   Two layered system added... Rayleigh velocity detection
% ver 3.0     31/07/2007   Attenuation curves tracing algorithm added.


disp('2. Starting points refinement  ->  Performing Fine search..')
% figure(80)
% hold
% grid

% figure(90)
% hold
% grid
% 
%--------------------------------------------------------------------------
% 1) Locate final points for 'c_ph' sweep.
 
    N1 = max(size(c_ph_0));    
c_ph_1 = zeros(N1,1);
c_ph_2 = zeros(N1,1);
    f1 = zeros(N1,1);
    f2 = zeros(N1,1);
    k1 = zeros(N1,1);
    k2 = zeros(N1,1);
    k3 = zeros(N1,1);
    k4 = zeros(N1,1);
for i = 1:N1
          %--------------------------------------------------------------------------
          % 1.1) Perform Fsearch 1st. step in 'attenuation' at constant 'frequency'.
            k0(i,1) = 2*pi*f_min/c_ph_0(i)      % Calculate wave vector for fixed frequency 'f_min'
  [k1(i,1),delta_k] = f_fsearch_1_atte_re(Nl,d,Ro,Alfa,Beta,delta_k_r,k0(i),f_min);

          % 1.2) Perform Fsearch 2nd. step in 'attenuation' at constant 'frequency'.
            k2(i,1) = f_fsearch_2_atte_re(Nl,d,Ro,Alfa,Beta,delta_k,delta_k_r_limit,k1(i),f_min);
            
          %--------------------------------------------------------------------------
          % 1.3) Perform Fsearch 1st. step in 'attenuation' at constant 'frequency'.
  [k3(i,1),delta_k] = f_fsearch_1_atte_im(Nl,d,Ro,Alfa,Beta,delta_k_r,k2(i),f_min);

          % 1.4) Perform Fsearch 2nd. step in 'attenuation' at constant 'frequency'.
            k4(i,1) = f_fsearch_2_atte_im(Nl,d,Ro,Alfa,Beta,delta_k,delta_k_r_limit,k3(i),f_min);
end
f1 = f_min*ones(N1,1);

%--------------------------------------------------------------------------
% 2) Locate final points for 'frequency' sweep at fixed phase velocity 'c_ph_max'
   k_0 = (2*pi/c_ph_max).*f_0;   % Corresponding 'k' vector at fixed 'c_ph_max'
   
if f_0 > 0
    N2 = max(size(f_0));
   f_1 = zeros(N2,1);
   f_2 = zeros(N2,1);
   k_1 = zeros(N2,1);
   k_2 = zeros(N2,1);
   k_3 = zeros(N2,1);
   k_4 = zeros(N2,1);
  
   for j = 1:N2
       %--------------------------------------------------------------------------
       % 2.1) Perform fine search 1st. step in 'frequency' sweep at constant 'c_ph'.
       [k_1(j),f_1(j)] = f_fsearch_1_fk(Nl,d,Ro,Alfa,Beta,k_0(j),f_0(j),f_fs);
       
       %--------------------------------------------------------------------------
       % 2.2) Perform 2nd. step in 'frequency' sweep at constant 'c_ph'.
       [k_2(j),f_2(j)] = f_fsearch_2_fk(Nl,d,Ro,Alfa,Beta,k_1(j),f_1(j),f_fs,delta_f_limit);
         
       %--------------------------------------------------------------------------
       % 2.3) Perform Fsearch 1st. step in 'attenuation' at constant 'frequency'.
    [k_3(j,1),delta_k] = f_fsearch_1_atte_re(Nl,d,Ro,Alfa,Beta,delta_k_r,k_2(j),f_2(j));

       %--------------------------------------------------------------------------
       % 2.4) Perform Fsearch 2nd. step in 'attenuation' at constant 'frequency'.
               k_4(j,1) = f_fsearch_2_atte_re(Nl,d,Ro,Alfa,Beta,delta_k,delta_k_r_limit,k_3(j),f_2(j));
               
       %--------------------------------------------------------------------------
       % 2.5) Perform fine search 1st. step in 'attenuation' at constant 'frequency'.
     [k_5(j,1),delta_k] = f_fsearch_1_atte_im(Nl,d,Ro,Alfa,Beta,delta_k_r,k_4(j),f_2(j));
                 
       %--------------------------------------------------------------------------
       % 2.6) Perform fine search 2nd. step in 'attenuation' at constant 'frequency'.
              k_6(j,1) = f_fsearch_2_atte_im(Nl,d,Ro,Alfa,Beta,delta_k,delta_k_r_limit,k_5(j),f_2(j));
   end
   k3 = [k4;k_6];    % Ensable final modes wave vector 'k3'
   f3 = [f1;f_2];    % Ensable final modes frequency vector 'f3'
else
    disp('No minimum point in frequency sweep to find...')
    k3 = k4;         % Ensable final modes wave vector 'k3'
    f3 = f1;         % Ensable final modes frequency vector 'f3'
end


