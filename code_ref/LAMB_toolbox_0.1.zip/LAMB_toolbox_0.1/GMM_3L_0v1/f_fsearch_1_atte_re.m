function [k,delta] = f_fsearch_1_atte_re(Nl,d,Ro,Alfa,Beta,delta_k_r,k,f)
%  This function performs the 1st. step of fine search in 'attenmuation'
%
% Units:    
%                                       Frequency 'f' = [Hz]
%                             Mode phase-speed 'c_ph' = [m/s]
%     Long.& shear bulk-wave velocities 'Alfa'/'Beta' = [m/s]
%                                        Density 'ro' = [Kgr/m^3]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     31/07/2007
% ver 2.0     11/08/2007    Algorithm error correction.
% ver 3.0     20/08/2007    Vectoriced version!

    n_r1 = 1;
%------------------------------------------------------------------
 delta_k = real(k)*delta_k_r;     % Atteuation step search size.
      k1 = [(k - delta_k); k; (k + delta_k)];
       w = 2*pi*f;
      w1 = w*ones(3,1);
    
 [det_S] = f_cal_determinant(3,Nl,d,w1,k1,Ro,Alfa,Beta);    % Calculate determiant at initial point
       a = log10(abs(det_S));

if (a(3) < a(2)) || (a(1) < a(2))
    %--------------------------------------------------------------------------
    % Choose direction of decreasing determinats. 
    if a(3) > a(1)
        delta =  -delta_k;  % The determinat decreses into the right (<-) see figure(10)
    elseif a(3) < a(1)
        delta =  delta_k;   % The determinat decreses into the left  (->) see figure(10)
    end    
    %--------------------------------------------------------------------------
    % Find minimun determinat 
    not_end = 1;
    while not_end
        k_n = k + delta;
  [det_S_n] = f_cal_determinant(1,Nl,d,w,k_n,Ro,Alfa,Beta);
        a_n = log10(abs(det_S_n));
        
        if a_n > a
          not_end = 0;
        else            
          k = k_n;    % Resume pointer to new value.
          a = a_n;   
       n_r1 = n_r1 + 1; 
               
%  figure(100)
%  plot(w/(2*pi),a_n,'ko')
%  drawnow

        end
    end
    %--------------------------------------------------------------------------
%     figure(80)
%     plot(real(k22),aa)
%     plot(real(k22),aa,'go')
%     plot(real(k22(n_r1)),aa(n_r1),'mo')
    
%     figure(10)
%     plot(w/real(k22(n_r1)),aa(n_r1),'ro')
    
%     figure(100)
%     plot(w/(2*pi),a,'ro')
%      n_r1
%      n_r1;
    %--------------------------------------------------------------------------    
else 
    %disp('"f_fsearch_1_atte_re"... Nothing to do!')
    %n_r1
    delta = delta_k;
end

    
    
    