function [Theta_1,K_1,F_1,Cph_1,Cg_1,Nf_1] = f_trace_modes(num_modes,N,Nl,d,Ro,Alfa,Beta,fs,f_max,f_fs,f_0,k_0,delta_k,delta_k_r,delta_k_r_limit,delta_f_limit)
%  This function performs the curve tracing algorithm for the Lamb modes of the system.
%
% Units:    
%                     Maximum modes phase-speed 'c_ph_max' = [m/s]
%                 Interpolation curves frequency step 'fs' = [Hz]
%                          Minimum modes frequency 'f_min' = [Hz]
%           Maximum frequency for Lamb curve modes 'f_max' = [Hz]
%                               Modes frequency vector 'f' = [Hz]
%              Fine search algorith frequency step  'f_fs' = [Hz]
%                             Modes wave number vector 'k' = [Rad/m]
%  Fix wave number increment for traccing curves 'delta_k' = [Rad/m]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     19/06/2007   
% ver 2.0     04/08/2007    Atenuation curves algorithm added.
% ver 3.0     27/08/2007    Interpolation algorithm + feature curves added:
%                           1)Phase & 2)Group velocity and 3)Angle of incidence.
% ver 3.0.1   15/01/2008    Add. returning of phase and group velocities.

figure(300); hold on; grid; xlabel('Frequency [Hz]'); ylabel('Phase velocity [m/s]');
figure(310); hold on; grid; xlabel('Frequency [Hz]'); ylabel('Wavenumber [Rad/m]'); 
figure(320); hold on; grid; xlabel('Frequency [Hz]'); ylabel('Attenuation = imag(K)');
figure(330); hold on; grid; xlabel('Frequency [Hz]'); ylabel('Angle of incidence [Deg�]');
figure(340); hold on; grid; xlabel('Frequency [Hz]'); ylabel('Group velocity [m/s]');

%--------------------------------------------------------------------------
  m_index = zeros(num_modes,1);
        K = zeros(N,num_modes);
        F = zeros(N,num_modes);
% 1) Find first '6' points in 'k,f' space for all detected Lamb modes.
disp('3.1. Calculating inicial points.')
[K(1:6,:),F(1:6,:)] = f_tmode_1_linear(num_modes,Nl,d,Ro,Alfa,Beta,f_fs,f_0,k_0,delta_k,delta_k_r,delta_k_r_limit,delta_f_limit);
d;
%--------------------------------------------------------------------------
% 2) Start curve points calculation from point '7' and so on...
disp('3.2. Tracing modes!..')
for m = 1:num_modes       
                 n = 7;   
    while (F(n-1,m) <= f_max) && (n < N+1)
                 f = F(n-6:n-2,m);     % Five point freq. vector. Oder from point  1 -> 5
                 k = K(n-6:n-2,m);
   [K(n,m),F(n,m)] = f_tmode_2_quad(Nl,d,Ro,Alfa,Beta,f_fs,f,k,delta_k,delta_k_r,delta_k_r_limit,delta_f_limit);   % Calculate remaining mode curve points.
                 n = n + 1;            % Increment pointer for next mode-curve value 'm'
    end
    m_index(m,1) = max(find(K(:,m)));  % Number of points of curve mode 'm'.
   m
end
%--------------------------------------------------------------------------
% 3) Interpolate curve modes.
disp('3.3. Interpolatating data points...')

    K_0 = cell(num_modes,1);   % Cell array for 'original' wavenumbers.
    F_0 = cell(num_modes,1);   % Idem for frequency points.
 Atte_0 = cell(num_modes,1);   % Idem for attenuation; units in: [%/mm].
  Cph_0 = cell(num_modes,1);   % Idem for phase velocity.
   Cg_0 = cell(num_modes,1);   % Idem for group velocity.
Theta_0 = cell(num_modes,1);   % Idem for incidence angle.
         
    K_1 = cell(num_modes,1);   % Cell array for "interpolated" wavenumbers.
    F_1 = cell(num_modes,1);   % Idem for frequency points.
 Atte_1 = cell(num_modes,1);   % Idem for attenuation; units in: [%/mm].
  Cph_1 = cell(num_modes,1);   % Idem for phase velocity.
   Cg_1 = cell(num_modes,1);   % Idem for group velocity.
Theta_1 = cell(num_modes,1);   % Idem for incidence angle.        
   Nf_1 = cell(num_modes,1);   % Number of freq. point for each mode.
   
for m = 1:num_modes
      F_0{m} = F(1:m_index(m),m); 
      K_0{m} = K(1:m_index(m),m);
%          a0 = -0.001*imag(K_0{m});                       % Conversion from: Nepers/m  -> Nepers/mm.
   Atte_0{m} = imag(K_0{m}); %1-(10.^(a0.*log10(exp(1))));               % Conversion from: Nepers/mm -> [%/mm].      
    Cph_0{m} = 2*pi.*F_0{m}./real(K_0{m});                % Calculate phase velocity.
     Cg_0{m} = (2*pi)*diff(F_0{m})./diff(real(K_0{m}));   % Obtain group velocity.
  k_medium_0 = (2*pi/Alfa(1)).*F_0{m};                    % Wavenumber vector for medium-1 .Eg. "air".
  Theta_0{m} = asin(real(K_0{m})./real(k_medium_0));      % Obtain incidence angle for mode 'm'.
  Theta_0{m} = (180/pi)*real(Theta_0{m});                 % Conversion from: Rad -> Deg�.
    
    f_min(m) = fs*(round(F(1,m)/fs));                     % Round to 'fs'Hz near value; new minimum freq. of mode 'm'.
      F_1{m} = (f_min(m):fs:f_max)';                      % Load cell array with frequecy vector.
      K_1{m} = interp1(F_0{m},K_0{m},F_1{m},'spline');    % Interpolate wavenumber mode 'm'.
%          a1 = -0.001*imag(K_1{m});                       % Conversion from: Nepers/m  -> Nepers/mm.
   Atte_1{m} = imag(K_1{m}); %1-(10.^(a1.*log10(exp(1))));               % Conversion from: Nepers/mm -> [%/mm].      
    Cph_1{m} = interp1(F_0{m},Cph_0{m},F_1{m},'spline');  % Calculate phase velocity.
     Cg_1{m} = (2*pi)*diff(F_1{m})./diff(real(K_1{m}));   % Calculate group velocity.
  k_medium_1 = (2*pi/Alfa(1)).*F_1{m};                    % Wavenumber vector for medium-1 .Eg. "air".
  Theta_1{m} = asin(real(K_1{m})./real(k_medium_1));      % Obtain incidence angle for mode 'm'.
  Theta_1{m} = (180/pi)*real(Theta_1{m});                 % Conversion from: Rad -> Deg�.
     Nf_1{m} = max(size(F_1{m}));                         % Calculate number of points for mode trace 'm'.
    
       resto = f_impar(m,2);
    if resto
        figure(300); plot(F_0{m},Cph_0{m},'bo'); plot(F_1{m},Cph_1{m},'g'); plot(F_1{m},Cph_1{m},'g.');
%        figure(300); plot(F_1{m},Cph_1{m},'b');
        
        figure(310); plot(F_0{m},real(K_0{m}),'bo'); plot(F_1{m},real(K_1{m}),'g'); plot(F_1{m},real(K_1{m}),'g.');
        figure(320); plot(F_0{m},Atte_0{m},'bo'); plot(F_1{m},Atte_1{m},'g'); plot(F_1{m},Atte_1{m},'g.');
        figure(330); plot(F_0{m},Theta_0{m},'bo'); plot(F_1{m},Theta_1{m},'g'); plot(F_1{m},Theta_1{m},'g.');
        f0 = F_0{m};  f0 = f0(2:m_index(m));
        f1 = F_1{m};  f1 = f1(2:Nf_1{m});        
        figure(340); plot(f0,Cg_0{m},'bo'); plot(f1,Cg_1{m},'g'); plot(f1,Cg_1{m},'g.');
    else
        figure(300); plot(F_0{m},Cph_0{m},'bo'); plot(F_1{m},Cph_1{m},'c'); plot(F_1{m},Cph_1{m},'c.');
%        figure(300); plot(F_1{m},Cph_1{m},'b');

        figure(310); plot(F_0{m},real(K_0{m}),'bo'); plot(F_1{m},real(K_1{m}),'c'); plot(F_1{m},real(K_1{m}),'c.');
        figure(320); plot(F_0{m},Atte_0{m},'bo'); plot(F_1{m},Atte_1{m},'c'); plot(F_1{m},Atte_1{m},'c.');
        figure(330); plot(F_0{m},Theta_0{m},'bo'); plot(F_1{m},Theta_1{m},'c'); plot(F_1{m},Theta_1{m},'c.');
        f0 = F_0{m};  f0 = f0(2:m_index(m));
        f1 = F_1{m};  f1 = f1(2:Nf_1{m});        
        figure(340); plot(f0,Cg_0{m},'bo'); plot(f1,Cg_1{m},'c'); plot(f1,Cg_1{m},'c.');
    end
    drawnow
end


m
m;

       
       

    
