function [k,delta_k] = f_fsearch_1_atte_im(Nl,d,Ro,Alfa,Beta,delta_k_r,k0,f0)
%  This function performs the 1st. step of fine search in 'attenuation'
%
% Units:    
%                                       Frequency 'f' = [Hz]
%                             Mode phase-speed 'c_ph' = [m/s]
%     Long.& shear bulk-wave velocities 'Alfa'/'Beta' = [m/s]
%                                        Density 'ro' = [Kgr/m^3]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     08/08/2007
% ver 2.0     15/08/2007    New version writen.
% ver 3.0     20/08/2007    Vectoriced version!

    n_i1 = 1;
   n_i11 = 1;
 not_end = 1;
 
       k = k0;
       w = 2*pi*f0;
%------------------------------------------------------------------
if imag(k0) == 0
           delta_k = real(k0)*delta_k_r;   % Calculate attenuation step search size.
          D_limit2 = delta_k/10000;         % Atte. mode search limit.
          while not_end
              w1 = [w;w];
              k1 = [(k + i*delta_k); (k + i*2*delta_k)];
           det_S = f_cal_determinant(2,Nl,d,w1,k1,Ro,Alfa,Beta); % Calculate determinant
               a = log10(abs(det_S));
              if a(2) < a(1)         % Minimum reatched?
                  k = k1(1);         % No, continue searching...
               n_i1 = n_i1 + 1;
              elseif a(2) >= a(1)    % Yes! 
                  if n_i1 > 1        % More than one iteration?
                            k = k1(1);       % Yes! Stop searching; absolute minimum reached! 
                      not_end = 0;   
                  elseif delta_k < D_limit2  % Minimum value of search atte. reached?
                          k = k0;            % Yes!! Then, stop search and assume no atte. value
                    delta_k = 0;             % if founded for this mode; return original 
                    not_end = 0;             % 'k' value.
                  else  
                    delta_k = delta_k/2;     % Decrease search step for new iteration...
                      n_i11 = n_i11 + 1; 
                  end            
              end
          end          
else
          %--------------------------------------------------------------------------    
          % Test direction of decreasing determinants
       delta = imag(k)*delta_k_r;               % Cal. attenuation step search size.
          k1 = [(k - i*delta); k; (k + i*delta)];
          w1 = [w;w;w];
     [det_S] = f_cal_determinant(3,Nl,d,w1,k1,Ro,Alfa,Beta);  % Calculate determinants
           a = log10(abs(det_S));
        
          if (a(2) < a(1)) && (a(2) < a(3))
                delta_k = delta;   % Yes! 
                not_end = 0;       % End search process; minimum reatched!
          elseif (a(3) < a(2)) && (a(3) < a(1)) % Direction? 
              delta_k = delta;     % Following...increasing 'k' values
              a_j_old = a(3);
                    k = k1(3);
          else
              delta_k = -delta;    % Following....decreasing 'k' values
              a_j_old = a(1);
                    k = k1(1);
          end
          %--------------------------------------------------------------------------
          % Find minimum determinant 
          while not_end
              k_j = k + i*delta_k;
              if imag(k) <= 0 
                  disp('Error:  "f_search_1_atte_im funtion" reach negative atte. value...')
                  disp('...decrease parameter:  delta_k ')
                  pause
              end
              [det_S_j] = f_cal_determinant(1,Nl,d,w,k_j,Ro,Alfa,Beta);
                    a_j = log10(abs(det_S_j));
              if a_j > a_j_old  % Next value > than previous?
                  delta_k = abs(delta);
                  not_end = 0;  % Yes! End search process; minimum reatched!
              else
                  k = k_j;      % Resume pointer for next value.
            a_j_old = a_j;   
               n_i1 = n_i1 + 1;
               
%  figure(100)
%  plot(w/(2*pi),a_j,'b+')
%  drawnow
              end
          end
end % End if-else
%--------------------------------------------------------------------------
% figure(90)
% plot(imag(k22(2:n_i1)),aa(2:n_i1))
% plot(imag(k22(2:n_i1)),aa(2:n_i1),'g+')
% plot(imag(k22(n_i1)),aa(n_i1),'r+')
%    
%det_S = f_cal_determinant(Nl,d,w,k,Ro,Alfa,Beta);
%    a = log10(abs(det_S));
% figure(10)
% plot(w/real(k),a,'r+')

% figure(100)
% plot(w/(2*pi),a,'r+')
%n_i1   
%n_i11


