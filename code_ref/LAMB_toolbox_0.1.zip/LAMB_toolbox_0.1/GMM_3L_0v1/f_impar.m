
function [resto_div] = f_impar(n,divisor)
% Funcion que devuelve '1' si el nro entrado es impar
% y '0' si es par.
%
% ver 1.0     23/10/2004
% ver 2.0     26/10/2004   Agregado divisor generico

resto_div = rem(n,divisor);   

% Obs. si 'divisor = 2' -> uso p/deteccion de num 'par' 'impar'
%      si distindo de 2 -> uso p/deteccion de divison exacta!
