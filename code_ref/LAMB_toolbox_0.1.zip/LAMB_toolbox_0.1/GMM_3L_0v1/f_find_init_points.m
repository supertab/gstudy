function [data,k_data] = f_find_init_points(data_s,det_S,alfa,beta)
%  This function locate the initial points (c_ph,f) from the coarse search 
% in the frequency/phase-speed plane for later tracing the mode curves.
%
% Units:    
%                                       Frequency 'f' = [Hz]
%                             Mode phase-speed 'c_ph' = [m/s]
%       Laminar material bulk wave speeds 'alfa/beta' = [m/s]
%
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     16/06/2007   
% ver 1.1     06/07/2007   Enhancement of end detection by: '&& (i < N1)'  at line 46
% ver 1.2     10/07/2007   No-init point detection added.

      N1 = max(size(det_S));
       b = abs(det_S);
%        [bm,bi] = min(b);
%        if b(bi) == 0
%            b = 10^-20;
%        end
       a = log10(b);
      aa = diff(a);

% figure(8)
% hold
% grid
% plot(aa,'g.')
% plot(aa,'b')
%       
% figure(10)
% hold
% grid
% plot(a,'b')
% plot(a,'g.')
      
      
p_margin = 0.98;             % Safe margin to not rich the end of vectors.
 not_end = 1;
   n_dev = 1;
       i = 1;
       n = 1;
while not_end && (i < N1)
    if (a(i) >= a(i+1)) && n_dev && not_end
             i = i + 1;      % Zone of negative derivative.
    elseif (a(i) < a(i+1)) && n_dev && not_end
        i_data(n) = i;       % Save index of starting curve point.
                n = n + 1;   % increase pointer for next value.
            n_dev = 0;       % Zone of derivative main change.
            if i+1 == N1
               not_end = 0;  % Terminate search!
            end
            i = i + 1; 
    elseif (a(i) < a(i+1)) && (~n_dev) && not_end
            while (aa(i) >=0) && ((i+1) < p_margin*N1)
                i = i + 1;   % Skip zone of positive derivative.
            end
            if i+1 >p_margin*N1
               not_end = 0;  % Terminate search!
            else
                n_dev = 1;         
            end
    elseif (a(i) >= a(i+1)) && (~n_dev) && not_end
            while (aa(i) < 0)  && ((i+1) < p_margin*N1)
                i = i + 1;   % Skip remaing possible negative derivative points.
            end
            while (aa(i) >=0)  && ((i+1) < p_margin*N1)
                i = i + 1;   % Skip next zone of positive derivative.
            end
            if i+1 > p_margin*N1
               not_end = 0;  % Terminate search!
            else
                n_dev = 1;         
            end
    end
    i;
end

n = max(size(i_data));
k = 1;
for i = 1:n
    % Select mode init points, only those different from bulk speeds and 1st data available.
    if (data_s(i_data(i)) ~= alfa) && (data_s(i_data(i)) ~= beta) && (data_s(i_data(i)) ~= data_s(1) )
        data(k,1) = data_s(i_data(i));  % ok! mode starting point selected.
      k_data(k,1) = i_data(i);
        k = k + 1;
    end
end

if k == 1
    data = 0;
    k_data = 1;
end




    
    
    
    