function [Alfa,Beta,ro] = f_mat_properties(Nl,material)
% This function return the longitudinal (Alfa) and shear (Beta)
% bulk wave velocities for the selected materials, with its densities.
% Obs. for the moment only few materials are at disposal.
%
% Units:    
%     Long.& shear bulk-wave velocities 'Alfa'/'Beta' =  [m/s]
%                                        Density 'ro' = [Kgr/m^3]
%                           Lame-consts: 
%                                            'lambda' = c12 [Pa]
%                                                'mu' = c44 [Pa] 
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     15/06/2007
% ver 2.0     01/09/2007    Attenuation effect added for some materials...
% ver 2.1     19/11/2007    Fused silica & YAG added.
% ver 2.2     10/03/2009    Copper mat. added.


  Alfa = zeros(Nl,1);
  Beta = zeros(Nl,1);
    ro = zeros(Nl,1);
lambda = zeros(Nl,1);
    mu = zeros(Nl,1);

for n = 1:Nl
    switch material(n)
        case 0 % Vacuum ---------------------------------------
            ro(n) = 1*10^-12;     % Density in [Kgr/m^3]
        lambda(n) = 2*10^-12;     % Lame constant in [Pa]
            mu(n) = 1*10^-12;     % Lame constant in [Pa
        
        case 1 % Air -----------------------------------------
            ro(n) = 1.194764;     % [Kgr/m^3] at: 21�;50%;1013.25 hPa
             alfa = 343.809;      % [m/s]     at: 21�;50%;1013.25 hPa
             beta = 1*10^-12;     % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]

        case 2 % Water ---------------------------------------
            ro(n) = 1000;         % [Kgr/m^3]
             alfa = 1483;         % [m/s]
             beta = 0.01;         % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]
        
       case 3 % Titanium -------------------------------------
            ro(n) = 4460;         % [Kgr/m^3]
             alfa = 6060;         % [m/s]
             beta = 3230;         % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]

       case 4 % Steel ----------------------------------------
            ro(n) = 7930;         % [Kgr/m^3]
             alfa = 5960;         % [m/s]
             beta = 3230;         % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]

       case 5 % Aluminium ------------------------------------
            ro(n) = 2620.4 %2700;               % [Kgr/m^3]
             alfa = 6370 %+ i*0.0638;    % [m/s]
             beta = 3170 %+ i*0.031;     % [m/s]
             mu_r = ro(n)*((real(beta)^2)-(imag(beta)^2));   
             mu_i = -2*ro(n)*real(beta)*imag(beta);
            mu(n) = mu_r + i*mu_i;      % [Pa]
         lambda_r = ro(n)*((real(alfa)^2) - (imag(alfa)^2) - 2*(real(beta)^2) - 2*(imag(beta)^2));  % [Pa]
         lambda_i = -2*ro(n)*((real(alfa)*imag(alfa)) - (real(beta)*imag(beta)));
        lambda(n) = lambda_r + i*lambda_i;
        
       case 6 % Epoxy ---------------------------------------
            ro(n) = 1170;         % [Kgr/m^3]
             alfa = 2610;         % [m/s]
             beta = 1100;         % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]
     
       case 7 % Gold ----------------------------------------
            ro(n) = 19488;        % [Kgr/m^3]
             alfa = 3217;         % [m/s]
             beta = 1195;         % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]
     
       case 8 % Fused quartz --------------------------------
            ro(n) = 2197;         % [Kgr/m^3]
             alfa = 5968;         % [m/s]
             beta = 3764;         % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]
        
       case 9 % Fused silica --------------------------------
              c11 = 7.85*10^10;   % [Pa]
              c44 = 3.12*10^10;   % [Pa]
            ro(n) = 2200;         % [Kgr/m^3]
            mu(n) = c44;          % [Pa]
        lambda(n) = c11 - 2*c44;  % [Pa]
        
       case 10 % YAG (Ittrium Aluminum Garnet)---------------
            ro(n) = 4550;         % [Kgr/m^3]
            mu(n) = 11.05*10^10;  % [Pa]
        lambda(n) = 11.07*10^10;  % [Pa]
        
       case 11 % Copper -------------------------------------
               % Copper data: density = 8930 kg/m^3;    Vl = 5010 m/s;    Vsh = 2200 m/s 
            ro(n) = 8930;         % [Kgr/m^3]
             alfa = 5010;         % [m/s]
             beta = 2270; %2200;  % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]          
        
       otherwise
            disp('Material type not defined yet...')
            pause
       end
       
   [Alfa(n),Beta(n)] = f_bulk_v(ro(n),lambda(n),mu(n));
end



%-----------------------------------------------------
% Test code 4 different: alfa, beta & density.
% Valores actuales:
   alfa = Alfa(2)
   beta = Beta(2)
 lambda = lambda(2)
     mu = mu(2)
    r_o = ro(2)
  sigma = lambda/(2*(lambda + mu))
      E = (beta^2)*2*r_o*(1+sigma)

% % De hojas de datos:
%     E_2 = 69000*10^6   % De la hoja de datos de Servicio estacio.
% sigma_2 = 0.355        % Del Kino.
%     r_o = 2700         % Del Kino & Servicio estacio.
%  alfa_2 = sqrt((E_2*(1-sigma_2))/(r_o*(1+sigma_2)*(1-2*sigma_2)))
%  beta_2 = sqrt(E_2/(2*r_o*(1+sigma_2)))
% 
%1;





