function [m_delta_k] = f_test_m_delta_k(Nl,d,Ro,Alfa,Beta,k0,f0,f_fs,delta_f_limit,delta_k,m_delta_k)
%  This function make's a previous test of the sub-increment 'm_delta_k',
%  in order to not have later excesive gradient changes.
%
% Units:    
%                          Coarse frequency point 'f' = [Hz]
%                          Frequency fine step 'f_fs' = [Hz]
%                             Mode phase-speed 'c_ph' = [m/s]
%     Long.& shear bulk-wave velocities 'Alfa'/'Beta' = [m/s]
%                                        Density 'ro' = [Kgr/m^3]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     26/06/2007   


     k0 = k0 + m_delta_k;  % Increment in wave vector in a 'milli_k' step
%--------------------------------------------------------------
% Frequency search in neighboring point (k + m_delta_k)
     f1 = f_fsearch_1_fc(Nl,d,Ro,Alfa,Beta,k0,f0,f_fs);
     f2 = f_fsearch_2_fc(Nl,d,Ro,Alfa,Beta,k0,f1,f_fs,delta_f_limit);
        
 f_grad = (f2 - f0)/m_delta_k;      % Test gradient at this point.
delta_f = f_grad*delta_k;           % Calculate jump in frequency..

if abs(delta_f) >= 0.2*f0           % If jump to excesive ->  change value of 'm_delta_k'
   disp('Increasing:  m_delta_k  <-  delta_k ')
   m_delta_k = delta_k;
end
