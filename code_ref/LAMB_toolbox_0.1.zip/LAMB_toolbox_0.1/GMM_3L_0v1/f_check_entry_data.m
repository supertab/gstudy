function [ok] = f_check_entry_data(Nl,f_min,f_max,f_cs,c_ph_min,c_ph_max,c_ph_cs,f_fs,c_ph_fs,delta_c_ph_limit,delta_f_limit)
% This function ensables the Global matrix 'S' of the method. See Ref.(1) in main.
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0    05/06/2007   

if Nl < 2
    disp('Error_1: Layered system should have 2 or more layers.')
    ok = 0;
    pause
elseif (f_min <= 0) || (f_max <= 0) || (f_cs <= 0) || (f_fs <= 0) || (delta_f_limit <= 0)
    disp('Error_2: Frequencies should not be zero or negative..')
    ok = 0;
    pause
elseif (c_ph_min <= 0) || (c_ph_max <= 0) || (c_ph_cs <= 0) || (c_ph_fs <= 0) || (delta_c_ph_limit <= 0)
    disp('Error_3: Phase velocities should not be zero or negative...')
    ok = 0;
    pause
elseif (f_max <= f_min)
    disp('Error_4.1: Maximum freq. should be grater than minimum....')
    ok = 0;
    pause
elseif  (f_min < f_cs)
    disp('Error_4.2: Minimum frequency should be equal or grater than freq. step size....')
    ok = 0;
    pause
elseif (c_ph_max <= c_ph_min)
    disp('Error_5.1: Maximum phase speed should be grater than minimum.....')
    ok = 0;
    pause
elseif (c_ph_min < c_ph_cs)
    disp('Error_5.2: Minimum phase speed should be equal or grater than speed step size.....')
    ok = 0;
    pause    
elseif (f_cs < delta_f_limit)
    disp('Error_6: "Delta_f_limit" should be lower than coarse freq. sweep "step size"')
    ok = 0;
    pause
elseif (c_ph_cs < delta_c_ph_limit)
    disp('Error_7: "Delta_cph_limit" should be lower than coarse phase speed sweep "step size"')
    ok = 0;
    pause
end

ok = 1;






