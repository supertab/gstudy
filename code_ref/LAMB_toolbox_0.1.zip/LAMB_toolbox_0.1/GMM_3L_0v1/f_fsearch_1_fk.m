function [k1,f1] = f_fsearch_1_fk(Nl,d,Ro,Alfa,Beta,k,f,f_fs)
%  This function performs the 1st. step of fine search in a 'frequency'
% sweep at constant phase velocity: 'c_ph_max'.
%  The final notation '_fk' means that the frequency and wavenumber
% are variated; keeping the phase velocity (c_ph) constant.
%
% Units:    
%                          Coarse frequency point 'f' = [Hz]
%                          Frequency fine step 'f_fs' = [Hz]
%                             Mode phase-speed 'c_ph' = [m/s]
%     Long.& shear bulk-wave velocities 'Alfa'/'Beta' = [m/s]
%                                        Density 'ro' = [Kgr/m^3]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     16/06/2007   
% ver 2.0     19/06/2007    Change input parameter:  c_ph -> k
% ver 3.0     20/08/2007    Vectoriced version!

%------------------------------------------------------------------
% Sweep in frequency at fixed phase velocity 'c_ph_max'

    w_fs = 2*pi*f_fs;
       w = 2*pi*f;
c_ph_max = w/k;         % Constant phase velocity [m/s]

      w1 = [(w - w_fs); w; (w + w_fs)];
      k1 = w1/c_ph_max;
 [det_S] = f_cal_determinant(3,Nl,d,w1,k1,Ro,Alfa,Beta);    % Calculate determinant at initial points
       a = log10(abs(det_S));

%--------------------------------------------------------------------------
% Choose direction of decreasing determinats. 
    if a(1) < a(3)
        delta = -w_fs;    % The determinat decreses into the right (<-) see figure(10)
        a_old = a(1);
    elseif a(3) < a(1)
        delta =  w_fs;    % The determinat decreses into the left  (->) see figure(10)
        a_old = a(3);
    elseif a(1) == a(3);
        disp('Ops! Troubles in  "f_fsearch_1_fk"  function...')
        disp('Absolute val. of determinants are iqual at distinct locations during fine search.')
        pause        
    end    
%--------------------------------------------------------------------------
% Find minimun determinat 
       n_f1 = 2;
    not_end = 1;
    while not_end        
             k_j = (w + n_f1*delta)/c_ph_max;
       [det_S_j] = f_cal_determinant(1,Nl,d,(w + n_f1*delta),k_j,Ro,Alfa,Beta);
             a_j = log10(abs(det_S_j));
        if a_j > a_old
              k1 = k;
              f1 = (c_ph_max*k1)/(2*pi);    % Conversion to frequency.
         not_end = 0;
        else            
            k = k_j;         % Resume pointer to new value.
        a_old = a_j;
         n_f1 = n_f1 + 1;
% f1 = (c_ph_max*k_j)/(2*pi);  % Conversion to frequency.
% figure(100)
% plot(f1,a,'c.') 
        end
    end
%--------------------------------------------------------------------------
% figure(100)
% plot(f1,a,'b.')
% 
% n_f1
% n_f1;







    
    
    