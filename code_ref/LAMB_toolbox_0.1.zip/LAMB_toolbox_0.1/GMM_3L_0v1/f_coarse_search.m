function [c_ph_ini,f_ini] = f_coarse_search(Nl,d,f,c_ph,Alfa,Beta,Ro) 
%  This function search and returns the starting points in the frequency/phase-speed plane,
% for tracing mode curves.
%
%
% Units:    
%                                       Frequency 'f' = [Hz]
%                             Mode phase-speed 'c_ph' = [m/s]
%     Long.& shear bulk-wave velocities 'Alfa'/'Beta' = [m/s]
%                                        Density 'ro' = [Kgr/m^3]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     15/06/2007   
% ver 2.0     20/08/2007    Vectoriced version!


disp('1. Looking for starting curve points  ->  Coarse search.')
%--------------------------------------------------------------------------
% 1) Coarse search_1
%    Velocity sweep at constant frequency. 'c_ph' = Lamb waves phase velocity

  c_ph_s = (c_ph(1):c_ph(3):c_ph(2))';  % Sweep in 'c_ph'
      N1 = max(size(c_ph_s));           % Number of points in phase velocity sweep.
       w = 2*pi*f(1)*ones(N1,1);        % Constant 'freq.'
      k1 = w./c_ph_s;                   % Wavevector component in 'x1' direction (parallel to plate). [rad/m]
  det_S1 = f_cal_determinant(N1,Nl,d,w,k1,Ro,Alfa,Beta);
      a1 = log10(abs(det_S1));

%--------------------------------------------------------------------------
% 2) Coarse search_2
% Frequency sweep at constant maximum speed: 'c_ph_max'.

     f_s = (f(1):f(3):f(2))';           % Sweep in freq. [Hz]
      N2 = max(size(f_s));              % Number of points in frequency sweep.
       w = 2*pi*f_s;      
      k1 = w/c_ph(2);                   % Wavevector component in 'x1' direction at maximum 'c_ph' (parallel to plate). [rad/m]            
  det_S2 = f_cal_determinant(N2,Nl,d,w,k1,Ro,Alfa,Beta);
      a2 = log10(abs(det_S2));

%--------------------------------------------------------------------------
% 3) Find the location of inicial curve points
[c_ph_ini,i_c_ph] = f_find_init_points(c_ph_s,det_S1,Alfa(2),Beta(2));
      [f_ini,i_f] = f_find_init_points(f_s,det_S2,Alfa(2),Beta(2));

%--------------------------------------------------------------------------
% 4) Figures ploting

% figure(10)
% hold
% grid
% plot(c_ph_s,a1,'b')
% plot(c_ph_s,a1,'g.')
% plot(c_ph_s(i_c_ph),a1(i_c_ph),'ro')
% 
% figure(100)
% hold
% grid
% plot(f_s,a2,'b')
% plot(f_s,a2,'c.')
% plot(f_s(i_f),a2(i_f),'ro')
% drawnow


% figure(20)
% hold
% grid
% plot(real_S1,imag_S1,'b')
% plot(real_S1,imag_S1,'g.')
% 
% figure(200)
% hold
% grid
% plot(real_S2,imag_S2,'b')
% plot(real_S2,imag_S2,'g.')



