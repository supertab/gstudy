function [Dm] = f_ensamble_Dm_matrix(N,type,x2,w,k1,ro,alfa,beta)
% This function ensables the field matrix 'D_plus' of the method. See Ref.(1) in main.
% Where:    
%                  Dm = D_minus
%                type = 0 -> use D_top
%                     = 1 -> use D_bottom
%       
%  Lame-consts. units = [Pa] 
%        Density (ro) = [Kgr/m^3]
%           alfa/beta = Long. & shear bulk wave velocities [m/s].
%                  x2 = Layer through thickness dimension vector [mm].
%                   s = Snell constant = sin(theta_L)/alfa = sin(theta_S)/beta.
%                   w = frequency vector!   Dimension = 1 x 1 x N.
%                  k1 = wavenumber vector!  Dimension = 1 x 1 x N.
%                   N = number of elements of vector 'w' and 'k1'.
%
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     05/06/2007   
% ver 1.01    13/06/2007    Cambio de signos en matrices segun T.P.Pialucha
% ver 1.02    14/06/2007    Cambio de signos en matrices segun J.L.Prego-Borges
% ver 1.03    15/06/2007    Uso de matrices s/paper Lowe
% ver 2.0     20/08/2007    Vectoriced version!

     Dm = zeros(4,2,N);

 C_alfa = sqrt(((w./alfa).^2) - (k1.^2));
 C_beta = sqrt(((w./beta).^2) - (k1.^2));
 g_alfa = exp(i*C_alfa.*x2);
 g_beta = exp(i*C_beta.*x2);
      B = (w.^2) - 2*(beta^2).*(k1.^2);
      
switch type
    case 0
        %------------------------------------------     
        % Dm_top
        disp('Ups! Attempting to use commented code...')
        disp('in function:  f_ensamble_Dm_matrix')
        pause
        
%         Dm(1,1) = k1*g_alfa;
%         Dm(2,1) = -C_alfa*g_alfa;
%         Dm(3,1) = i*ro*B*g_alfa;
%         Dm(4,1) = -2*i*ro*k1*(beta^2)*C_alfa*g_alfa;
% 
%         Dm(1,2) = -C_beta*g_beta;
%         Dm(2,2) = -k1*g_beta;
%         Dm(3,2) = 2*i*ro*k1*(beta^2)*C_beta*g_beta;
%         Dm(4,2) = i*ro*B*g_beta;
        
    case 1
        %------------------------------------------     
        % Dm_bottom
        Dm(1,1,:) = k1;
        Dm(2,1,:) = -C_alfa;
        Dm(3,1,:) = (i*ro).*B;
        Dm(4,1,:) = (-2*i*ro*(beta^2)*C_alfa).*k1;

        Dm(1,2,:) = -C_beta;
        Dm(2,2,:) = -k1;
        Dm(3,2,:) = (2*i*ro*(beta^2)*C_beta).*k1;
        Dm(4,2,:) = (i*ro).*B;
        
    otherwise
        disp('Error type in "Dm" matrix.  Only "0" or "1" alowed!! ')
        pause
end




