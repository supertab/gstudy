function [k_0,f_0] = f_tmode_1_linear(Nm,Nl,d,Ro,Alfa,Beta,f_fs,f,k,delta_k,delta_k_r,delta_k_r_limit,delta_f_limit)
%  This function performs the curve tracing algorithm for the Lamb modes of the system.
%
% Units:    
%                        Maximum modes phase-speed 'c_ph_max' = [m/s]
%                             Minimum modes frequency 'f_min' = [Hz]
%                                  Modes frequency vector 'f' = [Hz]
%                Fine search algorithm frequency step  'f_fs' = [Hz]
%                                 Modes wavenumber vector 'k' = [rad/m]
%  Real fix wavenumber increment for tracing curves 'delta_k' = [rad/m]
%
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     19/06/2007   
% ver 1.1     26/06/2007    Make a test of 'm_delta_k' previous of using it...
% ver 2.0     04/08/2007    Atenuation curves algorithm added.
% ver 3.0     19/08/2007    Core simplification...search in k-imaginary part abandoned!


init_points = 4 + 6             % Number of eliminated first points (minimum is '6').
        f_0 = zeros(init_points,Nm);
        k_0 = zeros(init_points,Nm);
%--------------------------------------------------------------------------
% 1) Find 1st. 6 points in 'k,f' space for all detected Lamb modes.
for m = 1:Nm  
   m_delta_k = 0.0005*delta_k;  %0.001  % Infinitesimal extrapolation increment
   
    f_0(1,m) = f(m);            % Save first point previously encontered
    k_0(1,m) = k(m);
    
       m_delta_k = f_test_m_delta_k(Nl,d,Ro,Alfa,Beta,k_0(1,m),f_0(1,m),f_fs,delta_f_limit,delta_k,m_delta_k);
    for n = 2:init_points
        %--------------------------------------------------------------
        % Calculate the remaining 5 points for extrapolation scheme.
        k_0(n,m) = k_0(n-1,m) + m_delta_k;  % Increment wavevector in a 'milli_k' step 
        f_0(n,m) = f_0(n-1,m);              %(Real part of the wavenumber). 
        %--------------------------------------------------------------
        % Start frequency search at neighboring point (k + m_delta_k)
             f_1 = f_fsearch_1_fc(Nl,d,Ro,Alfa,Beta,k_0(n,m),f_0(n,m),f_fs);
             f_2 = f_fsearch_2_fc(Nl,d,Ro,Alfa,Beta,k_0(n,m),f_1,f_fs,delta_f_limit);
             
        %--------------------------------------------------------------
        % Start attenuation search at neighboring point (k + m_delta_k)
          f_grad = (f_2 - f_0(n-1,m))/m_delta_k;  % Compute frequency gradient at point.
       delta_f_0 = f_grad*delta_k;                % Calculate corresponding jump in frequency.         
       
            f_00 = f_0(n-1,m) + delta_f_0;        % Actualize aproximate freq. point for: 'k + delta_k' value.
            k_00 = k_0(n-1,m) + delta_k;          % Save & jump wavevector for new point in 'k,f' space.
        
        %--------------------------------------------------------------
        % Find final freq. value by freq. search at: 'k + delta_k'
            f_11 = f_fsearch_1_fc(Nl,d,Ro,Alfa,Beta,k_00,f_00,f_fs);
            f_22 = f_fsearch_2_fc(Nl,d,Ro,Alfa,Beta,k_00,f_11,f_fs,delta_f_limit);
        %--------------------------------------------------------------
        % Find final wavenumber value by w.num. search at: 'k + delta_k'
 [k_11,delta_11] = f_fsearch_1_atte_im(Nl,d,Ro,Alfa,Beta,delta_k_r,k_00,f_22);
            k_22 = f_fsearch_2_atte_im(Nl,d,Ro,Alfa,Beta,delta_11,delta_k_r_limit,k_11,f_22);

        f_0(n,m) = f_22;  % Save final freq. value.
        k_0(n,m) = k_22;  % Save final w.num.value.
      end        
c_ph = (2*pi).*f_0(:,m)./real(k_0(:,m));
figure(300)
plot(f_0(:,m),c_ph)
plot(f_0(:,m),c_ph,'r.')
plot(f_0(1,m),c_ph(1),'ko')
drawnow

%         a = -0.001*imag(k_0(:,m));        % Conversion from: Nepers/m  -> Nepers/mm.
% atte_mode = 1-(10.^(a.*log10(exp(1))));   % Conversion from: Nepers/mm -> [%/mm].      
  atte_mode = imag(k_0(:,m));

figure(320)
plot(f_0(:,m),atte_mode,'b')
plot(f_0(:,m),atte_mode,'r.')
plot(f_0(1,m),atte_mode(1),'ko')
drawnow
m
end
%--------------------------------------------------------------------------
% Return the last 6-points only.
f_0 = f_0(init_points-5:init_points,:);
k_0 = k_0(init_points-5:init_points,:);
%--------------------------------------------------------------------------

    
