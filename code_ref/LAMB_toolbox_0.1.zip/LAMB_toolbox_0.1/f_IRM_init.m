function [et,Ps] = f_IRM_init(baffle,T_amb,Hr,P,theta,Nt,Nx2,Ny2,a,b,P_field_2,X2,Y2,z2,S_z,fs_IRM,t3,N3,f3,f_s3,Nf3,theta_3,r3_type,X3,Y3,Z3,f_D)
% This function computes the acoustic field signals (Ps) into a reception region for a given emission surface 
% with signals 'S_z'; based on the Impulse Response Method (IRM).
% It is based on the work: "Diffraction impulse response of rectangular transducers"
%                    from:  J.L.San Emeterio & L.Ullate {J.Acoust.Soc.Am. 92(2) (August 1992)}.
%
% Parameters:
%                 baffle = 0 -> Riggid-Baffle. Type of emission surface.
%                          1 -> Soft-Baffle. 
%                  T_amb = Ambient temperature [C�].
%                     Hr = Relative humidity [%].
%                      P = Atmospheric pressure [Pa].
%                  theta = Incident/reception field angle (rotation through Y-axis) in [Deg].
%                     Nt = Number of incident angles (theta) of THS excitation field.
%                Nx2,Ny2 = Number of points of emission field.
%                  2a,2b = Width & high of emission elements.
%              P_field_2 = Central point coords. on emission field [m].
%             X2,Y2 & z2 = Coordinates of emission points [m]. 'z2' goes no in lower case letter because it's just a scalar.
%                    S_z = IRM input data-cell array:  S_z = cell{Nt,num_modes}(Nx,Ny,N);
%                 fs_IRM = Sampling frequency for IRM [Hz].
%                     t3 = Time signal's vector [s].
%                     N3 = Number of points in signals.
%                     f3 = Frequency signal's vector [Hz].
%                   f_s3 = Frequecny sptep of signal's vector [Hz].
%                    Nf3 = Number of frequencies.
%                theta_3 = Reception's aperture orientation angle [Deg].
%                r3_type = Type of reception region:
%                          0. "Rectangular" regions; this include: single point; line and plane (Plane).
%                          1. Square/Rectangular circle filled (Plane).
%                          2. Circular/Ellipse circle filled (Plane).
%                          3. Cylindrical/spherical Shell!
%             X3,Y3 & Z3 = Coordinates of reception field region [m].
%                    f_D = 2D-directivity filter approximation.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
%
% ver 1.0    31/12/2008     Using IRM-2D core from: 'Main_FIRST_2D_2v3' (17/04/2008)
% ver 2.0    08/01/2009     Change on reception field dimensions: [Nx Ny]=size(X_field_2) --> S_z = zeros(Nx,Ny,N)
% ver 2.1    12/01/2009     Use of core routine: 'f_IRMc_IR_RB_point_fast' v6.4 @12/01/2009 to improve speed!
% ver 2.2    28/01/2009     Reception elements directivity model added.
% ver 2.3    08/02/2009     D-model deactivated until re-study...
% ver 2.4    19/01/2010     Use of D-filter model!

 theta_3r = theta_3*pi/180;
     pi_2 = pi/2;
[Nx3 Ny3] = size(X3);
   t3_max = max(t3);
      s_a = zeros(N3,1);
     Ps_k = zeros(Nx3,Ny3,N3);
       Ps = cell(Nt,1);  % -> Ps_k = zeros(Nx3,Ny3,N3);
        X = zeros(Nx2,Ny2);  Y = zeros(Nx2,Ny2);  Z = zeros(Nx2,Ny2);
        D = 1;           % If not selected use Omnidirectional directivity 4 reception elements!
%---------------------------------------------------------
% Calculate: speed & attenuation of sound and air density. 
% Data express in:  m/s, dB/m y Kg/m3 respectively.
[c,atte_air_dB,ro] = f_cal_air_properties(T_amb,Hr,P,f3);
             f_min = min(f3);
             f_max = max(f3);
                Nf = max(size(f3));
             i_min = round((f_min/f_s3)+1); % Index of 1st. non null filter value.
                 A = zeros(N3,1);
             total = Nt*Nx2*Ny2;            
%---------------------------------------------------------
% Load data for Directivity filter. 
if (f_D==1) && (f_max <=1.5*10^6)
    disp(' IRM D-filter On @1mm!');
    load matlab_data_Directivity_filter_a2_1mm_R_35mm_0�5_10kHz__0MHz5_1MHz5.mat
    D_M = sqrt(D_E);  clear D_E;   D = zeros(N3,1);
elseif (f_D==2) && (f_max <=1.5*10^6)
    disp(' IRM D-filter On @2mm!');
    load matlab_data_Directivity_filter_a2_2mm_R_35mm_0�5_10kHz__0MHz5_1MHz5.mat    
    D_M = sqrt(D_E);  clear D_E;   D = zeros(N3,1);
else
    disp('(o_o) Warning: Directivity Off...');
    if f_max > 1.5*10^6
        fprintf('      D.filter deactivated f_max = %.1f > 1.5MHz limit! \n',f_max/10^6);  f_D = 0;
    end
end
%---------------------------------------------------------
             
             
if baffle == 0   
    %---------------------------------------------------------------------------------------------------------------
    % Calulos p/Rigid-Baffle
    %---------------------------------------------------------------------------------------------------------------
    disp('2.7 Starting IRM for Rigid-Baffle: 1 -> All phylosophy... :) ');   
    for k2 = 1:Nt                       % S_z = cell{Nt,num_modes}(Nx,Ny,N);
        fprintf('theta = %.1f�     ',theta(k2))
        Ps{k2,1} = zeros(Nx3,Ny3,N3);
          p_done = 0;    n = 0;
        %-----------------------------------------------------------------------------------------           
        % Begin sweeping plate's emission elements (centered on P_field_2).
        for i2 = 1:Nx2
            for j2 = 1:Ny2       
                n = n + 1;  fprintf('%02i',p_done); % Start percentage job counter.
                %---------------------------------------------------------------           
                % Adapt reception coodinates for emission element (i2,j2).
                %  d1 = norm([X2(i2,j2) Y2(i2,j2) z2] - P_field_2);
                X = X3 - X2(i2,j2);     % Translate coords. from: O2[X(i2,j2) ;Y(i2,j2)] --> O2' (center in O2'(0,0)).
                Y = Y3 - Y2(i2,j2);
                Z = Z3 - z2;
         s_a(:,:) = S_z{k2,1}(i2,j2,:); % Extract aceleration signal for active emission element.         
                %---------------------------------------------------------------
                % Sweep reception region (centered on P_field_3) calculating 'n-esim' plane signals 'Ps'!
                % 1 -> All phylosophy --> Actual plate-emission element [X2(i2,j2) Y2(i2,j2) z2].
                for i3 = 1:Nx3
                    for j3 = 1:Ny3
                        % 2 Current field reception point = [X3(i3,j3) Y3(i3,j3) Z3(i3,j3)].
                                h = zeros(N3,1);                                % Reserve memory 4 IR-vector. Do not change of place this line!
                        [zone,R3] = f_cal_zone(X(i3,j3),Y(i3,j3),Z(i3,j3),a,b); % Distance from actual reception point to active emission element [m].
                        %------------------------------------------------                       
                        % Construct attenuation filter.
                          atte = 10.^(R3.*atte_air_dB./20);                   % Calculate corresponding atte. to distance R3 [ratio].
                                  A(i_min:Nf3+i_min-1,1) = atte(1:Nf3,1);     % Main part (0:f_s3:fs2/2).
                         A(N3-i_min-Nf3+3 :N3-i_min+2,1) = atte(Nf3:-1:1,1);  % Complementary frequencies (fs2/2:f_s3:fs).
                        %------------------------------------------------
                        % If Directivity activated -> calculate sensor's directivity.
                        if f_D
                            beta_r = atan((X3(i3,j3) - X2(i2,j2))/Z3(i3,j3)); % Incoming wavefront (WF)angle from point [X2(i2,j2) Y2(i2,j2) Z2(i2,j2)].
                            if r3_type == 3,       alfa_r = atan((X3(i3,j3) - P_field_2(1))/Z3(i3,j3));% Sensor's face inclination angle.
                            elseif (r3_type == 0) && (theta_3r >=0)
                                alfa_r = theta_3r; % Source direction pointing -> alfa_r >0
                            elseif (r3_type == 0) && (theta_3r <0)
                                alfa_r = theta_3r; fprintf('(o_o) Warning: array disorientated...\n'); 
                            else                   fprintf(':( Error: D-filter not defined for r3_type = %i\n',r3_type); error(' ');
                            end
                            delta = (beta_r - alfa_r)*(180/pi);               % Final sensor's incident WF angle. 
                           % [beta_r*180/pi alfa_r*180/pi delta]
                           %------------------------------
                           % Construct directivity filter.
                           M = interp2(F,Delta,D_M,f3,delta*ones(Nf,1)); % Interpolated directivity response @delta.
                           D(i_min:Nf+i_min-1,1) = M(1:Nf,1);            % Filter's Main part (0:f_s:fs/2).
                           D(N3-i_min-Nf+3:N3-i_min+2,1) = M(Nf:-1:1,1); % Complementary frequencies (fs/2:f_s:fs).
                           %------------------------------
                           A = A.*D;
                        end                                                 
                        %------------------------------------------------
                        % Calculate impulse response (w/fast code!) & pressure signal.
                        h = f_IRMc_IR_RB_point_fast ([X(i3,j3) Y(i3,j3) Z(i3,j3)],a,b,c,t3,h,N3,zone,t3_max);
                        ps = (ro/fs_IRM)*f_conv_met2(N3,h,s_a,A); % Calculate & store final pressure signal [Pa].
                        if sum(isnan(ps))
                            [X3(i3,j3) Y3(i3,j3) Z3(i3,j3)]
                            [X2(i3,j3) Y2(i3,j3) z2]
                        end
                        Ps_k(i3,j3,:) = ps;
                    end
                end
                %---------------------------------------------------------------
                % Reception field superposition acumulator.
                % Ovelap & stores field data for emission element (i2,j2).
                Ps{k2,1} = Ps{k2,1} + Ps_k(:,:,:);                  
                    Ps_k = zeros(Nx3,Ny3,N3);   % Clear auxiliar buffer.
                %---------------------------------------------------------------                
                p_done = round((Nt*n*100)/total); fprintf('\b\b'); % Print job done.
            end % End for 'i2'
        end % End for 'j2'
        %-----------------------------------------------------------------------------------------           
        S_z{k2,1} = 0;    % Free memory with used input data.
        fprintf(' ok \n');
    end % End for 'Nt'
    %---------------------------------------------------------------------------------------------------------------      
else
    %---------------------------------------------------------------------------------------------------------------
    % Calculos p/Soft-Baffle
    %---------------------------------------------------------------------------------------------------------------
    disp(':( Ups! Soft-Baffle not implemented yet in function:  "f_IRM_init" ');  error(' ');
end 

               et = toc;   % THS Enlapsed time [s]
[minutes,seconds] = f_convert_time(et);
fprintf('\n IRM done! :) \n');
fprintf('         et = %.1f   %.1f : %.1f \n\n',et,minutes,seconds);

fprintf(' :) JL Remember 2 check recep.field 4 neg. coords... \n\n ')




%%%  [D] = f_IRM_D_rad_element(c,r3,f3,D_angle);  % Determinate reception directivity value [0...1].
