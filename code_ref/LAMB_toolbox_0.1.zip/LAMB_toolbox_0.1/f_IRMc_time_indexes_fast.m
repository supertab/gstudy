function [i_T0,i_TD] = f_IRMc_time_indexes_fast (N,t,T0,TD)
% Funcion de calculo de los indices min. y max en la trama de tiempo
% 't', dentro de la cual se calcularan las 'alfa_s' y 'h'
%
% ver 1.0    30/07/2004
% ver 2.0    12/11/2004   Optimizacion del codigo, inclusion de: 'if (max(indexs) <= 0)'
% ver 3.0    26/11/2004   Agreg. margen prev. y post. a lo indices hallados,(p/cal. bien los alfa's x las dudas...)
% ver 4.0    28/09/2005   Agreg. de '-1' en linea '22' (i_TD = ...)
% ver 5.0    22/12/2008   Deteccion de [] en linea 21:  "min(find(indexs))".
% ver 5.1    12/01/2009   Change in name: 'f_cal_time_indexes' --> 'f_IRM_time_indexes'.
% ver 6.0    14/01/2009   Fast version!


margen = 1;  % Nro de muestras extras, p/cal. alfa's fuera de los limites 'i_T0' e 'i_TD'
%---------------------------------
k = find((T0 <= t) & (t <= TD));  % Indices corresp. ala ventana de calculo de los 'alfas'

% Indice de 't' corresp. a T0
if isempty(k) i_T0 = margen;  k = N;
else          i_T0 = min(k);  end;

% Indice de 't' corresp. a TD
i_TD = max(k) + margen - 1; 
%---------------------------------

% Obs. si luego hubiera algun error, no olvidar que es xque 'i_T0' o
% 'i_TD', se salen de los limites de los indices del vector de muestras: '1' y 'N'
%
% if (i_T0) <= 0)
%     i_T0 = 1;      % prevencion de ventana de calculo de los alfa's no nula  
% end    




