function [x_w2,y_w2,x_s2,y_s2,P_field_3,x_w3,y_w3,x_s3,y_s3,n_a3,n_b3] = f_IRM_check_input_data (t_amb,Hr,P,P_field_2,x_w2,y_w2,x_s2,y_s2,fs,f0,f_min,f_max,trace_duration,P_field_3,R_3,x_w3,y_w3,x_s3,y_s3,n_a3,n_b3,Nt,theta,ang_alfa,ang_beta,ang_gamma,theta_3,phi_3,psi_3,r3_type,f_pause)
% Verify if input variables to IRM main are correct...
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
%
% ver 1.0    29/12/2008    Using IRM-2D core: 'Main_FIRST_2D_2v3' (17/04/2008)
% ver 2.0    09/01/2009    Add of incident angle vector 'theta'.
% ver 2.1    17/01/2009    Error repaired in 'z_field_3' coordinate & 'theta_3'parameter added.
% ver 2.2    07/02/2009    'r3_type' parameter added to help define location of reception aperture.
% ver 2.3    01/03/2009    Reception field dims. checking code... modified.


f_warning = 0;
%--------------------------------------------------------------------------
% Re-define coordinates of central point of reception field 'P_field_3' if necessary.
if r3_type && R_3
    if R_3 == 0
        f_input(' R_3 ?');
    end
    theta_3_r = theta_3*(pi/180);    
    % Use 'P_field_2' as reference for aligments.
    x_field_3 = P_field_2(1) + R_3*sin(theta_3_r);
    y_field_3 = P_field_2(2);
    z_field_3 = P_field_2(3) + R_3*cos(theta_3_r); % Remember 'P_field_2' is located on plate's surface.
    P_field_3 = [x_field_3 y_field_3 z_field_3];
end
%--------------------------------------------------------------------------
% Check dimension values of reception field.
if (x_s2 == 0) && (y_s2 == 0)
    x_s2 = 0.001;  fprintf(' Using default X-value for:  x_s2 = %.1f [mm] \n',x_s2*1000);
    y_s2 = 0.001;  fprintf(' Using default Y-value for:  y_s2 = %.1f [mm] \n',y_s2*1000);
elseif (x_s2 <= 0) && (y_s2 > 0)
    x_s2 = y_s2;  fprintf(' (o_o) Warning: assigning ->  x_s2 = y_s2 =  %.1f [mm] \n',x_s2*1000);
elseif (x_s2 > 0) && (y_s2 <= 0)
    y_s2 = x_s2;  fprintf(' (o_o) Warning: assigning ->  y_s2 = x_s2 =  %.1f [mm] \n',y_s2*1000);
end
if x_w2 <= 0
    x_w2 = x_s2;
    fprintf(' (o_o) Warning: assigning -->  x_w2 = x_s2 = %.1f [mm] \n',x_w2*1000); % Width 4recept. zone in Y-axis.
end
if y_w2 <= 0
    y_w2 = y_s2;
    fprintf(' (o_o) Warning: assigning -->  y_w2 = y_s2 = %.1f [mm] \n',y_w2*1000); % Width 4recept. zone in Y-axis.
end    

%---------------------------------------------------------------
% Error messages:
fprintf('\n2.0.1 Checking IRM input variables... ');    
if (t_amb < 0) || (Hr < 0)  || (P < 99000)
   disp(':(  Error_1: wrong value of ambient paramenters...');
   fprintf(' t_amb = %d \n Hr = %d \n  P = %d \n',t_amb,Hr,P);  
   disp(' Can not continue with IRM calculation! ');  error(' ');
elseif (x_w2 <= 0) || (y_w2 <= 0)
   disp(':(  Error_2: Null or negative value of IRM-element dimension...');
   fprintf(' x_w2 = %d \n y_w2 = %d \n',x_w2,y_w2);         
   disp(' Can not continue with IRM calculation! ');  error(' ');
elseif (x_s2 < 0) || (y_s2 < 0)
   disp(':(  Error_3: Negative value of inter-element step dimension...');
   fprintf(' x_s2 = %d \n y_s2 = %d \n',x_s2,y_s2);
   disp(' Can not continue with IRM calculation! ');  error(' ');
elseif R_3 < 0
   disp(':(  Error_4: P_field_3 can not be on other the side or inside the plate! ');
   fprintf('  P_field_2 = %d  \n   P_field_3 = %d  \n R_3 = %d \n',P_field_2,P_field_3,R_3);   error(' ');
elseif (fs <= 0) || (f0 <= 0) || (f_min < 0) || (f_max < 0)
   disp(':(  Error_5: negative values of frequency  paramenters...');
   fprintf(' fs = %fs \n f0 = %d \n  f_min = %d \n f_max = %d \n',fs,f0,f_min,f_max);
   disp(' Can not continue with IRM calculation! ');  error(' ');
elseif (f_min > f_max)
   disp(':(  Error_6: wrong values of frequency BW paramenters: f_min > f_max ! ');
   fprintf(' f_min = %d \n f_max = %d \n',f_min,f_max);
   disp(' Can not continue with IRM calculation! ');  error(' ');
elseif (fs < 2*f0)
   fprintf(':( Error_7: Sampling frequency < than Niquist limit: ');
   fprintf(' fs = %d \n 2*f0 = %d',fs,2*f0);
   disp(' Can not continue with IRM calculation! ');  error(' ');
elseif (trace_duration < 0)
   fprintf(':( Error_8: Negative value of "trace_duration"!! ');
   fprintf(' trace_duration = %d \n',trace_duration);
   disp(' Can not continue with IRM calculation! ');  error(' ');
elseif (phi_3 > 180) || (phi_3 < 0)
   fprintf(' :( Error_9: "Phy" 1st. shell aperture angle outside range: 0�-180�... \n ');
   fprintf(' phi = %d \n',phi_3);  error(' ');
elseif (psi_3 > 180) || (psi_3 < 0)
   fprintf(' :( Error_10: "psi" 2nd. shell aperture angle outside range: 0�-180�... \n ');
   fprintf(' psi = %d \n',psi_3);  error(' ');
end

%---------------------------------------------------------------
% Warning messages:
if (fs < 300*10^6)
   fprintf('\n');
   disp('(o_o) Warning: Using low sampling frequency IRM may loose accuracy...');
   fprintf('      fs = %d MHz \n',fs/10^6);
   f_warning = 1;
end
if (trace_duration < 10/fs) && (trace_duration ~= 0)
   fprintf('(o_o) Warning: Value of "trace_duration" is too low... ( <= 10/fs) \n ');
   fprintf(' trace_duration = %d \n 10/fs = %d',trace_duration,10/fs);
   f_warning = 1;
end
if (x_w2 < 10^-5) || (y_w2 < 10^-5)
   fprintf('(o_o) Warning: Size acoustic grid elemens to small... \n ');
   fprint(' x_w2 = %d \n y_w2 = %d \n',x_w2,y_w2);      
   f_warning = 1;
end
if (ang_alfa >= 360) || (ang_beta >= 360) || (ang_gamma >= 360)
   fprintf('(o_o) Warning: Field rotation angles >= 360�... \n ');
   fprintf(' ang_alfa = %d \n ang_beta = %d \n ang_gamma = %d \n',ang_alfa,ang_beta,ang_gamma);
   f_warning = 1;
end
for k = 1:Nt
    if theta(k) < 0
        fprintf('(o_o) Warning: negative incident angle value... \n ');
        fprintf(' theta(%i) = %d� \n',k,theta(k));
        f_warning = 1;
    end
end
if (R_3 < 0.001) && (R_3 ~= 0)
   disp('(o_o) Warning: Reception field point becoming too close to plate...');
   fprintf(' R_3 = %.1d \n',R_3);
   f_warning = 1;      
end
if (P_field_3(1) <= 0)
   disp('(o_o) Warning: Reception field point too close to origin...');
   disp(' ...computation of negative coordinates may not work! :| ');
   fprintf('P_field_3 = [%.2g %.2g %.2g] \n',P_field_3(1),P_field_3(2),P_field_3(3));
   f_warning = 1;         
end
if (n_a3 <= 0) || (n_b3 <= 0)
   disp('(o_o) Warning: Null or negative val. of number of points by reception element...');
   fprintf('Assigning:  n_a3 = 1  &  n_b3 = 1 \n');
        n_a3 = 1;          
        n_b3 = 1;
   f_warning = 1;         
end
if (n_a3 - fix(n_a3)) || (n_b3 - fix(n_b3))
    disp('(o_o) Warning: number of points by element must be integer values...');
    fprintf('    Assigning: n_a3 = %i  &  n_b3 = %i \n',round(n_a3),round(n_b3));
        n_a3 = round(n_a3);
        n_b3 = round(n_b3);
   f_warning = 1;         
end
if (x_s3 <= 0)
   disp('(o_o) Warning: Null or negative value of X3-step field element dimension...');
   fprintf('Assigning:  x_s3 = 1 mm \n');      
        x_s3 = 0.001;
   f_warning = 1;         
end
if (y_s3 <= 0)
   disp('(o_o) Warning: Null or negative value of Y3-step field element dimension...');
   fprintf('Assigning:  y_s3 = 1 mm \n');      
        y_s3 = 0.001;
   f_warning = 1;         
end
if (x_w3 < 0)
   disp('(o_o) Warning: Negative value of X3-width reception field dimension...');
   fprintf('Assigning:  x_w3 = 0 \n');      
        x_w3 = 0;
   f_warning = 1;         
end
if (y_w3 < 0)
   disp('(o_o) Warning: Negative value of Y3-high reception field dimension...');
   fprintf('Assigning:  y_w3 = 0 \n');      
        y_w3 = 0;
   f_warning = 1;         
end
%---------------------------------------------------------------
if f_warning
    fprintf(' :| ok... \n');
    if f_pause  
        disp(' Program paused. Press any key to continue.')
        pause; 
    end
else
    fprintf(' :) ok! Done. \n');
end






