function [c,atte_air_dB,ro,Z0] = f_cal_air_properties(t,hr,p,f0)
% This function calculates the: 1. Velocity of sound in air [m/s];
% 2. The attenuation of sound [dB/m] and 3. Air density [Kg/m^3].
% It is based on the works:
%          1) For air c & attenuation see paper of: 'Graham Benny & Gordon Hayward' JASA 107(4) Abr.2000
%          2) For air density see paper:  'Equation for the Determination of the Density of Moist Air'.
%                                         P. Giacomo Metrologia 18, 33-40 (1982). 
%                                         R. S. Davis Metrologia, 29, 67-70. (1992). 
%
% Parameters; all are assumed to be column vectors:
%
%                t = Ambient temperature (�C).
%               hr = Relative humidity [%].
%                p = Atmospheric pressure [Pa].
%               f0 = Frequency of sound [Hz]. 
%
%-------------------------------------------------------------------------
% Remember the definition of extintion distance 'ed'.
% Defined by:
% ed = 1/atte_air        % Were the wave amplitude reduces to 36.8% (in 2/3 aprox.)
% ed = (5*10^13)/(f^2)   % This is aproximately expression valid for f >= 100kHz 
%-------------------------------------------------------------------------
%
%
% ver 1.0   18/09/2006
% ver 2.0   07/12/2008  English version w/vector code. 'c' express in [m/s] and atte_air_dB in [dB/m].
% ver 2.1   15/01/2009  Air characteristic impedance added.
% ver 2.2   05/05/2010  Adjusted values for air-densty calculations!

%-------------------------------------------------------------------------
T0 = 273.16;         % Triple point of water temperature (aprox. 0�K).
 T = T0 + t;         % Ambien temperature [Kelvin].
c0 = 331.31;         % Speed of sound [m/s] at the triple point of water.
P0 = 1;              % Reference atmospheric pressure = 1 [bar].

 P = p./(10.^5);     % Conversion from: [Pa] to --> [Bar].
 
%-------------------------------------------------------------------------
%-------------------------------------------------------------------------
% 1) Calculate speed of sound in air at temperature 't�C':
 c = c0.*sqrt(T./T0); %  In [m/s].
 
% Another similar expression derived from adiabatic aproach is:
%           c = sqrt(gamma*P/ro) = sqrt(gamma*R*T/mu) = sqrt(gamma*k*T/mo)
% Where:
%       gamma = 1.40  Is the (constant) ratio of the specific heats = Cp/Cv 
%          Cp = Specific heat at constant pressure.
%          Cv = Specific heat at constant volume.
%          mu = Is the molecular weight of 1 mol of air.
%          mo = The mass of single air molecule = mu/N.
%           k = R/N  Is the Bolztmann's constant.
%           N = The Avogadro number 6.02*10^23 molecules/mol.
%        B_ad = gamma*P  Is the adiabatic Bulk modulus of air.

%-------------------------------------------------------------------------
%-------------------------------------------------------------------------
% 2) Calculate attenuation air sound in air:
R_Psat_P0_dB = 10.79586.*(1-(T0./T)) ...       % Log.10(Psat/P) Where 'Psat' is the saturation pressure.
             + (1.50474.*10.^-4).*(1 - 10.^(-8.29692.*((T./T0) - 1))) ...
             + (0.42873.*10.^-3).*((10.^(4.76955.*(1-(T0./T)))) - 1) ...
             -  2.2195983;

      Psat_P = 10.^(R_Psat_P0_dB);     % water mole fraction
           h = hr.*(Psat_P)./(P./P0);
          
       f_r_O = (P./P0).*(24 + (4.04.*(10.^4).*h.*( (0.02+h)./(0.391+h) )));   % Resonance frequency of Oxigen [Hz].
       f_r_N = (P./P0).*(sqrt(T0./T)).*(9 + (280.*h.*exp(-4.17.*(((T0./T).^(-1./3)) -1)) ));   % Resonance frequency of Nitrogen [Hz].
        
     %-------------------------------------------------------------------------
     % We have inverted the term 'P/P0' by (P0/P) in such a way that
     % calculations adjust to reality... 
     % ...if atmospheric pressure raises --> Air attenuation must decrease!
     % And not into the reversed way as appear in the paper! This could be
     % a possible mistake in the paper...
     alfa_cr = (1.84.*(10.^-11)).*(f0.^2).*(P0./P).*(sqrt(T./T0));  % Air attenuation coeficient due to: 'clasic theory' + 'rotational air coefecient'
     %-------------------------------------------------------------------------    
  alfa_vib_O = (f0.^2).*((T0./T).^(5./2)).*( (1.278.*10.^-2).*( exp(-2239.1./T)./(f_r_O+((f0.^2)./f_r_O)) ) ); % Vibration Oxigen atte. coeficient.
  alfa_vib_N = (f0.^2).*((T0./T).^(5./2)).*( (1.068.*10.^-1).*( exp(-3352./T)./(f_r_N+((f0.^2)./f_r_N)) ) );   % Vibration Nitrogeno atte. coeficient. 
%-------------------------------------------------------------------------
% Note on: Attenuation definition.  
%-------------------------------------------------------------------------
% If a wave is of the form:        A = e^-(alfa*y)  
% then with y2 > y1 we have:   A2/A1 = e^-(alfa*y2)/e^-(alfa*y1)  < 1
%                              A2/A1 = e^-(alfa*Delta_y)         ;  Delta_y = y2 - y1 > 0
% Then taking ln to both sides...
% We have:               atte_Nepers = -(alfa*Delta_y)
% And                        atte_dB = 10*log10[(A2/A1)^2]  =  20*log10(A2/A1)
%
   atte_air = -(alfa_cr + alfa_vib_O + alfa_vib_N);  % Final value of attenuation of sound in air [nepers/m].
atte_air_dB = (20.*log10(exp(1))).*atte_air;         % The same express in [dB/m].
%-------------------------------------------------------------------------
% Remember the definition of extintion distance 'ed'.
% Defined by:
% ed = 1/atte_air        % Were the wave amplitude reduces to 36.8% (in 2/3 aprox.)
% ed = (5*10^13)/(f^2)   % This is aproximately expression valid for f >= 100kHz 
%-------------------------------------------------------------------------


%-------------------------------------------------------------------------
%-------------------------------------------------------------------------
% 3) Begin calculations of air density:
 R =  8.31441;            % Molar ideal gas constant   [J/(mol.�K)]
Mv = 48.015*10^-3;        % Molar mass of water vapour [kg/mol]
Ma = 28.9635*10^-3;       % Molar mass of dry air      [kg/mol]

 A =  1.2811805*10^-5;    % [K^-2]
 B = -1.9509874*10^-2;    % [K^-1]
 C = 34.04626034;         %
 D = -6.3536311*10^3;     % [K]
 
a0 =  1.62419*10^-6;      % [K/Pa]
a1 = -2.89690*10^-8;      % [1/Pa]
a2 =  1.0880*10^-10;      % [1/(�K.Pa)]
b0 =  5.75700*10^-6;      % [K/Pa]
b1 = -2.58900*10^-8;      % [1/Pa]
c0 =  1.92970*10^-4;      % [K/Pa]
c1 = -2.28500*10^-6;      % [1/Pa]
 d =  1.7300*10^-11;      % [K^2/Pa^2]
 e = -1.03400*10^-8;      % [K^2/Pa^2]
 
%-------------------------------------------------------------------------
% 3.1) Calculation of the saturation vapour pressure at ambient temperature, in [Pa].
psv = exp(A.*(T.^2) + B.*T + C + D./T);
% 3.2) Calculation of the enhancement factor at ambient temperature and pressure.
fpt = 1.00062 + (3.14.*10.^-8).*p + (5.6.*10.^-7).*(t.^2);
% 3.3) Calculation of the mole fraction of water vapour.
 xv = hr.*fpt.*psv.*(1./p).*(10.^-2);
% 3.4) Calculation of the compresibility factor of air.
  Z = 1 - ((p./T).*(a0 + a1.*t + a2.*(t.^2) + (b0+b1.*t).*xv + (c0+c1.*t).*(xv.^2))) + ((p.^2./T.^2).*(d + e.*(xv.^2)));
%-------------------------------------------------------------------------
% 3.5) Final value of air density in [kg/m^3].
% ro2 = 1.24    % Kino value of air-desnty @20�.
 ro = (p.*Ma./(Z.*R.*T)).*(1 - xv.*(1-Mv./Ma));

%-------------------------------------------------------------------------
% 4.1 Air characteristic impedance in [N.s/m^3]=[kg/(m^2.s)] or [Rayls].
 Z0 = c*ro;     



 
 
%---------------------------------------------
% Old incorrect values!
%  R =  8.314510;           % Molar ideal gas constant   [J/(mol.�K)]
% Mv = 18.015*10^-3;        % Molar mass of water vapour [kg/mol]
% Ma = 28.9635*10^-3;       % Molar mass of dry air      [kg/mol]
% 
%  A =  1.2378847*10^-5;    % [K^-2]
%  B = -1.9121316*10^-2;    % [K^-1]
%  C = 33.93711047;         %
%  D = -6.3431645*10^3;     % [K]
%  
% a0 =  1.58123*10^-6;      % [K/Pa]
% a1 = -2.9331*10^-8;       % [1/Pa]
% a2 =  1.1043*10^-10;      % [1/(�K.Pa)]
% b0 =  5.707*10^-6;        % [K/Pa]
% b1 = -2.051*10^-8;        % [1/Pa]
% c0 =  1.9898*10^-4;       % [K/Pa]
% c1 = -2.376*10^-6;        % [1/Pa]
%  d =  1.83*10^-11;        % [K^2/Pa^2]
%  e = -0.765*10^-8;        % [K^2/Pa^2]
