function f_FRM_plot_1(N3,t3,Vs3_3_0,Vs3_3_1,P_field_3,Nt,theta,a,p_max,num_p,Ps,S,fs,fs3,f,f_title,axis_font,f_delete_figs,f_norm_plots,f_dB_plots,f_pause,f_handle)
% Plot features of final array output signals.
% Parameters:
%                     N3 = Number of points of signals.
%                     t3 = Time signal's vector [s].
%                Vs3_3_0 = Vs3_3_0(N3,Nt) Final array signals @'Nt' incident angles w/no delays.
%                Vs3_3_0 = Vs3_3_0(N3,Nt) Final array signals @'Nt' incident angles w/PWF delays.
%              P_field_3 = Reception aperture center field point.
%                     Nt = Number of incident angles.
%                  theta = Incident angle vector [Deg].
%                      a = Radius of THS excitation 'point' radiators.
%                  p_max = Maximum THS pressure signal level.
%                     Ps = array of w/THS-incident signals. (?)
%                      S = Spectrum (?) of THS-incident signals...
%                     fs = Sampling frequency [Hz].
%                      f = Frequency vector for selected BW in [Hz].
%                f_title = Flag 4 plotting titles  0 -> Do not.
%              axis_font = Size of font title.
%          f_delete_figs = Flag 4 deleting figure 0 -> Do not delete.
%           f_norm_plots = Flag nomalizing amplitudes in signals 0 -> Do not normalize.
%                f_pause = Flag 4 program pause 0 -> Do not pause.
%               f_handle = Figure number.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    29/01/2009
% ver 1.1    21/02/2009     Inter program 'f_pause' added.
% ver 1.2    28/02/2009     Change in parameter 'fs_IMR' --> 'fs' because of use downsampled data.
% ver 2.0    14/12/2009     Adaptation for LAMB program ver 0.1 + 'f_handle' added.
% ver 2.1    18/12/2009     Adaptation to 'f_FRM_DAS_processor' v1.0


fprintf('4.1. Plotting final aperture signal(s) @Nt = %i incidence angle(s) \n',Nt)
     if f_norm_plots
         M = cell(3,1);
         M{1} = 'Input signal';
         M{2} = 'PWF signal';
         M{3} = 'Focalized signal';
    else
            M = cell(2,1);
         M{1} = 'PWF signal';
         M{2} = 'Focalized signal';
    end
     [c_type] = f_assign_color(Nt);
    c_p_index = round(num_p/2);    % Index of central excitation signal for input spectrum 'S'.
           S0 = S{c_p_index};
            x = P_field_3(1);  y = P_field_3(2);  z = P_field_3(3);
    %---------------------------------------------------------------------------------------------------------------    
    % 4.1.1 Plot output signal(s).
    h1 = figure(f_handle+1); hold on; grid on; 
    set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
    xlabel('t [s]','FontSize',axis_font);   
    if f_title     
        title(['Total output aperture signal(s) at (',num2str(x),' ;',num2str(y),' ;',num2str(z),') @p-max = ',num2str(p_max),'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p)],'FontSize',f_title); 
    end;
    %---------------------------------        
    % 4.1.2. Plot amplitude spectrum.
    h2 = figure(f_handle+2); hold on; grid on; 
    set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
    xlabel('f [Hz]','FontSize',axis_font);   
    if f_dB_plots
        ylabel('Amplitude [dB]','FontSize',axis_font); 
    else
        ylabel('Amplitude ','FontSize',axis_font); 
    end
    if f_title     
        title(['Output spectrum(s) at (',num2str(x),' ;',num2str(y),' ;',num2str(z),') @p-max = ',num2str(p_max),'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p)],'FontSize',f_title); 
    end;
    %---------------------------------        
    % 4.1.3. Plot phase spectrum.
    h3 = figure(f_handle+3); hold on; grid on; 
    set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
    xlabel('f [Hz]','FontSize',axis_font);   ylabel('Phase [Rad]','FontSize',axis_font); 
    if f_title     
        title(['Output spectrum(s) at (',num2str(x),' ;',num2str(y),' ;',num2str(z),') @p-max = ',num2str(p_max),'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p)],'FontSize',f_title); 
    end;
    
    %---------------------------------------------------------------------------------
    if f_norm_plots
        %-----------------------------------------------------------------------------
        [Vs3_3_1_max] = max(max(Vs3_3_1));  % Abosulute maximum amplitude of outpt signals.
        for k = 1:Nt
            %-------------------------
            % Extract PWF delayed signals (DAS@0�)
                   s = Vs3_3_1(:,k);   % Vs3_4 = Vs3_4(N3,Nt) Final array output with NO delays (focalized beam).   
               [S,F] = f_cal_spectra(fs3,s(:));   
            S_m(k,1) = max(S(:,1));    % Save max. spectrum ampltitude value.
        end  
        S_m = max(S_m); % Absolute maximum spectrum val. used in normalizations.
        %--------------------------------------
        % Plot central excitation signal & normalized spectrum.
                 N0 = length(Ps(:,c_p_index));
                 t0 = (0:1/fs:(N0-1)/fs)';
        [Ps_max,i1] = max(Ps(:,c_p_index));
        [S0_max,j1] = max(S0(:,1));
            S0(:,1) = S0(:,1)/S0_max;
        figure(h1); plot(t0,Ps(:,c_p_index)/Ps_max,'k');   text(t0(i1),Ps_max,'s0','VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
        figure(h2); plot(f,S0(:,1),'k');                   text(f(j1),max(S0(:,1)),'S0','VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
        figure(h3); plot(f,S0(:,2),'k');                   text(f(j1),max(S0(:,2)),'S0','VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
        %--------------------------------------   
        figure(h1);  ylabel('Normalized amplitude','FontSize',axis_font);
        %-----------------------------------------------------------------------------
    else
        Vs3_3_1_max = 1;   S_m = 1;
        figure(h1);  ylabel('Vout [V]','FontSize',axis_font);
    end
    
    %---------------------------------------------------------------------------------
    for k = 1:Nt
            %-------------------------
            % Process PWF delayed signals (DAS@0�)
                 s = Vs3_3_1(:,k);
        [s_max,i2] = max(s(:));
                 E = (norm(s)^2)/N3; % Signal energy: E = ps*v [J]  ; v = ps/Z0
             [S,F] = f_cal_spectra(fs3,s(:));  
            S(:,1) = S(:,1)/S_m;
        [S_max,j2] = max(S(:,1));        
            %-------------------------
            % Process Non-delayed signals (focalized beam)
                s2 = Vs3_3_0(:,k);
      [s2_max,i22] = max(s2(:));
                E2 = (norm(s2)^2)/N3; % Signal energy: E = ps*v [J]  ; v = ps/Z0
            [S2,F] = f_cal_spectra(fs3,s2(:));  
           S2(:,1) = S2(:,1)/S_m;
      [S2_max,j22] = max(S2(:,1));
            %-------------------------    
            % Plot delayed signals
            figure(h1); plot(t3,s/Vs3_3_1_max,c_type(k));        text(t3(i2),s_max/Vs3_3_1_max,[num2str(theta(k)),'� ','  Energy = ',num2str(E),' J',],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);        
            if f_dB_plots
                figure(h2); plot(F,20*log10(S(:,1)),c_type(k));  text(F(j2),S_max,[num2str(theta(k)),'� '],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
            else
                figure(h2); plot(F,S(:,1),c_type(k));            text(F(j2),S_max,[num2str(theta(k)),'� '],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
            end            
            figure(h3); plot(F,S(:,2),c_type(k));                text(F(j2),S_max,[num2str(theta(k)),'� '],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
            %-------------------------    
            % Plot Non-delayed signals
            figure(h1); plot(t3,s2/Vs3_3_1_max,'g');             text(t3(i22),s2_max/Vs3_3_1_max,[num2str(theta(k)),'� ','  Energy = ',num2str(E2),' J',],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);        
            if f_dB_plots
                figure(h2); plot(F,20*log10(S2(:,1)),'g');       text(F(j22),S2_max,[num2str(theta(k)),'� '],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
            else 
                figure(h2); plot(F,S2(:,1),'g');                 text(F(j22),S2_max,[num2str(theta(k)),'� '],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
            end
            figure(h3); plot(F,S2(:,2),'g');                     text(F(j22),S2_max,[num2str(theta(k)),'� '],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
            if Nt == 1
                figure(h1); legend(M,'FontSize',axis_font);
                figure(h2); legend(M,'FontSize',axis_font);
                figure(h3); legend(M,'FontSize',axis_font);
            end
            drawnow;
    end
    fprintf('     Reference input spectrum: S0{%i} @num_p = %i  \n\n',c_p_index,num_p);
    %---------------------------------------------------------------------------------
    
% Adjust spectrum figure axis.    
[f1,i1] = min(f);
[f2,i2] = max(f);
if f_dB_plots
    dB_level = max( [max(20*log10(S2(:,1))) max(20*log10(S(:,1)))] );
    if dB_level > 0 
        figure(h2); axis( [f1 f2  -20*dB_level dB_level] );
    else
        figure(h2); %axis( [f1 f2  3*dB_level dB_level] );
    end
else
    figure(h2); axis( [f1*0.6  f2*1.0  0  max( [max(S(:,1)) max(S2(:,1))] ) ] );
end
%figure(h3); axis( [f1  f2  min([min(S(i1:i2,2)) min(S2(i1:i2,2))])  max([max(S(i1:i2,2)) max(S2(i1:i2,2))]) ] );


% %--------------------------------
% % Test code for measurements 22-03-2009
%         N = max(size(Ps))
%        s2 = s(1:N)';
%     c_ww1 = crosscorr(Ps(:,1),s2,N/2);
% [C_ww1,F] = f_cal_spectra(fs,c_ww1);
% 
% figure(99); hold on; grid on;
% plot(F,C_ww1(:,1));

%--------------------------------
% plot(t3,s,'r')
E = sum(abs(s).^2)/max(size(s))   % E@8� = 9.2898e-012    E@0� = 1.2264e-014
if f_delete_figs && f_pause
    pause;  
    delete(figure(h1)); delete(figure(h2)); delete(figure(h3));
elseif f_delete_figs
    delete(figure(h1)); delete(figure(h2)); delete(figure(h3));
end

