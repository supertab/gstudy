function [S_int] = f_integrate(S,fs,n_ini,n_end)
% This function integrates the 'column' signals contained in a given matrix 'S'
% between a defined sample window: [n_ini n_end].
% Obs.
%     1) It should be:    1 <= n_ini  <= n_end  <= N    
%     2) Signal are given by 'columns'.
% 
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   01/06/2005
% ver 2.0   03/11/2007      Matrix version & english translation.
% ver 2.1   14/04/2008      Error fix in start value of 'n':  'n = n_ini';

disp('Integrating signals....+')
  
    [N,nro_s] = size(S);    % 'N' -> number of trace elements and number of signals -> 'nro_s'.
if n_ini < 0
    n_ini = 1;
elseif n_end > N   
    n_end = N;
elseif n_ini > n_end
    disp('Error!  "n_ini" parameter should be grater (>) than "n_end" ')
    pause
end
    
S_int = zeros(N,nro_s);
for j = 1:nro_s
    S(:,j) = S(:,j) - mean(S(:,j));        % Extract mean value.
         a = 0;
         n = n_ini;
         while (n >= n_ini) && (n <= n_end)
         S_int(n,j) = S(n,j) + a;
                  a = S_int(n,j);
                  n = n + 1;
         end
end

S_int = (1/fs)*S_int;





