function [ele_amp,ele_delay] = f_FIRST_ele_profiles(ele_order,N_ele,ele_amp_type,ele_delay_type,c,R,O,O_ele,ang_deflec,f_plot,f_handle,f_font)
% Calculate the amplitude (apodization) and delay profiles of array elements amplitud. 
% Data:
%               ele_amp_type = 0 -> No apodization -> uniform amplitud 4 all eles.
%                            = 1 -> Gaussiana profile.
%                            = 2 -> Triangular profile.
%                            = 3 -> User defined apo.vector.
%
%             ele_delay_type = 0 -> No element's signal delay (focalized beam).
%                            = 1 -> % Deflected Plane Wavefront (DPWF) generation.
%                            = 2 -> User defined delay vector.
%
% ver 1.0   21/10/2005
% ver 1.1   29/03/2006   Agreg. generacion de FOPDs!
% ver 2.0   01/12/2009   Adaptation to LAMB program ver 0.1

if f_plot
    if (f_handle <= 0) || isempty(f_handle)
        f_handle = 999004; figure(f_handle); hold on; grid on;    
    end
end
%------------------------------------------------------------
switch(ele_amp_type)
    case 0  % Uniforme amplitude (No apodization)
            ele_amp = ones(N_ele,1);
    case 1  % Gaussiana
            disp('Ups!  Not implemented yet......Gaussian apodization')
            error(':( ');
    case 2  % Triangular
            disp('Ups!  Not implemented yet......Triangular apodization')
            error(':( ');
    case 3  % User defined vector
            disp('Ups!  Not implemented yet......user defined vector amp. eles.')
            error(':( ');
    otherwise
            disp('Error in type of apodization input.')
            error(':( ');
end
        
switch(ele_delay_type)
    case 0  % No delay for array elements (focalized beam).
            ele_delay = zeros(N_ele,1);
    case 1  % Deflected plane wavefront (DPWF).
            f_quiet = 0; f_color = 'g';
            if ele_order == 0     % 1st. element 2 the rigth side (from array's front view)
                j = 1;     k = N_ele;
            else
                j = N_ele; k = 1; % 1st. element 2 the left.
            end
            if N_ele > 1
                [ele_delay] = f_cal_t_delay_FOPD(c,R,N_ele,O,O_ele,j,k,ang_deflec,f_plot,f_handle,f_font,f_color,f_quiet);
            else
                ele_delay = 0;   
            end
    case 2  % User defined delay vector
            disp('Ups! User defined delay vector 4 eles.....not yet implemented!')
            error(':( ');
    otherwise
            disp('Error en tipo de delay eles. entrado....')
            error(':( ');
end
        
%--------------------------------------------------------------------
% Plot of signals
if f_plot
    figure(f_handle+1); hold on; grid on;
    xlabel('N� ele.','FontSize',f_font); ylabel('ele_delay [s]','FontSize',f_font);
    plot(ele_delay); plot(ele_delay,'g.');
end
%1;
