function [s] = f_gen_signal(N,n_burst,s_type,s_amp,f0,fs,P0,t)
% This function generates diferent types of signals used in acoustic calculations.
% Where:
%              N = Number of points in signal.
%        n_burst = Number of cicles in burst-type signal (only used w/burst signals).
%         s_type = 'Type' of signal to generate.
%          s_amp = Signal's amplitude; typicaly in [Pa].
%             f0 = Bandwidth's (BW) central frequency.
%             fs = Sampling frequency [Hz].
%             P0 = Initial phase [Rad]; only for sinus type signals.
%              t = Signal's temporal axis [s].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    20/10/2005
% ver 2.0    05/01/2008     English version!
% ver 2.3    14/04/2008     Added 'n_burst' parameter.
% ver 3.0    22/04/2008     Impluse signal added! 
% ver 2.4    08/05/2008     Added 't' parameter.
% ver 2.4.1  04/03/2009     Code corrected for: 'case 8'  (Simulated impact impluse).

switch(s_type)
    %-------------------------------------------------------------------
    case 1  % Sinusoidal
        [s] = f_s_sinus(s_amp,f0,t,P0);           
    %-------------------------------------------------------------------
    case 2  % Pulsed model from: J.L.San Emeterio & L.G. Ullate paper.
        [s] = f_s_pulsed(s_amp,f0,t);       
    %-------------------------------------------------------------------
    case 3  % Burst-sinusoidal
        % Type of windowing to apply. 
        if n_burst >= 0   w_type = 0;  % 0 -> Rectangular. 
        else              w_type = 1;  % 1 -> Sinusoidal.
        end
        [s] = f_s_burst_sin(s_amp,f0,t,abs(n_burst),w_type);           
    %-------------------------------------------------------------------
    case 4  % Square-burst.
            % If   n_burst < 0  ->  Anti-simmetric type.
            % If   n_burst > 0  ->  Simmetric type.
            % Else n_burst == 0 ->  Simmetric type @n_burst = 10.            
     w_type = 0;
        [s] = f_s_burst_square(s_amp,f0,t,n_burst,w_type);
    %-------------------------------------------------------------------
    case 5  % Sinusoidal burst-chirp
        t_end = 15*10^-6         % Time for ending chirp [s].
        if max(t) < t_end
            disp('Error:  t_end > t_max  in f_s_chirp_sin function...');  error(' ');
        else
            f_ini = 0.4*10^6
            f_end = 1.4*10^6
              [s] = f_s_chirp_sin(s_amp,t_end,N,f_ini,f_end,fs);                       
        end
    %-------------------------------------------------------------------
    case 6  % Square burst-chirp
        disp(' :(  Ups!  Not implemented yet!...');  error(' ');
    case 7  % Impluse of amplitude 's_max' and duration '1/fs'.
                  ts = 1/fs;
                  td = 5*10^-6;
                  nd = round(td/ts);
                   s = zeros(N,1);
%        s(nd:nd+1,1) = s_amp;
                   M = round(N/10);
              s(M,1) = s_amp;
    case 8  % Heaviside step of amplitude 's_max'.
                  ts = 1/fs;
                  td = 5*10^-6;
                  nd = round(td/ts);
                   s = s_amp*ones(N,1);
              s(1:round(N/2),1) = 0;

    case 9  % Simulated impact impluse of amplitude 's_max' new model.
            % load  matlab_data_impulse_force_model_3;
        load  matlab_data_impulse_force_model_1;          
         td = 5*10^-6; % Impulse duration time [s] (user changeable parameter). 
                       % Obs:  td = 5us seems to be good 4 AL@0.8mm laser impact measuremets :)
       fs_p = 816/td;                 % 816 = N� sample  of signal != 0
       fprintf('Impact model: td = %.1f us   fs_p = %.2f MHz \n',td*10^6,fs_p/10^6)       
        t_p = (0:1/fs_p:(N_p-1)/fs_p)';           
          s = zeros(N,1);
       [s2] = f_interpol_signal_fs2(fs_p,fs,f_plastic);
       if N >= N_p   
           s(1:N_p,1) = s2(1:N_p,1);  % Correct signal longitude to 'N' points.
       else
           s(1:N,1) = s2(1:N,1);      % Correct signal longitude to 'N' points.
       end
       s = s_amp*s/max(s);
    case 10  % Impluse of amplitude 's_max' old model.
                  ts = 1/fs;
             delta_t = 30*10^-6;   % Impulse duration time [s].
                  td = 20*10^-6    %(N/2)*ts   % delta_t  % Impulse delay time [s].
        if round(delta_t/ts) < 5
            disp(' (o_o)  Warning: "Real" impulse signals contain less than 5 points... ')
        end
        if max(t) > delta_t
             t_sigma = delta_t/10
              t_mean = delta_t/2
              
                  t2 = (0:1/fs:delta_t)';   N2 = max(size(t2));
                   y = s_amp*gaussmf(t2,[t_sigma t_mean]);  % Gaussian time distrubution [s].
                   s = zeros(N,1);
                   
                  N1 = round(td*fs);
                  N2 = round(N2/2);
                  s(N1-N2:N1+N2-2,1) = y;           
           else
               t_max = max(t)
               td
               error(' :(  Signal,s duration time should be grater than t_max... ')
           end
    case 11  % User defined vector.
        load  matlab_data_user_vector;
        N_in = length(s_in)
        fprintf('User defined signal: fs_in = %.2f MHz \n',fs_in/10^6)       
        t_in = (0:1/fs_in:(N_in-1)/fs_in)';
           s = zeros(N,1);
        [s2] = f_interpol_signal_fs2(fs_in,fs,s_in);
       if N >= N_in
           s(1:N_in,1) = s2(1:N_in,1); % Correct signal longitude to 'N' points.
       else
           s(1:N,1) = s2(1:N,1);       % Correct signal longitude to 'N' points.
       end
       s = s_amp*s/max(s);             % Apply corresp. signal amplitude.
    otherwise
        disp(' :( Error: Tipo de se�al de entrada no definido..!');  error(' ');
end  

%s   
