function [et,a,S_z,Ps,S,X_field,Y_field,z_field,Nx,Ny,N,Nf,Nt,f,c_ph,theta,k,t,num_p,num_modes,mode_type,lambda_min] = f_THS_main_v5(s_path,s_file,f_plot_eles,T_amb,Hr,P,plate_mat,d,modes,O,a,p_max,x_w,y_w,x,X,Y,Ps,num_p,num_s,num_p_s,fs,f0,f_min,f_max,t_min,t_max,s_type,s_delay,n_burst,r_type,a_type,P_field_2,x_w2,y_w2,x_s2,y_s2,theta_min,theta_max,theta_s,c_ph_min,c_ph_max,c_ph_s,f_cph_mapping,f_pause,f_font,f_title,f_plate_handle)
%--------------------------------------------------------------------------~=
% Begin calculations of Time Harmonic Solution method (THS)!
% This core routines are based in the last version available:
% 'Main_thsm_5v.m'  ver 5.0  13/02/2008.
%--------------------------------------------------------------------------~=
%  This routines computes the Lamb wave temporal displacement signals (vertical & radial) 
% for a single layer of a given isotropic material excited by a number (num_p) of finite 
% circular regions of radius 'a'.
% It is based on the work: "The influence of Finite-Size Sources in Acousto-Ultrasonics"�
%                    from:  B.N.Pavlakovic & Joseph L. Rose (NASA report. 1994)
% 
% Obs.:      Units defined in the SI system. 
%            All dimensions in [m].
%            All angles if not specified in degrees [Deg].
%            
%            'L' = stands for Longitudinal waves.
%            'S' = stands for Shear waves.
%            The terms 'Bulk-waves' or 'Plane-waves' are the same.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    29/12/2008     Based on core 5.0 (13/02/2008) Frequency-Phase_velocity mapping. 
% ver 1.1    15/01/2009     Return of air characteristic impedance added.
% ver 1.2    19/01/2009     Draw of plate added.
% ver 1.3    17/02/2009     Inter program 'f_pause' added.
% ver 1.4    27/02/2009     's_delay' parameter added.
% ver 2.0    27/11/2009     Adaptation 4 LAMB program ver 0.1  1st. THS ver glued w/IRM code! (Complete LAMB program)


disp('--------------------------------------------')
fprintf('1.1 Initializing THS \n');
disp('--------------------------------------------')
%--------------------------------------------------------------------------
% 1. Start THS:
% 1.1 Define main paremeters.
[alfa,beta,ro,Lambda,Mu,c,ro_air,lambda_air_max,Z0,N,t,Nf,f,f_s,Nt,theta,Ncph,c_ph,num_modes,mode_type,lambda_min,W,K,theta_s,plate_type] = f_THS_define_parameters(f_cph_mapping,s_type,T_amb,Hr,P,plate_mat,d,a,modes,t_min,t_max,fs,f0,f_min,f_max,c_ph_min,c_ph_max,c_ph_s,theta_min,theta_max,theta_s,x_s2,y_s2,f_font,f_title);
%--------------------------------------------------------------------------
% If not using FIRST simulator, then define excitation 
if s_type >= 0
    %--------------------------------------------------------------------------
    % 1.2 Calculate coordinates of excitation field if selected.
    [x,X,Y,Ps,Ps_theta,num_p,num_s,num_p_s,a] = f_THS_excitation_coords(s_path,s_file,s_delay,O,s_type,r_type,a,x_w,y_w,N,fs,t,f_plot_eles(1),f_plate_handle);
    % 1.3 Draw plate & emission field boundary
    plate_color = 2;
    plate_dim = [0.300 0.100 d];
    %  plate_dim = [2.5*max(X_field) max(X_field) d];  % Other possible of plate dims [6*x_w2 6*y_w2 2*P_field_2(3)].
    plate_O = [P_field_2(1)/2 P_field_2(2) P_field_2(3)];
    f_THS_draw_plate(num_p,num_s,a,p_max,d,plate_type,plate_O,plate_dim,plate_color,f_plate_handle,f_font,f_title);
end
%--------------------------------------------------------------------------
% 1.4 Calculate coordinates of reception field.
[Nx,Ny,X_field,Y_field,z_field,P_far,ii_far,ii_near] = f_THS_reception_coords(f_cph_mapping,num_p,O,P_field_2,x_w2,y_w2,x_s2,y_s2,f_plate_handle);
%--------------------------------------------------------------------------
% 1.5 Check maximum 't_max' value with maximum distance.          
             [t2] = f_check_t_max(c,f_cph_mapping,num_modes,s_type,[min(min(X)) min(min(Y)) d/2],P_far,t_max,W,K);
[minutes,seconds] = f_THS_estimate_time(f_cph_mapping,s_type,s_delay,n_burst,r_type,a_type,p_max,O,t_max,num_modes,mode_type,num_p,num_s,num_p_s,x,X,Y,x_w,y_w,c,Nx,Ny,N,Nf,Nt,W,K,t,f,f_min,f_max,plate_type,d,a,f0,fs,f_s,c_ph,alfa,beta,Mu,f_pause,f_font,f_title);
%--------------------------------------------------------------------------
% 1.6 Start THS.
[et,S_z,Ps,S,Nf,Ncph,f,c_ph,k] = f_THS_init(f_cph_mapping,c_ph,s_type,s_delay,n_burst,r_type,a_type,num_p,num_s,num_p_s,num_modes,mode_type,modes,N,Nf,Nt,theta,d,a,O,Nx,Ny,X_field,Y_field,z_field,x,X,Y,x_w,y_w,Ps,c,f0,f_min,f_max,fs,p_max,t,f,W,K,alfa,beta,Mu,ii_far,ii_near,f_pause,f_font,f_plate_handle);

%--------------------------------------------------------------------------
% Print final data.
      t_pp = et/(num_p*num_modes*Nx*Ny*Nt); % Elapsed time by point-2-point calculations for all modes & all angles [s].
lambda_min = min(lambda_min);               % Absolute minum mode's frequency [m].
fprintf('       t_pp = %.1f s \n',t_pp);
fprintf(' lambda_min = %.1f mm \n',lambda_min*1000);
fprintf('      num_p = %i \n\n',num_p);

%pause;
delete(figure(991)); 
delete(figure(992));
delete(figure(993));
delete(figure(994));

%delete(figure(20)); 


