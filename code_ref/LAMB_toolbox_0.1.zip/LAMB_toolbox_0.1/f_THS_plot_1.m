function [F,Cph,Mode_max,h] = f_THS_plot_1(num_modes,f,c_ph,S_z,a,p_max,f_title,axis_font,f_delete_figs,f_pause)
% Plot features for 3D maps (Frequency-Phase_velocity).
% Parameters:
%      num_modes = Number of Lamb waves modes simulated.
%              f = Frequency vector [Hz].
%           c_ph = Phase velocities vector [m/s].
%            S_z = THS data cell array:  S_z = cell{Nt,num_modes}(Nx,Ny,N);
%              a = Radius of excitation 'points' [m].
%          p_max = Maximun excitation pressure [Pa].
%        f_title = 1 -> Activate title plot.          0 -> Do not.
%      axis_font = Title & axis font size.
%  f_delete_figs = 1 -> Deletes figures before quit.  0 -> Do not delete figures.
%        f_pause = 1 -> Activate program pause.       0 -> Do not.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    02/12/2008
% ver 1.1    11/12/2008     Delete figures flag added.
% ver 1.2    17/02/2009     Inter program 'f_pause' added.


h = figure(100000);  hold on; grid on;
fprintf('1.4.1 F-Cph normalized map feature @p_max = 1 Pa; a = %.2f mm \n',a*1000)

%Extract & plot 3D-maps!
[F,Cph] = meshgrid(f,c_ph);
  for m = 1:num_modes
      [Mode_max] = S_z{1,m}(:,:);  % Where: S_z = cell(1,num_modes)(Ncph,Nf);           
                                   % A_max = A_max/max(max(A_max));
       surf(F,Cph,Mode_max);
  end
  
% Use Z buffer render 2 speed up the plotting.
set(gcf,'Renderer','zbuffer'); set(h,'BackingStore','on'); axis tight;
caxis([0 10^-18])      % Set 3D color axis

set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
if f_title  title(['Frequency-Phase velocity map @p-max = ',num2str(p_max),'Pa;',' a = ',num2str(a*1000),' mm'],'FontSize',f_title); end;
xlabel('f [Hz]','FontSize',axis_font);  
ylabel('Cph [m/s]','FontSize',axis_font);  zlabel('u_z [m]','FontSize',axis_font); 

%--------------------------------
if f_delete_figs && f_pause
    pause;  
    delete(figure(10000));
elseif f_delete_figs
    delete(figure(10000));
end

