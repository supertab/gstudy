function [RD,steering,Array_feature,Array_delay] = f_FRM_plot(f3_delete_figs,Vs_feature_type,Vs_delay_type,a,p_max,num_p,Ps,S,t3,N3,Nt,Ns,theta,steering,fs,fs3,f,P_field_3,Xc3,Yc3,Zc3,Vs3_2,Vs3_3_0,Vs3_3_1,Vs3_3_2,f_polar_coord,f_norm_plots,f_dB_plots,f_pause,f_font,f_title,f_plot,f_plate_handle)
% Plotting function for FRM output data features.
% Parameters:
%          Vs3_4 = zeros(N3,Nt);  % Final array output matrix signals for steering angle vector 'theta'.
%             Ps = IRM data cell array:  Ps = cell{Nt,1}(Nx3,Ny3,N3);
%   f_norm_plots = 1 -> Normalize plot amplitudes.                  0 -> Do not.
%         f_font = Axis labels font size eg. 14.
%        f_title = Plot Title w/font size 14,etc.                   0 -> Do not plot titles.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    04/02/2009
% ver 1.4    21/02/2009     Inter program 'f_pause' added.
% ver 1.5    28/02/2009     Change in parameter 'fs_IMR' --> 'fs' because of use downsampled data.
% ver 2.0    14/12/2009     Adaptation for LAMB program ver 0.1 + 'f_handle' added.

                               

%----------------------------------------------------------------------------------------------------------------
% 4) Plot features for Field Reception Module.
%----------------------------------------------------------------------------------------------------------------
disp('4.1 Plotting FRM data...');
%------------------------------------------------------------------
% 4.1) Plot aperture total reception signal(s) for 'Nt' incidence angle(s).
%disp('(O_O) Warning: f_FRM_plot_1  function de-activated...')
f_handle = f_plate_handle + 410;
%f_FRM_plot_1(N3,t3,Vs3_3_0,Vs3_3_1,P_field_3,Nt,theta,a,p_max,num_p,Ps,S,fs,fs3,f,f_title,f_font,f3_delete_figs,f_norm_plots,f_dB_plots,f_pause,f_handle);

%------------------------------------------------------------------
% 4.2) Draw aperture reception diagram.
if max(size(steering)) > 1
         f_handle = f_plate_handle + 420;
    [RD,steering] = f_FRM_plot_2(Vs_feature_type,Vs_delay_type,N3,fs3,t3,Vs3_3_2,steering,Nt,Ns,theta,a,p_max,num_p,f_title,f_font,f3_delete_figs,f_polar_coord,f_norm_plots,f_dB_plots,f_pause,f_plot,f_handle);
end
%------------------------------------------------------------------
% 4.3) Extract feature-profiles of array's received signals.
         f_dB_plots = 0;
           f_handle = f_plate_handle + 430;
[Array_feature,Array_delay] = f_FRM_plot_3(Vs_feature_type,Vs_delay_type,Xc3,Yc3,Zc3,Vs3_2,theta,a,p_max,num_p,t3,fs3,f3_delete_figs,f_pause,f_norm_plots,f_dB_plots,f_title,f_font,f_handle);


fprintf(' Done.... FRM finish!  :) \n\n')










