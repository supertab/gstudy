function [a0,b0,c,ro,Z0,lambda0,s_type,theta_min,theta_max,theta_s,O,OA,R_1,ang_deflec_1,ang_alfa_1,ang_beta_1,ang_gamma_1,f_cph_mapping] = f_FIRST_check_input_data(T_amb,Hr,P,emitter_type_1,OA,a2_1,b2_1,R_1,O,d,x_w,y_w,a,ang_alfa_1,ang_beta_1,ang_gamma_1,fs_IRM,f0,f_min,f_max,t_min,t_max,v_amp_1,s_type,ele_amp_type_1,ele_delay_type_1,ang_deflec_1,f_cph_mapping)
% Verify if input variables for FIRST software.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
%
% ver 1.0    07/12/2009    Using IRM-2D core: 'Main_FIRST_2D_2v3' (17/04/2008)


       a0 = a2_1/2;          % Define half width of array elements.
       b0 = b2_1/2;          % Define half high of array elements.
   s_type = abs(s_type);     % Correct neg. value of signal type.
theta_min = abs(ang_beta_1); % Correct values for THS-incident angle vector 'theta'.
theta_max = abs(ang_beta_1);
  theta_s = abs(ang_beta_1);
%-----------------------------------------------------------
if ang_beta_1 < 0
    fprintf('(o_o) Warning: negative ang_beta_1 = %.1�',ang_beta_1);
    fprintf('      Setting:          ang_beta_1 = %.1�',abs(ang_beta_1));
else
    ang_beta_1 = -ang_beta_1;  % Invert angle around Y-axis to correspond rotations w/plate location.
end
    
%-----------------------------------------------------------
if (O(1) ~= 0) || (O(2) ~= 0) || O(3) ~= d/2; 
    O = [0 0 d/2];
    disp('(o_o) Warning: LAMB origin moved (or) not located on plate�s surface...');
    disp('      Moving to: 0 0 d/2 ');
end
%-----------------------------------------------------------
if (OA(1) ~= 0) || (OA(2) ~= 0)
    OA(1) = 0;
    OA(2) = 0;
    disp('(o_o) Warning: Emitter array not Y-axis centered...');
    disp('      Moving to: 0 0 z ');
elseif (OA(3) <= 0)
    OA(3) = 0.035; 
end
%-----------------------------------------------------------
if emitter_type_1 ~= 2
    fprintf(':( Error: wrong or not available  emitter_type_1 = %i \n',emitter_type_1);
    error(' ')
end
%-----------------------------------------------------------
if R_1 <= 0; 
    R_1 = 0.035; 
    disp('(o_o) Warning: Null or negative array radius...');
    fprintf('      Setting  R = %.1f mm \n',R_1*1000);
end
%-----------------------------------------------------------
if ang_deflec_1 ~= 0
   ang_deflec_1 = 0;
   disp('(o_o) Warning: Detecting no-null steering angle for emitter array...');
   disp('      Setting PWF deflection angle = 0 ');
end
%-----------------------------------------------------------
if (ang_alfa_1 ~= 0) || (ang_gamma_1 ~= 0); 
    ang_alfa_1 = 0;
   ang_gamma_1 = 0;
   disp('(o_o) Warning: Turns around X/Z axis detected. Setting angles to 0...');
end
%-----------------------------------------------------------
if f_cph_mapping 
    f_cph_mapping = 0;
    disp('(o_o) Warning: de-activating Frequency-Phase velocity mapping...');
end
%-----------------------------------------------------------
if a <= 0
    a = 0.0005;
       disp('(o_o) Warning: circles radius a < 0...');
    fprintf('      Assigning default value  a = %.2f mm \n',a*1000);
end
%-----------------------------------------------------------
if fs_IRM < 100*10^6
    fs_IRM = 100*10^6;
    fprintf('(o_o) Warning: fs_IRM = %.2f MHz < 100 MHz \n',fs_IRM/10^6);
       disp('      Setting to: fs_IRM = 100 MHz');
end
%-----------------------------------------------------------
if (f0 < f_min) || (f0 > f_max)
    fprintf(':( Error: f0 = %.2f MHz outside BW = %.2f-%.2f MHz \n',f0/10^6,f_min/10^6,f_max/10^6);
    error(' ');
end
%-----------------------------------------------------------
if t_min < 0
    fprintf('(o_o) Warning: negative t_min = %.2f us \n',t_min*10^6);
       disp('      Setting to: t_min = 0 s');
end    
if t_max > 0.001
    fprintf('(o_o) Warning: Possible 2 long  t_max = %.2f us... \n',t_max*10^6);    
end
%-----------------------------------------------------------
if round(s_type) > 10
    fprintf(':( Error: wrong value of s_type = %i \n',s_type);
    error(' ');        
end
%-----------------------------------------------------------
if v_amp_1 <= 0
    fprintf(':( Error: wrong value of v_amp_1 = %i m/s \n',v_amp_1);
    error(' ');    
elseif(v_amp_1 > 10)
    fprintf('(o_o) Warning: To high value of  v_amp_1 = %i m/s... \n',v_amp_1);
end
if (ele_amp_type_1 ~= 0) && (ele_amp_type_1 ~= 1) && (ele_amp_type_1 ~= 2) && (ele_amp_type_1 ~= 3)
    fprintf(':( Error: wrong value of ele_amp_type = %i \n',ele_amp_type_1);
    error(' ');        
end
if (ele_delay_type_1 ~= 0) && (ele_delay_type_1 ~= 1) && (ele_delay_type_1 ~= 2)
    fprintf(':( Error: wrong value of ele_delay_type = %i \n',ele_delay_type);
    error(' ');        
end
%-----------------------------------------------------------
if x_w < 0
    fprintf('(o_o) Warning: negative value of  x_w = %.1f mm \n',x_w*1000);
       disp('      Setting default value: x_w = 0');
end    
if y_w < 0
    fprintf('(o_o) Warning: negative value of  y_w = %.1f mm \n',y_w*1000);
       disp('      Setting default value: y_w = 0');
end    

%--------------------------------------------------------------------------
% 1.0.1.1 Cal. sound speed in air [m/seg].
[c,atte_air_dB,ro,Z0] = f_cal_air_properties(T_amb,Hr,P,f0);
              lambda0 = c/f0;      % Air wavelenght @f0 [m]
%--------------------------------------------------------------------------
disp('1.0.1.1 IRM parameters... Ok :)')
fprintf(' Computing incident field @ang_beta_1 = %0.1f�\n',-ang_beta_1);
fprintf(' Lambda_air = %.2f mm   @f0 = %.2f MHz  \n',lambda0*1000,f0/10^6);
fprintf('     fs_IRM = %.1f MHz  BW = %.2f-%.2f MHz\n',fs_IRM/10^6,f_min/10^6,f_max/10^6);

