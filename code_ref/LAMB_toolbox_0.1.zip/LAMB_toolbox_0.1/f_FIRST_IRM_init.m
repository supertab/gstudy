function [et,Ps] = f_FIRST_IRM_init (T_amb,Hr,P,baffle,N_ele,O_ele,ang_ele,ele_amp,ele_delay,a,b,X,Y,Z,fs_IRM,f_s,f_min,f,Nf,N,t,t_max,s)
% This function computes the acoustic field signals (Ps) into a reception region for a given emission array,
% 7based on the Impulse Response Method (IRM).
% It is based on the work: "Diffraction impulse response of rectangular transducers"
%                    from:  J.L.San Emeterio & L.Ullate {J.Acoust.Soc.Am. 92(2) (August 1992)}.
% Note:
%      air-density = [kg/m3]
%  air-attenuation = dB/m 
%              s_a = [m/s2]
%      h(P(xyz),t) = [m/s]
%
%
% ver 1.0   03/12/2009   Adaptation 2 LAMB program 0v1. Based on 'f_cal_Ps_plane' ver 2.2 (26/01/2008)

[ni,nj] = size(X);
    Ps = zeros(ni,nj,N);
  Ps_n = zeros(ni,nj,N);
     A = zeros(N,1);
p_done = 0;    
 total = N_ele;
%--------------------------------------------------------------------------
% Determine air attenuation in [dB/m] and index of 1st. non null filter value.
[c,atte_air_dB,ro,z0] = f_cal_air_properties(T_amb,Hr,P,f);
                 i_min = round((f_min/f_s)+1); 
%--------------------------------------------------------------------------
tic             
if baffle == 0   
   %--------------------------------------------------------------------------
   % IRM for Rigid baffle
   %--------------------------------------------------------------------------
   fprintf('FIRST Rigid-Baffle N = %i fs_IRM = %.1fMHz \n',N,fs_IRM/10^6);
   for n = 1:N_ele  % N_ele = nro. total de elementos del array
           fprintf('%02i',p_done);          % Start percentage job counter.
           %---------------------------------------------------------------
           % 1 --> All phylosophy... actual field point = [X(i,j) Y(i,j) Z(i,j)].
             s_a = ele_amp(n)*s;                                    % Apply element amplitude apodization.
           [s_a] = f_delay_signal(fs_IRM,N,ele_delay(n),s_a,1);     % Apply signal's corresponding delay.
           for i = 1:ni       % <- 2nd. Calculate 'rows'.
               for j = 1:nj   % <- 1st. Calculate 'columns'.
                      h = zeros(N,1);                               % Reserve memory 4 IR-vector. Do not change of place this line!
                     Pt = [X(i,j) Y(i,j) Z(i,j)] - O_ele(n,:);      % Move point: P -> P' ref. to O' = O_ele(k).
                   [Pt] = f_rotar_y(Pt,ang_ele(n,1));               % Rotate element face around 'Y-axis'.                   
        [zone,distance] = f_cal_zone(Pt(1),Pt(2),Pt(3),a,b);        % Distance from actual reception point to active emission element [m].               
                    %------------------------------------------------
                    % Construct attenuation filter.
                    % We left 'atte < 0' so we avoid later forget to multiply by (-1).
                    atte = 10.^(distance.*atte_air_dB./20);         % Calculate corresponding atte. to distance R3 [ratio].
                           A(i_min:Nf+i_min-1,1) = atte(1:Nf,1);    % Main part (0:f_s3:fs2/2).
                    A(N-i_min-Nf+3 :N-i_min+2,1) = atte(Nf:-1:1,1); % Complementary frequencies (fs2/2:f_s3:fs).
                   %------------------------------------------------
                   % Calculate impulse response (w/fast code!) & pressure signal.
                           [h] = f_IRMc_IR_RB_point_fast (Pt,a,b,c,t,h,N,zone,t_max);
                   Ps_n(i,j,:) = (ro/fs_IRM)*f_conv_met2(N,h,s_a,A); % Calculate & store final pressure signal [Pa].
               end 
           end
           %---------------------------------------------------------------
     Ps = Ps + Ps_n;       % Acumulator of 'field planes'.
   Ps_n = zeros(ni,nj,N);  % Reserve/reset memory for auxiliar buffer.
   %---------------------------------------------------------------                
   p_done = round((n*100)/total); fprintf('\b\b'); % Print job done.   
%   n
   end  % End for 'n' ele.
else
    %---------------------------------------------------------------------------------------------------------------
    % IRM for Soft baffle
    %---------------------------------------------------------------------------------------------------------------
    disp(':( Ups! Soft-Baffle not implemented yet in function:  "f_FIRST_IRM_init" ');  error(' ');
end % end if-else


et = toc; % Enlapsed time [s].







