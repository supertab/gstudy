function f_IRM_plot_2(Ps_feature_type,Ps_delay_type,N3,Z0,fs_IRM,t3,Ps3,f,S,x3,y3,z3,r3_type,Nt,theta,ang_alfa,ang_beta,ang_gamma,a,p_max,num_p,f_title,axis_font,f_delete_figs,Ps_movie,movie_delay,f_save_movie,d_factor,f_norm_plots,f_pause)
% Plot features for: 2) Reception line with "theta" incidence angles :)
% Parameters:
%Ps_feature_type = 0 -> Maximum.  
%                  1 -> Pick-to-pick value.
%                  2 -> Energy.                                
%              value -> Time instant 'photo' (index between 1:N).
%  Ps_delay_type = 0 -> Extraction of signal delays from (+)Pick.
%                  1 ->      "          "       but from (-)Pick.
%                  2 -> Delay extraction from signals envelope.
%             N3 = Number of points in signal traces.
%             Z0 = c*ro. Air characteristic impedance in [N.s/m^3] or [Rayls].
%         fs_IRM = IRM Sampling frequency [Hz].
%             t3 = Signal's temporal axis [s].
%            Ps3 = IRM output cell array data 'structure'. ->  Ps3 = cell(Nt,1)(Nx3,Ny3,N3).
%              f = Frequency vector [Hz].
%              S = Input excitation spectrum cell array:  S = cell{1,1}(Nf,2);
%       x3,y3,z3 =
%        r3_type = Acoustic reception region type:
%                  0 -> "Rectangular" region. This include: single point; line and plane (Plane).
%                  1 -> Square/Rectangular circle filled (Plane).
%                  2 -> Circular/Ellipse circle filled (Plane).
%                  3 -> Cylindrical/spherical Shell!
%             Nt = Number of incidence angles (theta).  In case of 3D-map --> Nt = Ncph.
%          theta = Plane wave incidence angle vector [Deg].
%       ang_alfa = Rotation of plane 'Ps' around axis 'X3'.Ej.90� -> plane 'X3-Z3'
%       ang_beta = Rotation following axis 'Y3' It's orientation have to be studied later...
%      ang_gamma = Rotation following axis 'Z3'.
%              a = Radius of excitation 'points' [m].
%          p_max = Maximun excitation pressure [Pa].
%          num_p = Number of THS excitation 'points'.
%        f_title = 1 -> Activate title plot.                0 -> Do not.
%      axis_font = Title & axis font size.
%  f_delete_figs = 1 -> Deletes figures before quit.        0 -> Do not delete figures.
%       Ps_movie = 1 -> Display movie feature.              0 -> Do not. 
%    movie_delay = Delay between movie frames [s].
%   f_save_movie = 1 -> Save movie into a file '*.avi'.     0 -> Do not.
%       d_factor = Downsample frequency factor (fs2 = fs/d_factor) to speed-up movies.
%   f_norm_plots = 1 -> Apply amplitude normalization.      0 -> Do not.
%        f_pause = 1 -> Activate program pause.             0 -> Do not.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    20/12/2008
% ver 1.1    08/01/2009     External downsample variable added: 'd_factor'.
% ver 2.1    15/01/2009     Corr. of energy calculation by adding air characteristic impedance.
% ver 2.2    17/02/2009     Inter program 'f_pause' flag added.


x3 = x3(:); % Enssure that vectors have column form.
y3 = y3(:);
z3 = z3(:);

[Nx3 Ny3] = size(x3);      % Number of points of reception field.

if (r3_type == 0) || (r3_type == 3)
    fprintf('2.4.2. Line/Arc reception region with  Nt = %i incidence angle(s) :) \n',Nt)
    %---------------------------------        
    % Detect plane of given line field.
     [ax,ax_name] = f_IRM_detect_axis(x3,y3,z3);
%     Ps3
else
    fprintf(':( Error: Using wrong "r_type" parameter w/Line-Arc region type \n');
    fprintf('Nx3 = %i   Ny3 = %i   r3_type =',Nx3,Ny3,r3_type);
    error(' ');
end

if ~Ps_movie
    %---------------------------------------------------------------------------------------------------------------    
    % 2.1 Plotting features of pressure signals.
    h1 = figure(500010); hold on; grid on; 
    set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
    xlabel([ax_name ' [m]'],'FontSize',axis_font);
    if f_title     
        title(['Feature of pressure signals in ',ax_name,' line @p-max = ',num2str(p_max),'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p)],'FontSize',f_title); 
    end
    %---------------------------------        
    % Plot feature of pressure signals.
    h2 = figure(500011); hold on; grid on; 
    set(gcf,'Renderer','zbuffer')  % Use Z buffer to speed up the plotting.
    set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
    xlabel([ax_name ' [m]'],'FontSize',axis_font);
    if f_title     
        title(['Pressure signals delay in ',ax_name,' line @p-max = ',num2str(p_max),'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p)],'FontSize',f_title); 
    end

    [a b c] = size(Ps3{1});
    for k = 1:Nt
        if (a == 1) && (b > 1)
            Ps(:,:) = Ps3{k}(1,:,:);
        elseif (a > 1) && (b == 1)
            Ps(:,:) = Ps3{k}(:,1,:);
        else
            disp('(o_o) Warning! Detecting single point in line function...')
            disp('      JL  try to review the calling code :| ');
            f_IRM_plot_1(N3,fs_IRM,t3,Ps3,x3,y3,z3,Nt,theta,p_max,num_p,Z0,fs,Ps,f,S,f_title,axis_font,f_delete_figs,f_norm_plots);
        end
        [Ps_feature,Ps_delay] = f_cal_Ps_feature(Ps_feature_type,Ps_delay_type,Z0,N3,fs_IRM,t3,theta(k),Ps,h1,h2,ax,0,axis_font);
        figure(h1); plot(ax,Ps_feature,'b'); 
        figure(h2); plot(ax,10^6*Ps_delay,'r'); 
    
        [Ps_max,jj] = max(Ps_feature);
        text(ax(jj),Ps_max,[num2str(theta(k)),'�'],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);  
        drawnow;
        % pause;
    end
else
    %---------------------------------------------------------------------------------------------------------------
    % 2.2 Display movie for line reception field!
    if     d_factor <= 0  fprintf('(o_o) Warning: d_factor must be >= 1 \n'); d_factor = 1
    elseif d_factor > 1   fprintf(' d_factor On! @ %.1f \n',d_factor);  end;
     fs4 = fs_IRM/d_factor;
  t4_min = t3(1);
[t4_max] = f_round(t3(N3),1/fs4,0);
      t4 = (t4_min:1/fs4:t4_max)';    % Downsample time axis from:  fs_IRM --> fs_IRM/d_factor.
      N4 = length(t4);
   [Ps3] = f_resample_data(N3,N4,fs_IRM,fs4,t3,t4,Ps3);
    fprintf('(o_o) Warning: displaying movie for 1st. incidence angle only \n');
       k = 1;                      [d1 d2 d3] = size(Ps3{k});     
    xmin = min(ax);                      xmax = max(ax);
    ymin = -(max(max(Ps3{k}(:,:,:))));   ymax = -ymin;
    fprintf(' theta: %d�... \n',theta(k));
    if (d1 == 1) && (d2 == 1)
        %------------------------------------------------------------------
        % Warning! Detecting single point in line function; review calling code..
        f_IRM_plot_1(N3,fs_IRM,t3,Ps3,x3,y3,z3,Nt,theta,p_max,num_p,f_title,axis_font,f_delete_figs);
    else
        %------------------------------------------------------------------
        for n = 1:N4
            h1 = figure(50012); %  set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
            if (d1 == 1) && (d2 > 1)   
                plot(ax,Ps3{k}(1,:,n));  % Plot Y-line movie.
            else % (d1 > 1) && (d2 == 1)
                plot(ax,Ps3{k}(:,1,n));  % Plot X-line movie.
            end
            title(['Acoustic pressure @p-max = ',num2str(p_max),'Pa; a = ',num2str(a*1000),' mm  � J.L.Prego-Borges'],'FontSize',12);
            xlabel([ax_name,' [m]'],'FontSize',axis_font);   ylabel('[Pa]','FontSize',axis_font);
            axis([xmin xmax ymin ymax]);  grid on;
            F(n) = getframe(h1);
            pause(movie_delay);
            if ~f_save_movie clear F; end;  % In not save file...then release memory!
        end
        if f_save_movie
            file = input('file_name ?','s');
            fprintf('Saving data to "%s.avi"  file.\n',file)
            movie2avi(F,file,'compression','Cinepak','quality',65)
            disp(' :)  Done!')
        end                
        %------------------------------------------------------------------
    end
end   

%--------------------------------
if f_delete_figs && f_pause
    pause;  
    delete(figure(h1)); 
    if ~Ps_movie  delete(figure(h2)); end;
elseif f_delete_figs
    delete(figure(h1)); 
    if ~Ps_movie  delete(figure(h2)); end;
end
