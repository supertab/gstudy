function [h] = f_IRMc_h_I_opt_fast (i_T0,i_TD,N,t,h,TA,TB,TC,TD, alfa_1,alfa_2,alfa_3,alfa_4)
% Funcion de computo de 'h(x,y,z,t)' en la zona 'I'
% 
% ver 6.0-8.0
% ver 9.0    30/07/2004   Funcion optimizada. Calculo de 'h' dentro de la ventana T0-TD)
% ver 9.1    28/01/2008   Uso de vectores columna p/'h'.
% ver 9.2    12/01/2009   Change in name: 'f_cal_h_I_opt' --> 'f_IRMc_h_I_opt'.
% ver 9.3    14/01/2009   Pass of 'h' vector as a parameter to improve speed!



Tm = min(TB,TC);
TM = max(TB,TC);

for i = i_T0:i_TD
      if (TA <= t(i)) && (t(i) <= Tm)
          h(i) = pi/2 - alfa_1(i) - alfa_2(i);

      elseif (Tm < t(i)) && (t(i) <= TM) && (TB <= TC)
          h(i) = -alfa_1(i) + alfa_3(i);

      elseif (Tm < t(i)) && (t(i) <= TM) && (TC < TB)
          h(i) = -alfa_2(i) + alfa_4(i);

      elseif (TM < t(i)) && (t(i) <= TD)
          h(i) = -pi/2 + alfa_3(i) + alfa_4(i);

      end
end      





