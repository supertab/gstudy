function [U] = f_THS_plot_2_3(f_movie,movie_delay,f_save_movie,f_view_spectra,f_feature_type,num_modes,t,N,Nt,Nx,fs,S_z,X_field,x_s2,theta,a,p_max,Z0,f_title,axis_font,f_delete_figs,f_pause)
% Plot features for X-line reception field with multiple incidence angles!
% Parameters:
%        f_movie = 1 -> Display movie feature.              0 -> Do not. 
%    movie_delay = Delay between movie frames [s].
%   f_save_movie = 1 -> Save movie into a file: '*.avi'.    0 -> Do not.
% f_view_spectra = 1 -> Activate spectrum visualization.    0 -> De-activate feature.
% f_feature_type = 0 -> Maximum.  
%                  1 -> Pick-to-pick value.
%                  2 -> Energy.                                
%              value -> Time instant 'photo' (index between 1:N).
%      num_modes = Number of Lamb waves modes simulated.
%              t = Signal's temporal axis [s].
%              N = Number of points in signal traces.
%             Nt = Number of incidence angles (theta vector).
%             Nx = Number of excitation 'points' followinx X-axis. 
%             fs = Sampling frequency [Hz].
%            S_z = THS data cell array:  S_z = cell{Nt,num_modes}(Nx,Ny,N);
%        X_field = X-coodinates of THS simulated field [m].
%           x_s2 = Step between THS simulated field points following X-axis [m].
%          theta = Plane wave incidence angle vector [Deg].
%              a = Radius of excitation 'points' [m].
%          p_max = Maximun excitation pressure [Pa].
%             Z0 = c*ro Is the air characteristic impedance in [N.s/m^3] or [Rayls].
%        f_title = 1 -> Activate title plot.                0 -> Do not.
%      axis_font = Title & axis font size.
%  f_delete_figs = 1 -> Deletes figures before quit.        0 -> Do not delete figures.
%        f_pause = 1 -> Activate program pause.             0 -> Do not.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    02/12/2008
% ver 1.1    11/12/2008     Delete figures flag added.
% ver 2.0    08/01/2009     Change on reception field dimensions: [Nx Ny]=size(X_field) --> S_z = zeros(Nx,Ny,N)
% ver 2.1    15/01/2009     Corr. of energy calculation by adding air characteristic impedance.
% ver 1.2    17/02/2009     Inter program 'f_pause' added.


fprintf('1.4.2.3. Plotting for X-line field at multiple incidence angles! \n',Nt);

if ~f_movie
    %---------------------------------------------------------------------------------------------------------------
    %---------------------------------------------------------------------------------------------------------------
    if f_view_spectra
        %----------------------------------------------------------------------
        % 2.3.1 Plot 2D-FFT spectrum for X-line.
            fprintf(' fs = [%.3f %.3f] MHz \n',fs/10^6,(1/x_s2)/10^6);
           fs = [fs 1/x_s2];
            U = zeros(Nx,Nt,N);
        for k = 1:Nt
            % Compose total signal at every point in X-line.
            for j = 1:Nx
                [U(j,k,:)] = f_THS_compose_total_signal(num_modes,N,S_z,k,j,1); % S_z = cell{Nt,num_modes}(Nx,Ny,N).
            end
            s(:,:) = U(:,k,:);
             [S,F] = f_cal_spectra(fs,s');
     
            fprintf(' Plotting spectra for theta = %d� \n',theta(k))
            figure(23100); 
            surf( F{1},F{2},S{1}/max(max(S{1})) ); 
            xlabel('f [Hz]','FontSize',axis_font);  ylabel('K [rad/m]','FontSize',axis_font); 
            set(gcf,'Renderer','zbuffer'); shading interp; 
            view(0,90); axis tight; drawnow;
            if Nt == 1 hold on; grid on; else pause; end; 
        end
        set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
        if f_title 
            title(['2D-fft normalized amp. spectrum for an X-line @p-max = ',num2str(p_max),'Pa;',' a = ',num2str(a*1000),' mm'],'FontSize',f_title);
        end;    
    else        
        %----------------------------------------------------------------------
        % 2.3.2 Detect signal's features for X-line.
            h = figure(23200); hold on; grid on;   set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
            xlabel('X [m]','FontSize',axis_font);  ylabel('Uz vertical displacement feature','FontSize',axis_font); 
            U = zeros(Nx,Nt);                      not_done = 1;
        for k = 1:Nt
            for j = 1:Nx
                [u] = f_THS_compose_total_signal(num_modes,N,S_z,k,j,1);  % S_z = cell{Nt,num_modes}(Nx,Ny,N).
                switch(f_feature_type)
                    case 0 % Maximum.
                        U(j,k) = max(u);
                        ylabel('Maximum amplitude [m]','FontSize',axis_font); 
                    case 1 % Pick-2-pick.                
                        U(j,k) = max(u) + abs(min(u));
                        ylabel('Pick to pick amplitude [m]','FontSize',axis_font); 
                    case 2 % Energy.
                             v = fs*diff(u);
                             v = [v; 0];              % Velocity signal [m/s].
                        U(j,k) = (norm(v)^2)*(Z0/N);  % Signal energy: E = rms(ps)*rms(v) [J]  ; v = ps/Z0 % Remember: RMS_x = norm(x)/sqrt(N).
                        ylabel('Energy [J]','FontSize',axis_font);
                    otherwise
                        if (f_feature_type < 0) || (f_feature_type > N)
                            fprintf(' :( Error: Wrong value of feature_type = %d \n',feature_type);  error(' ');
                        else
                            U(j,k) = u(f_feature_type);  % X-line Photo!
                            ylabel(['uz amplitude @ t = ',num2str(t(f_feature_type)*10^6),'us'],'FontSize',axis_font);
                            if not_done
                                fprintf('X-line photo at t = %.2f us  ',t(f_feature_type)*10^6);
                                not_done = 0;
                            end
                        end
                end % End switch
            end
            plot(X_field,U(:,k),'b');  [Ux jj] = max(U(:,k));
            text(X_field(jj),Ux,[' ',num2str(theta(k))],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);  drawnow;
        end
        if f_title
            title(['X-line feature of vertical displacements @p-max = ',num2str(p_max),'Pa;',' a = ',num2str(a*1000),' mm'],'FontSize',12);
        end
    end
    %---------------------------------------------------------------------------------------------------------------
    %---------------------------------------------------------------------------------------------------------------
else
    %----------------------------------------------------------------------
    % 3.1 Make movie for X-line reception field.    
    fprintf('(o_o) Warning: displaying X-line movie for 1st. incidence angle only \n');
    fprintf(' theta: %d�... \n',theta(1));
    % Add all Lamb modes!  
    M = zeros(Nx,N);     
    U = zeros(Nx,N);              % Put 2 zero signal acumulator.
    for n = 1:num_modes
        M(:,:) = S_z{1,n}(:,1,:); % S_z = cell{Nt,num_modes}(Nx,Ny,N);
             U = U + M;           % Calculate total signal by superposing all modes.
    end
    clear S_z; % Release memory!
    %------------------------------------------------------------------
    % Display movie!
      Uz = zeros(Nx,1);            
    xmin = min(min(X_field));   xmax = max(max(X_field));
%   zmin = -1.5*10^-10;           zmax = 1.5*10^-10;
    zmin = -(max(max(max(U))));   zmax = -zmin;
    for n = 1:N
        h = figure(31000);    set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
        plot(X_field,U(:,n)); grid on;
        axis([xmin xmax zmin zmax zmin zmax]);  view(0,90);
        title(['Uz displacement [m] @p-max = ',num2str(p_max),'Pa;',' a = ',num2str(a*1000),' mm','  � J.L.Prego-Borges'],'FontSize',12);
        xlabel('X [m]','FontSize',axis_font);  ylabel('uz [m]','FontSize',axis_font);    
        F(n) = getframe(h);
        pause(movie_delay);
        if ~f_save_movie clear F; end;  % In not save file...then release memory!
    end             
    if f_save_movie
        file = input('file_name ?','s');
        fprintf('Saving data to "%s.avi"  file.\n',file)
        movie2avi(F,file,'compression','Cinepak','quality',70)
        disp(' :)  Done!')
    end
end    


%--------------------------------
if f_delete_figs && f_pause
    pause;  
    delete(figure(23100));  delete(figure(23200));  delete(figure(31000));
elseif f_delete_figs
    delete(figure(23100));  delete(figure(23200));  delete(figure(31000));
end

    
    
    
    
    
    
    
    
    