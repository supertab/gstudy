function [mode_type,F2,K2] = f_load_Al_Lamb_modes(d,Lamb_mode)
% This function loads the seleted dispersion curves (Lamb_modes)
% for an Aluminum plate of width 'd'.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    15/01/2008
% ver 1.0.1  07/05/2008    Change in returning variable:  'm_type' --> 'mode_type'.
% ver 1.1    24/08/2008    AL plate of 3.2 mm added.


switch d
    case 0.0003
        disp(' Loading dispersion data for Al  0.3 mm ')
        load  matlab_data_modes__0mm3_Al_air_43KHz_20MHz
    case 0.0005
        disp(' Loading dispersion data for Al  0.5 mm ')
           disp(' (o_o)  Warning: Using low freq. extended Lamb modes...')  
           load  matlab_data_modes__0mm5_Al_air_0Hz_20MHz_ext
    case 0.0008
        disp(' Loading dispersion data for Al  0.8 mm ')
        load  matlab_data_modes__0mm8_Al_air_17KHz_15MHz
    case 0.001
        fprintf(' Loading dispersion data for Al  1 mm \n')
        load  matlab_data_modes__1mm0_Al_air_15KHz_15MHz
    case 0.0015
        disp(' Loading dispersion data for Al  1.5 mm ')
        load  matlab_data_modes__1mm5_Al_air_10KHz_11MHz.mat
    otherwise
        d
        error(' :(  Dispersion data not available for width of Al sheet.')
end

     num_modes = max(size(Lamb_mode));  % Number of modes to load.
num_data_modes = max(size(K));          % Number of modes in data file.    
            F2 = cell(num_modes,1);
            K2 = cell(num_modes,1);

fprintf(' Modes:  ');
for i = 1:num_modes
            n = 1;
    not_ready = 1; 
    while not_ready
        if strcmp(Lamb_mode{i},mode_type{n}) && (n <= num_data_modes)
            %----------------------------------------------
            % Detect type of Lamb mode
            if strncmp(Lamb_mode{i},'A',1)
                m_type(1,i) = 1;
                fprintf('\b %s ',Lamb_mode{i});
            elseif strncmp(Lamb_mode{i},'S',1)
                m_type(1,i) = 0;
                fprintf('\b %s ',Lamb_mode{i});
            else
                Lamb_mode{i}
                error(' :(   Input starting letter of Lamb mode is not correct...')
            end
            %----------------------------------------------
            % Save mode
            F2{i} = F{n};
            K2{i} = K{n};
        not_ready = 0;
        elseif (n < num_data_modes)
            n = n + 1;
        else
            Lamb_mode{i}
            error(' :(   Mode type not included in:  Al@%d  loaded data... \n',d)
        end
    end
end    
clear mode_type
%fprintf('Loadig data for %s modes...',Lamb_mode)
mode_type = m_type;

%n




