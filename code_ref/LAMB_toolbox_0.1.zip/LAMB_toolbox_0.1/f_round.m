function [x2] = f_round(x,increment,delta)
% This function rounds a given number 'x'
% in 'n' integer fractions of 'increment'.
% Obs.
%      delta > 0  Rounds towards ->  (n+1)*increment_x > x
%      delta < 0  Rounds towards ->    (n)*increment_x < x
%      delta = 0  Rounds towards ->  Nearest value.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   28/01/2008

        n = 0;
       x2 = 0;
not_ready = 1;
if round(x/increment) > 1000000
    disp('Warning: increment parameter too small in:  "f_round_2"...')
    pause
end

while not_ready
    if x2 < x
        n = n + 1;        % When exits 'n' always has accumulated 'n+1' increments.
       x2 = n*increment;
    else
        not_ready = 0;
    end
end

if (delta > 0)
    x2 = n*increment;      % Rounds to (n+1)
elseif (delta < 0) && (n ~= 0)
    x2 = (n-1)*increment;  % Rounds to (n)
elseif (delta == 0) && (n ~= 0) % Rounds to nearest value.
    if x <=(n-0.5)*increment    
        x2 = (n-1)*increment;
    else
        x2 = n*increment;
    end
end













