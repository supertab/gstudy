function [P] = f_r_intersec(r_a,r_b)
% Calcula el punto de interseccion entre dos segmentos de rectas r_a y r_b def. x un par de puntos.
% IMPORTANTE: Se parte del supuesto de que los dos segmentos de recta se cortan
%
% Obs. los puntos de Ref. 'P0_a', 'P0_b' de las dos rectas, son p/el cal. de las pendientes 
% y son los que se encuentran en el 2do. y 3er. cuadrante respect.
%
% ver 2.0   23/11/2005  
% ver 3.0   24/11/2005
% ver 4.0   28/05/2006  Short version code!
% ver 4.1   28/02/2009  Correction in code.

% -------------------------------------------------------------------------
% Cal. de las pendientes y ordenadas al origen de las rectas 'a' y 'b'
 P0_a = r_a(1,:); 
 P1_a = r_a(2,:);
   ax = (P1_a(1)-P0_a(1));
if ax == 0   ax = 10^-15;   end;
  m_a = (P1_a(2)-P0_a(2))/ax;   % Pend. recta_a
  b_a = P0_a(2) - m_a*P0_a(1);  % Ordenada al origen recta_a

 P0_b = r_b(1,:); 
 P1_b = r_b(2,:);
   bx = (P1_b(1)-P0_b(1));
if bx == 0   bx = 10^-15;   end;
  m_b = (P1_b(2)-P0_b(2))/bx;   % Pend. recta_b
  b_b = P0_b(2) - m_b*P0_b(1);  % Ordenada al origen recta_b

% -------------------------------------------------------------------------
% Cal. punto de interseccion
xi = (m_a*P0_a(1) - m_b*P0_b(1) - P0_a(2) + P0_b(2))/(m_a - m_b);
yi = m_a*xi + b_a;

 P = [xi yi];
 
 
% % -------------------------------------------------------------------------
% % Cal. punto de interseccion
%     yi = (b_a*m_b - b_b*m_a) / (m_b - m_a);
% if m_a == 0 
%     xi = yi/m_b - b_b/m_b;
% else
%     xi = yi/m_a - b_a/m_a;
% end
%
%P = [xi yi];
  



% % -------------------------------------------------------------------------
% % Old_code...
% % -------------------------------------------------------------------------
% % Deteccion del punto de ref. de la 'recta_a'
% if (r_a(1,1) <= 0) & (r_a(1,2) <= 0)
%     P0_a = r_a(1,:);  % Punto de ref. recta_a
%     P1_a = r_a(2,:);
% elseif (r_a(2,1) <= 0) & (r_a(2,2) <= 0)
%     P0_a = r_a(2,:);  % Punto de ref. recta_a 
%     P1_a = r_a(1,:);
% elseif (r_b(1,1) <= 0) & (r_b(1,2) <= 0)
%     P0_a = r_b(1,:);  % Punto de ref. recta_a
%     P1_a = r_b(2,:);  % Invesion de rectas 'b'-> 'a'
%     P0_b = r_a(1,:);  % Invesion de rectas 'a'-> 'b'
%     P1_b = r_a(2,:);
% else
%     P0_a = r_b(2,:);  % Punto de ref. recta_a
%     P1_a = r_b(1,:);  % Invesion de rectas 'b'-> 'a'
%     P0_b = r_a(1,:);  % Invesion de rectas 'a'-> 'b'
%     P1_b = r_a(2,:);
% end
% 
% % -------------------------------------------------------------------------
% % Deteccion del punto de ref. de la 'recta_b'
% if P0_b(1,1) < P1_b(1,1)
%     P0_b = P0_b(1,:);  % Punto de ref. recta_b
%     P1_b = P1_b(1,:);
% else
%       uu = P0_b(1,:);  
%     P0_b = P1_b(1,:);  % Punto de ref. recta_b
%     P1_b = uu;
% end

% -------------------------------------------------------------------------
% Extension de las rectas a mas de '100' unidades en ambas direcciones
% (p/evitar probl.de superposicion del pto. de ref. c/el de inteseccion)
%
% xi = (m_a*P0_a(1) - P0_a(2) - m_b*P0_b(1) + P0_b(2))/(m_a - m_b);
% yi = m_b*xi - m_b*P0_b(1) + P0_b(2);
%  P = [xi yi]
 
 
 
 
 
