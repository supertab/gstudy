function [alfa,beta,gamma] = f_IRM_detect_ele_orientation(P_ref,P,r3_type,phi_3,psi_3,ang_alfa,ang_beta,ang_gamma)
% Detect orientation angles for IRM receiving element located at point 'P' 
% respect to reference point 'P_ref' plate's plane.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    03/01/2009
% ver 2.0    19/01/2009      Change in sign definition of ang_beta.
% ver 3.0    22/02/2009      Corr. in eqs.
           


if r3_type == 3
    if (phi_3 > 0) && (psi_3 == 0)
        % For arcs alogn X-Z plane.
        alfa = ang_alfa;
        beta = ((180/pi)*atan((P(1) - P_ref(1))/(P(3) - P_ref(3)))); % + ang_beta;
       gamma = ang_gamma;
    elseif (phi_3 == 0) && (psi_3 > 0)
        % For arcs alogn Y-Z plane.
        alfa = (-(180/pi)*atan((P(2) - P_ref(2))/(P(3) - P_ref(3)))); % + ang_alfa;
        beta = ang_beta;
       gamma = ang_gamma;
    else
%        p_point = [P_ref(1) P(2)]        
        alfa = (-(180/pi)*atan((P(2) - P_ref(2))/(P(3) - P_ref(3)))); % + ang_alfa;
        beta = ((180/pi)*atan((P(1) - P_ref(1))/(P(3) - P_ref(3)))); % + ang_beta;
       gamma = ang_gamma;  
    end
else
    alfa = ang_alfa;
    beta = ang_beta;
   gamma = ang_gamma;
end

