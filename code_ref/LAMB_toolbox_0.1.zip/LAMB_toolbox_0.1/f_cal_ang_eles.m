function [ang_c] = f_cal_ang_eles(ele_order,N_e,d,R)
% Funcion auxiliar de calculo de los angulos (en Rad.) 'subtendidos' entre c/u de los centros 
% de eles. o sub-eles (segun como se llame la rutina), contra el eje 'Z'. 
%
%  Datos:   
%        N_e = nro. de elementos o sub-elementos en cuestion  
%          d = distancia de sepacion entre centros de eles. adyacentes [mm]
%          R = radio de curvatura [mm] 
% Retorna:
%      ang_c = angulo comprendido entre los centros de los eles./sub-eles. [Rad]
%
% ver 1.0    05/10/2005  
% ver 1.1    28/10/2005   Cambio en nomenclatura var. salida.
% ver 2.0    27/11/2009   Adaptation for LAMB program ver 0.1

    j = 1;
ang_c = zeros(N_e,1);      % Ang. de giro de los eles. en torno al eje 'Y'. [Rad]

if R == inf  ang_d = 0;
else         ang_d = d/R;  % Tang(angulo) corresp. al paso 'd' visto desde el centro de curvatura, a R[mm]
end

if f_impar(N_e,2)
    for i = (N_e-1)/2:-1:-(N_e-1)/2 % Num. eles. impar
        ang_c(j,1) = i*ang_d;
                 j = j+1;
    end
else
    for i = 1:N_e                   % Num. eles. impar
        ang_c(i,1) = (((N_e-1)/2)-(i-1))*ang_d;
    end
end

%--------------------------------------------------------------------------
% If 1st. element to the right side (from array's front view).
if ele_order ~= 0  % Then invert order of coordinates.
    ang_c_inv = zeros(N_e,1);
    for i = 1:N_e
        ang_c_inv(i,:) = ang_c(N_e-i+1,:);
    end               
    ang_c = ang_c_inv;
    fprintf(' Inverse ele. order: ele_angle(1) = %.1f� \n',ang_c(1)*180/pi);
else
    fprintf(' Normal ele. order: ele_angle(1) = %.1f� \n',ang_c(1)*180/pi);
end

%1;

    
    