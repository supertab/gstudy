function [zone,distance] = f_cal_zone (x,y,z,a,b)
% Funcion de calculo de la zona asignada a un punto de campo 'P'
% Donde:
%       (x,y,z) = Coord. del punto de campo a calcular [mm].
%             a = Semi-ancho de la aperura rectangular [mm].
%             b = Semi-alto de la aperura rectangular [mm].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver. 1.0   16/07/2004
% ver. 2.0   29/07/2004    Exclusion del borde 'S1' de la zona IV)
% ver. 3.0   15/10/2004    Todos los bordes estan excluidos de la zona IV
% ver. 4.0    3/11/2004    Inclusion puntos c/coord. neg., todos los cuadrantes del ele.
% ver. 5.0    5/11/2004    Esta ver. incluye la tranf. del origen de coord del ele. 
% ver. 6.0   20/11/2004    Inclusion del Origen de coord. generaliz. del Array 'OA'
% ver  7.0   26/01/2005    Exclusion de lo anterior x error de conceptual.
%                          Nueva ref. al Origen del elemento 'i' y cal. distancia a 'O'                         
% ver. 8.0   22/06/2005    Se elimino el uso de 'O' dado que 'Pt' ya viene referenciado a el.
% ver. 9.0   16/12/2008    Correccion x mal uso de:  menor-o-igual '<=' y  mayor-o-igual '>=' !!

distance = sqrt((x^2) + (y^2) + (z^2));  % distancia del punto de campo 'P' al origen de coord. del sub.ele. en cuestion

x = abs(x);  % Obs. aqui se incluyen todos los cuadrantes ref. al 1ero. en el cual 
y = abs(y);  % se basan los calculos del paper. El abs(), produce esta referenciacion.
                    
if (x >= a) && (y >= b)     % los bordes estan incluidos en la zona 1
    zone = 1;
elseif (x < a) && (y >= b)  % Con el '<=' forzamos que el borde 'S2' pertenezca a la zona II
    zone = 2;
elseif (x >= a) && (y < b)  % Con el '<=' forzamos que el borde 'S1' pertenezca a la zona III
    zone = 3;
elseif (x < a) && (y < b)   % Quitandolo entonces a la zona IV.. (mejor no entrar en ella..)
    zone = 4;
end    

