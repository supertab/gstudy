function [d_s] = f_diff(N,fs,s)
% This function calculates the derivative of given signal 's'
% with sampling frequency 'fs'; using a numeric aproximation formula.
% See ref. book of: "Mathematical Handbook for Scientists and Engineers"
%                    Granino A. Korn & Theresa M. Korn 
%                    Mc Graw Hill; 2nd. Ed. (1968). 
%                    Equation 20.7-9  (page 771).
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    08/12/2008    


  d_s = zeros(N,1);
for i = 4:N-1
    d_s(i) = ( 3*s(i+1) + 10*s(i) - 18*s(i-1) + 6*s(i-2) - s(i-3) )*(fs/12);
end









