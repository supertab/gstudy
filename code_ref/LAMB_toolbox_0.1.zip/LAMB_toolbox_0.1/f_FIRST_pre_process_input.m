function [N,Nf,f_s,f,t,s_a,ele_amp,ele_delay] = f_FIRST_pre_process_input(ele_order_1,N_ele_1,ele_amp_type_1,ele_delay_type_1,c,R_1,O2,O_c_ele,ang_deflec_1,v_amp_1,n_burst,s_type,s_delay,Nx,Ny,N2,t2,fs_IRM,f0,f_min,f_max,f_FIRST_filter,f_plot,f_handle_input,f_font)
% This function prepares input data for the FIRST-IRM routines.
%
%      P_field_2 = [x y z]  Central point in plate emission field region [m].     
%           x_w2 = Width of emission field in X axis [m].
%           y_w2 = Width in Y axis [m].
%
%           x_s2 = Step between points in X axis [m].
%           y_s2 = In Y axis [m].
% 
%         fs_IRM = Sampling frequency for IRM [Hz].
%
%             Nx = Number of points in X-axis of emission grid.
%             Ny = Number of points in Y-axis of emission grid.
%             Nx = Number of incident angles (theta) of THS excitation field.
%
%            
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
%
% ver 1.0    01/12/2009    


fprintf('1.0.4.0 Preprocessing input data: \n');
%--------------------------------------------------------------------------
% 1.0.4.1 Determinate amplitude & delay profiles of emitter array elements.
disp(' 1.0.4.1 Determining amplitude & delay element profiles.');
[ele_amp,ele_delay] = f_FIRST_ele_profiles(ele_order_1,N_ele_1,ele_amp_type_1,ele_delay_type_1,c,R_1,O2,O_c_ele,ang_deflec_1,f_plot,f_handle_input+3,f_font);

%--------------------------------------------------------------------------
% 1.0.4.2 Calculate input aceleration signal.
disp(' 1.0.4.2 Calculating input aceleration signal..');
[sa,sv] = f_FIRST_s_a_signal(n_burst,s_type,v_amp_1,N2,fs_IRM,f0,f_min,f_max,t2,s_delay,f_plot,f_handle_input+1,f_font);

%--------------------------------------------------------------------------
% 1.0.4.2.b Load & apply emitter's frequency response if required.
fprintf(' 1.0.4.2.b');
sa = f_freq_filter(N2,fs_IRM,f_min,f_max,sa,f_FIRST_filter,f_plot,f_handle_input+2);
%--------------------------------------------------------------------------
% 1.0.4.3 Test fft speed versus trace longitude.
fprintf(' 1.0.4.3 Testing vector longitudes for speed... \n')
      s2 = sa(:);
 [N3,t3] = f_cal_t_power_2 (fs_IRM,t2); % Aproximate N2 lenght to -> '2^n' multiple for IRM speed-up. 
      s3 = zeros(N3,1);
  if N3 >= N2;  s3(1:N2) = s2(:);
  else             s3(:) = s2(1:N3);
  end
 [N,t,s_a] = f_test_speed(N2,N3,t2,t3,s2,s3); % Test & assing final logitudes 4 input signal.

%--------------------------------------------------------------------------
% 1.0.4.4 Dermine frequencies in signal bandwidth (BW).
 f_s = fs_IRM/N;            % Frequency spacing 'steps' between frequency points in signals [Hz].
   f = (f_min:f_s:f_max)';  % Signal's frequency operating vector BW [Hz].  
  Nf = max(size(f));        % Number of frequencies in BW.  
fprintf(' 1.0.4.4 Determining frequency vector bandwidth...\n');
fprintf('        N = %i   Nf = %i   f_s = %.1f Hz \n',N,Nf,f_s);
%--------------------------------------------------------------------------
% 1.0.4.5 Checking available memory. Maximum size of continuos block = 1015.56 MB.
fprintf(' 1.0.4.5 ');
  N_limit = 905*1024*1024;
[N_total] = f_IRM_check_memory(N_limit,Nx,Ny,N);



 
% %--------------------------------------------------------------------------
% % Check emission element-min.wavelenght ratio.
% ele_ratio = (2*a)/(lambda_min/2);
% if (lambda_min/2 < 2*a)
%       disp('(o_o) Warning: Using too wide emission elements... ');
%    fprintf('      field calculations may loose accuracy. Ele_ratio should be < 1 \n');
%    fprintf('      ele_ratio = %.1f \n\n',ele_ratio);
% end
% 
% fprintf('2.2. IRM Final data: \n');
% fprintf('         N = %i   Nf = %i   f_s = %.1f Hz \n',N4,Nf4,f_s4);
% fprintf(' Emission element parameters: \n');
% fprintf('        2a = %.3f mm \n',2*a*1000);
% fprintf('        2b = %.3f mm \n',2*b*1000);
% fprintf('Lambda_min = %.1f mm \n',lambda_min*1000);
% fprintf(' ele_ratio = %.1f %% \n\n',ele_ratio*100);  if ele_ratio > 1  fprintf('\b\b It should be <= 100%%  (o_o) \n'); end;
% 
% fprintf(' P_field_2 = [%.3g %.3g %.3g] \n',P_field_2(1),P_field_2(2),P_field_2(3));
% % u = [P_field_2 - P_field_2o];  % Cal. in plane offset vector.
% % if norm(u) > 0   fprintf(' -> [%.3g %.3g %.3g] \n',P_field_2o(1),P_field_2o(2),P_field_2o(3));
% % else             fprintf(' \n');   end;
% fprintf(' P_field_3 = [%.3g %.3g %.3g] \n',P_field_3(1),P_field_3(2),P_field_3(3));
% fprintf('    D3_min = %.1f mm    D3_max = %.1f mm \n',D3_min*1000,D3_max*1000);







