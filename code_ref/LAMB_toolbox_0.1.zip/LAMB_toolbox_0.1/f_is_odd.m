function [r_div] = f_is_odd(n,divider)
% This function returns '1' if 'n' is odd or '0' if it is even.
% Obs.:
%      If   'divider = 2'  ->  Use for detection of  'odd/even' number.
%      If  'divider ~= 2'  ->  Uso for detection of exact division!

%
% ver 1.0     23/10/2004
% ver 2.0     26/10/2004   General divided added.
% ver 2.1     16/09/2007   English version.

r_div = rem(n,divider);   

