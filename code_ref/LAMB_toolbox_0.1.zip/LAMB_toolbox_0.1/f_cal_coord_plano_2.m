function [u,U,V,W] = f_cal_coord_plano_2 (P_field,uw,vw,us,vs)
% Funcion de calculo d/coordenas de puntos p/una region de campo rectangular:
% 'plano', 'linea' o 'punto'.
% Parte de un 1 "sector rectangular" de dimensiones 'uw','vw' definido para:
% Z = P_field(3) -> plano 'X,Y'.
%
% Datos de entrada: 
%                    P_field = Punto central d/region circular en plano de campo [x,y,z].
%                        uw  = Ancho del plano [mm].
%                        vw  = Alto  del plano [mm].
%                        us  = Paso entre puntos d/grilla s/'Ancho' [mm].
%                        vs  = Idem 'Alto' [mm].
% 
% ver 1.0    10/11/2005
% ver 1.1    30/03/2006    Agreg. de variable 'handle' p/graficado selectivo en figuras
% ver 1.2    05/06/2006    Agreg. punto mas cercano
% ver 2.0    24/01/2008    Plot en 3D del TC. 
% ver 3.0    01/02/2008    Redefinicion d/funcion x simplificacion.
% ver 4.0    11/12/2008    Hemos omitido la mult. *(-1) de 'v' y 'u' p/unificar el codigo IRM y THM.

%--------------------------------------------------------------------------------
% Ajuste de las dimensiones del 'ancho' de acuerdo al paso de la grilla dado p/q
% tanto 'nro_u' como 'nro_v', den nros. de puntos enteros p/la grilla del plano.
resto_u = f_impar(uw,us);
if resto_u  % Dividendo del ancho fraccionario?
   nro_u = fix(uw/us);  % Sip!, redefinir nro. de puntos y...
      uw = nro_u*us;    % ancho del plano 'uw' de acuerdo al paso dado, 'us'
else
   nro_u = uw/us;       % No, ok! dividendo entero, no hace falta cambiar la dim. del ancho
end

%--------------------------------------------------------------------------------
% Ajuste de las dimensiones del 'alto' de a cuerdo al paso de la grilla dado p/q 
% tanto 'nro_u' como 'nro_v', dan nros. de puntos enteros p/la grilla del plano.
resto_v = f_impar(vw,vs);
if resto_v  % Dividendo del alto fraccionario?
   nro_v = fix(vw/vs);  % Sip!, redefinir nro. de puntos y...
      vw = nro_v*vs;    % alto del plano 'vw' de acuerdo al paso dado, 'vs'
else
   nro_v = vw/vs;       % No, ok! dividendo entero, no hace falta cambiar la dim. del alto.
end

%--------------------------------------------------------------------------------
% Generacion vectores de puntos corresp. al ancho (u) y alto(v) del plano/linea 
% (segmento de recta).
% Obs. Utilizaremos p/'u,v'  las coord. 'x,y' de 'P_field' ya que x ellas se centra 
% el 'plano'. Recordar depende de:  P_field(x,y,z).
  u_min = P_field(1,1) - (uw/2);   
  u_max = P_field(1,1) + (uw/2);   
  v_min = P_field(1,2) - (vw/2);   
  v_max = P_field(1,2) + (vw/2);
      
      u = u_min+(0:nro_u - 1)*(u_max - u_min)/floor(nro_u);  % gen. de vectores p/1na 'Linea' coords. 'x'
      u = [u  u_max];  % Obs. los corchetes '[..]' agregan un punto mas al vector (u_max)
      v = v_min+(0:nro_v - 1)*(v_max - v_min)/floor(nro_v);  % gen. de vectores p/1na 'Linea' coords. 'y'
      v = [v  v_max];  % Obs. los corchetes '[..]' agregan un punto mas al vector (v_max)
      w = P_field(1,3); % Coord. 'Z' del Plano/Linea = P_field(z)
%--------------------------------------------------------------------------------
% Generacion de matrices U,V y W corresp. a los puntos del plano de campo a rotar.
% Definidas sobre el plano: Z = P_field(3)  --> plano 'X,Y'.
     un = max(size(u));          % Halla el nro. de puntos de los vectores en: 'us' y 'vs'.
     vn = max(size(v));               
     
      U = zeros(un,vn);          % Pide memoria p/la matriz corresp. a la coordenada 'U'.
      V = zeros(un,vn);          % Pide memoria p/la matriz corresp. a la coordenada 'V'.
      W = w*ones(un,vn);         % Pide memoria y genera la matriz corresp. a las coordenada 'W'.

for j = 1:vn
    U(:,j) = u(1,:)';            % Cargar matriz final 'U'.
end
for i = 1:un
    V(i,:) = v(1,:);             % Cargar matriz final 'V'.
end



