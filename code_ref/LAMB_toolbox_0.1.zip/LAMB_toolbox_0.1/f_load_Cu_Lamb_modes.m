function [mode_type,F2,K2] = f_load_Cu_Lamb_modes(d,Lamb_mode)
% Loads dispersion curve data (Lamb_modes) for Cooper plate of width 'd'.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    30/12/2009


switch d
    case 0.00035
        disp(' Loading dispersion data for Cu @0.35 mm ')
        load  matlab_data_modes__0mm35_Cu_air_60KHz_6MHz.mat
    case 0.00045
        disp(' Loading dispersion data for Cu @0.45 mm ')
%           disp(' (o_o)  Warning: Using low freq. extended Lamb modes...')  
           load  matlab_data_modes__0mm45_Cu_air_60KHz_6MHz.mat
    otherwise
        d
        error(' :(  Dispersion data not available for width of Al sheet.')
end

     num_modes = max(size(Lamb_mode));  % Number of modes to load.
num_data_modes = max(size(K));          % Number of modes in data file.    
            F2 = cell(num_modes,1);
            K2 = cell(num_modes,1);

fprintf(' Modes:  ');
for i = 1:num_modes
            n = 1;
    not_ready = 1; 
    while not_ready
        if strcmp(Lamb_mode{i},mode_type{n}) && (n <= num_data_modes)
            %----------------------------------------------
            % Detect type of Lamb mode
            if strncmp(Lamb_mode{i},'A',1)
                m_type(1,i) = 1;
                fprintf('\b %s ',Lamb_mode{i});
            elseif strncmp(Lamb_mode{i},'S',1)
                m_type(1,i) = 0;
                fprintf('\b %s ',Lamb_mode{i});
            else
                Lamb_mode{i}
                error(' :(   Input starting letter of Lamb mode is not correct...')
            end
            %----------------------------------------------
            % Save mode
            F2{i} = F{n};
            K2{i} = K{n};
        not_ready = 0;
        elseif (n < num_data_modes)
            n = n + 1;
        else
            Lamb_mode{i}
            error(' :( Mode type not included in  Cu@%d  loaded data. \n',d)
        end
    end
end    
clear mode_type
%fprintf('Loadig data for %s modes...',Lamb_mode)
mode_type = m_type;

%n




