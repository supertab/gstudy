function [w] = f_w_triang(num_s,level)
% This function creates a triangular apodizing window 'w'
% of 'num_s' points; with minimum Y-axis value 'level'.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   10/02/2008

     n = (1:num_s)';    % Auxiliary X-axis of apodization coefficients.
if f_impar(num_s,2)            
    ii = (num_s-1)/2 + 1;     % Max. index of (+)straight line.
     m = (1 - level)/(ii-1);  % Inclination of (+)straight line.
    w1 = m*(n(1:ii) - 1) + level; % Y-axis values for (+)straight line.
    w2 = w1(ii-1:-1:1);       % Y-axis values for (-) with '-m' inclination.
else
    ii = num_s/2;
     m = (1 - level)/(ii-1);
    w1 = m*(n(1:ii) - 1) + level;        
    w2 = w1(ii:-1:1);
end
w = [w1;w2];   % Final triangular window aasembly.




