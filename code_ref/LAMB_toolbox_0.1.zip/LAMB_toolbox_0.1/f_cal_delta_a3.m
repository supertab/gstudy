function [d_delta_a] = f_cal_delta_a3(w0,k0,k_tl,k_ts,h,alfa,beta)
% This funtion calculates the derivatives of the dispersion functions 
% for straight crested Anti-symmetric Lamb wave modes in a free layer.
% Calculation are based on the work : 
%                          "The influence of Finite-Sice Sources in Acousto-Ultrasonics"�
%                    from:  B.N.Pavlakovic & Joseph L. Rose (NASA report. 1994)
% 
% Obs.:      w0 = Angular frequency vector [rad/s].
%            k0 = Wavenumber vector [Rad/m].
%             h = Half plate thickness [m].
%          k_tl = Longitudinal wavenumber [Rad/m].
%          k_ts = Tranverse wavenumber [Rad/m].
%          alfa = Longitudinal bulk wave velocity [m/s].
%          beta = Transversal bulk wave velocity [m/s].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    19/11/2008  From Dimitry Zakharov suggestions.

%--------------------------------------------------------------------------
% Dispersion function and its derivative for simmetric modes.
%   delta_a = ((((k_ts.^2) - (k0.^2)).^2).*sin(k_tl.*h).*cos(k_ts.*h)) + ((4.*(k0.^2).*k_tl.*k_ts).*cos(k_tl.*h).*sin(k_ts.*h));
% d_delta_a = diff(delta_a)./diff(k0);

%------------------------------------------------
% New code from Dimitry analysis :)

        q = (((w0./beta).^2) - (2.*(k0.^2)));
        p = sqrt(((w0./alfa).^2) - (k0.^2));  % = k_tl
        s = sqrt(((w0./beta).^2) - (k0.^2));  % = k_ts

d_delta_a = (( - ( 8.*k0.*q.*sin(p.*h).*cos(s.*h) )...
               - ( ((q.^2).*h.*k0.*cos(p.*h).*cos(s.*h))./p )... 
               + ( ((q.^2).*h.*k0.*sin(p.*h).*sin(s.*h))./s )...
             )...  
             +...
             (   ( 8.*k0.*p.*s.*cos(p.*h).*sin(s.*h))...
               - ( (4.*(k0.^3).*s.*cos(p.*h).*sin(s.*h))./p )... 
               - ( (4.*(k0.^3).*p.*cos(p.*h).*sin(s.*h))./s )... 
               + ( 4.*(k0.^3).*h.*s.*sin(p.*h).*sin(s.*h) )... 
               - ( 4.*(k0.^3).*h.*p.*cos(p.*h).*cos(s.*h) )... 
             ));




                                     

         
         
         
         