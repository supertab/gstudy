function [N3,t,fs,Vs3_2,Vs3_3_0,Vs3_3_1,Vs3_3_2,S3_2,F3_2,Vs3_4,S3_4,F3_4,steering,Ns] = f_FRM_main(c,Z0,Amp_gain,ang_steer,Xc3,Yc3,Zc3,x_s3,y_s3,a_3,b_3,n_a3,n_b3,r3_type,R_3,P_field_2,P_field_3,X3,Y3,Z3,Ps3,theta,Nt,N3,t,fs,f_min,f_max,n_level,n_type,f_filter,f_FRM_taper,f_FRM_delay,f_multifocus_DAS,X_field_2,Y_field_2,z_field_2,f_pause,f_font,f3_plot_delays,f3_plot,f_plate_handle)
% This set of routines compose the Field Receiving Module (FRM) functions that computes the "final reception signals" 
% for a given reception region or aperture embedded into a plate emission field.
% Parameters:
%                      c = Speed of sound in air [m/s].
%                     Z0 = c*ro. Air characteristic impedance of a plane wave in [N.s/m^3] or [Rayls].
%               Amp_gain = FRM gain-amplifier factor [dB].
%              ang_steer = [Min. Max. step] values of reception steering angles [Deg].
%            Xc3,Yc3,Zc3 = Receiving elements center's coordinates.
%              x_s3,y_s3 = Width & high dimensions of reception elements [m].
%                a_3,b_3 = Half width & high of reception sub-elements according to [n_a3 n_b3]).
%              n_a3,n_b3 = Number of points by reception element along X & Y axis resp.
%                r3_type = Type of reception region (point, line, plane & shell).
%                    R_3 = Curvature radius of field reception region [m].
%              P_field_3 = Reception aperture field center point.
%               X3,Y3,Z3 = Coodinates of reception field (Array sensor points).
%                    Ps3 = IRM data cell array:  Ps = cell(Nt,1) zeros(Nx3,Ny3,N3);
%                  theta = Vector with incident angles of THS excitation field.
%                     Nt = Number of incident angles.
%                     N3 = Number of points of signals.
%                      t = Time vector for signals [s].
%                     fs = Sampling frequency [Hz].
%                n_level = If > 0 Add fixed white Gaussian 'noise_level' to FRM signals in [W] @R_load = 1ohm.
%                          [] -> Do not.
%                 n_type = 'fix' -> Add fix amount of power.
%                          'ref' -> Use maximun signal to measure power.
%               f_filter = 1 -> Activate sensor's frequency response.
%            f_FRM_taper = 1 -> Use tapered beamformer.
%            f_FRM_delay = Ad-hoc introduced delay of time vector [s].
%                f_pause = Inter program pause flag.
%                 f_font = Axis labels font size eg. 14.
%                f_title = Plot Title w/font size 14,etc.                   0 -> Do not plot titles.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    04/02/2009     Using data from engine: 'f_IRM_main_2D_2v3' v1 (11/12/2008).
% ver 1.1.0  17/02/2009     Inter program 'f_pause' added.
% ver 1.1.1  23/02/2009     Added 'P_field_3' parameter.
% ver 1.2    28/02/2009     'Amp_gain' added + Change in 'fs_IMR' --> 'fs' because of use downsampled data.
% ver 2.0    18/12/2009     'fs_IMR -> fs' eliminated + New DAS post-processor! (Delay And Sum)


  
fprintf(' 3. Initializing FRM -------------------------------\n');
%--------------------------------------------------------------------------
% 3. Begin calculations for Field Reception Module (FRM).
%--------------------------------------------------------------------------
% Assumed value for Array_C2 transference constant.
   k_couple = 32.6;       % [V/m/s]  -->  k = 1/p1 = 1/ 0.0307 [m/s/V]  From data Array_C2 @ele.0F (18/10/2005).
%--------------------------------------------------------------------------
[Nxc3 Nyc3] = size(Xc3);  
    N_r_ele = Nxc3*Nyc3;  % Number of receiving elements on reception aperture (array).
  [Nx3 Ny3] = size(X3);   % Nx3*Ny3 = Total number of points on reception field.
  
fprintf('Coupling k_couple = %.2f [V/m/s] \n',k_couple);
fprintf('          N_r_ele = %i  @(%i x %i) @@(%ix%i) \n',N_r_ele,Nxc3,Nyc3,n_a3,n_b3);
fprintf('   ele.dims:   2a = %.1f mm      2b = %.1f mm \n',x_s3*1000,y_s3*1000);
fprintf(' s-ele.dims: 2a_3 = %.1f mm    2b_3 = %.1f mm \n',2*a_3*1000,2*b_3*1000);
fprintf('      Nt = %i  @[',Nt); for i=1:Nt fprintf(' %.1f',theta(i)); end;  fprintf(']� \n'); % Number of present incidence angles.
% %--------------------------------------------------------------------------
% % Check memory requirements...
% [steer_ang,Ns] = f_create_steer_vector(ang_steer);
%             MB = Nt*Ns*Nxc3*Nyc3*N3*8/(1024*1024)
% if MB > 1024
%     
% end

%--------------------------------------------------------------------------
% 3.1 Compose individual element signals by adding points inside ele. boundaries.
[Ps3_1,N_s_ele,N_r_ele] = f_FRM_compose(Nxc3,Nyc3,Xc3,Yc3,Zc3,x_s3,y_s3,X3,Y3,Z3,Ps3,theta,Nt,N3,t,f_plate_handle,f3_plot);
%--------------------------------------------------------------------------
% 3.2.1 Check signal's sampling rate for DAS beamformer (possible up-sampling).
fprintf('3.2.1 Checking sampling rate @steer_s = %.2f�\n',ang_steer(3));
[N3,t,fs,f,Ps3_1] = f_check_fs_rate(c,x_s3,ang_steer(3),N3,t,fs,f_min,f_max,Ps3_1,f_FRM_delay);
%--------------------------------------------------------------------------
% 3.2.2 Convert signals.
[Vs3_2,N_s_ele] = f_FRM_convert(Z0,k_couple,x_s3,y_s3,N_s_ele,Nxc3,Nyc3,Ps3_1,Nt,N3,fs);
%--------------------------------------------------------------------------
% 3.2.3 Add noise & Amplify.
[Vs3_2] = f_FRM_amplify(Nxc3,Nyc3,Vs3_2,Nt,N3,Amp_gain,n_level,n_type,f_FRM_taper);
%--------------------------------------------------------------------------
% 3.2.4 Apply sensor's frequency response.
fprintf('3.2.4 ');
[Vs3_2] = f_freq_filter(N3,fs,f_min,f_max,Vs3_2,f_filter,f3_plot,f_plate_handle);
%--------------------------------------------------------------------------
% 3.2.5 If using 1D X-axis array, extract 2D spectrum for 1st. theta(k).
if Nyc3 == 1
    V32(:,:) = Vs3_2(1,:,1,:);
         V32 = V32';
 [S3_2,F3_2] = f_cal_spectra([fs 1/x_s3],V32);
% Conversion from wavenumber matrix -> Phase velocity values.
F3_2{2}(1,:) = 1;
         Cph = 2*pi*F3_2{1}./F3_2{2}; 
     F3_2{2} = Cph;
else
    S3_2 = 0;  F3_2 = 0;
end
%--------------------------------------------------------------------------
f_plot_signals = 1
f_FRM_plot_signals(Nxc3,Nyc3,X3,Y3,Z3,Vs3_2,Nt,N3,fs,t,f_plot_signals,f_plate_handle);
%--------------------------------------------------------------------------
% 3.3 DAS Beamforming.
% 3.3.0 Obtain array output at null signal delays (focalized beam).
fprintf(' 3.3.0 ');
          f_null_delay = 1; 
[Ns,steer_ang,Vs3_3_0,V34,S34,F34] = f_FRM_DAS_processor(c,N_r_ele,Nxc3,Nyc3,r3_type,R_3,P_field_3,Xc3,Yc3,Zc3,x_s3,Vs3_2,theta,0,Nt,N3,fs,f_multifocus_DAS,P_field_2,X_field_2,Y_field_2,z_field_2,f_null_delay,f3_plot_delays,f3_plot,f_plate_handle,f_font); % Add received signals (no delays).

%--------------------------------------------------------------------------
% 3.3.1 Obtain array output w/PWF equalization delays (infinite focus).
fprintf(' 3.3.1 ');
          f_null_delay = 0;
[Ns,steer_ang,Vs3_3_1,V35,S35,F35] = f_FRM_DAS_processor(c,N_r_ele,Nxc3,Nyc3,r3_type,R_3,P_field_3,Xc3,Yc3,Zc3,x_s3,Vs3_2,theta,[0 0 1],Nt,N3,fs,f_multifocus_DAS,P_field_2,X_field_2,Y_field_2,z_field_2,f_null_delay,f3_plot_delays,f3_plot,f_plate_handle,f_font); % Add equalized signals (PWF delays @0�).

%--------------------------------------------------------------------------
% 3.3.1b Obtain array output @theta(k)�.
% fprintf(' 3.3.1b ');
%            steer = [theta(1) theta(1) theta(1)]
%     f_null_delay = 0;
% [Ns,steering,s8] = f_FRM_DAS_processor(c,N_r_ele,Nxc3,Nyc3,r3_type,R_3,P_field_2,P_field_3,Xc3,Yc3,Zc3,x_s3,Vs3_2,theta,steer,Nt,N3,fs,f_null_delay,0,0,f_plate_handle,f_font); % Add equalized signals (PWF delays @theta(k)�).
%--------------------------------------------------------------------------
% 3.3.2 DAS beamforming at 'Ns' deflection angles!
fprintf(' 3.3.2 ');
         f_null_delay = 0;
[Ns,steering,Vs3_3_2,Vs3_4,S3_4,F3_4] = f_FRM_DAS_processor(c,N_r_ele,Nxc3,Nyc3,r3_type,R_3,P_field_3,Xc3,Yc3,Zc3,x_s3,Vs3_2,theta,ang_steer,Nt,N3,fs,f_multifocus_DAS,P_field_2,X_field_2,Y_field_2,z_field_2,f_null_delay,f3_plot_delays,f3_plot,f_plate_handle,f_font); % Add equalized signals (PWF delays @0�).
fprintf(' New: N3 = %i  @fs3 = %.1f MHz\n',N3,fs/10^6)

%--------------------------------------------------------------------------
if f_pause
    disp('Program paused. Press any key to continue...'); pause;
end
fprintf(' FRM done! :) \n\n')
delete(figure(30));











