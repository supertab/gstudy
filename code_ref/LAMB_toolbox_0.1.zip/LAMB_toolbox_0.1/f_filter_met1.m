function [s_fil] = f_filter_met1(s,H_fil)
% Apply filter transference 'H_fil' to signal 's'.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   26/12/2009

%---------------------------------------
% Old code active to save time! 
     S = fft(s);
 S_fil = S.*H_fil;
 s_fil = real(ifft(S_fil));


