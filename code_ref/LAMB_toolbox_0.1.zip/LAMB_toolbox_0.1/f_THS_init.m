function [et,S_z,Ps,S,Nf,Ncph,f,c_ph,k0] = f_THS_init(f_cph_mapping,c_ph,s_type,s_delay,n_burst,r_type,a_type,num_p,num_s,num_p_s,num_modes,mode_type,modes,N,Nf,Nt,theta,d,a,O,Nx,Ny,X_field,Y_field,z_field,x,X,Y,x_w,y_w,Ps,c,f0,f_min,f_max,fs,p_max,t,f,W,K,alfa,beta,Mu,ii_far,ii_near,f_pause,f_font,f_plate_handle)
% This function computes the Time Harmonic Solution (THS) signals for a given excitation and reception fields.
% 
% 
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    17/02/2008
% ver 1.1    14/04/2008     Added 'n_burst'  parameter.
% ver 2.0    12/05/2008     Change in name:  'f_init_THS' -> 'f_THS_init'.
% ver 3.0    19/11/2008     Change in F-Cph map sweep. 
% ver 3.1    08/01/2009     Change on reception field dimensions: [Nx Ny] = size(X_field) 1st.X-dim then Y-dim.
% ver 3.2    27/02/2009     's_delay' parameter added.


tic

f_quiet = 0;
fprintf('1.3. Starting THS... \n');
fprintf('(o_o) Warning: Radial displacements omitted. \n')
Ncph = max(size(c_ph));            % Number of phase velocity points to simulate. 
if f_cph_mapping
    %----------------------------------------------------------------------
    % 1)  Start frequency-phase_velocity 3D-mapping.
    fprintf('1.3.1 Starting normalized pressure 3D F-Cph map... \n')
num_modes = max(size(mode_type))
       Nf = max(size(f))           % Number of frequencies points to simulate. 
      S_z = cell(1,num_modes);      
    %-----------------------------
     S{1} = [1 0];                 % Use ideal normalized input spectrum for 3D map calculations.
                                   % This is implicitly assumed because 's_type = 1' (sinusoidal signal).
    %-----------------------------
    for k = 1:num_modes
        mode_type(k)
        S_z{1,k} = f_THS_compute(f_cph_mapping,mode_type(k),num_p,d,a,N,Nf,Nt,Nx,Ny,X_field,Y_field,z_field,X,Y,S,t,W,K,c_ph,alfa,beta,Mu,f_quiet);
    end %  s(:,:) = s_z(1,:,:);    % <-- Dummy casting 4 ploting!
    k0 = 0;
    %--------------------------------------------------------------------------
else
    if s_type <= 0
        %--------------------------------------------------------------------------
        % 2)  Begin THS field calculations at loaded fixed-incident angle 'Ps_theta'
        fprintf('1.3.2 Computing THS for simulated data... \n')
          S_z = cell(1,num_modes);
        for j = 1:num_modes
            fprintf('%s %i',modes{j},mode_type(j));
            S = f_extract_spectrum(num_p,f_max,fs,W{j}/(2*pi),Ps);  % Extract spectra for loaded field.
     S_z{1,j} = f_THS_compute(f_cph_mapping,mode_type(j),num_p,d,a,N,Nf(j),Nt,Nx,Ny,X_field,Y_field,z_field,X,Y,S,t,W{j},K{j},c_ph,alfa,beta,Mu,f_quiet);
        end
        k0 = K{1}; 
        %--------------------------------------------------------------------------
    else
        %--------------------------------------------------------------------------
        % 3)  Start THS field calculations for possible angle vector 'theta'.
        fprintf('1.3.3 Computing THS for simulated data... \n')
        if (Nt > 1) && (num_p == 1)
            fprintf('(o_o) Warning: Computing more than 1 angle for sigle \n')
            fprintf(' excitation point... do not have sense! :( \n theta = %f',theta'); pause;
        end     
        %--------------------------------------------------------------------------
        % Enable plot of apodizations if seleted.          
        p_flag = zeros(Nt,1); 
        if (a_type > 0) && (num_p > 1)  p_flag = 1; 
        else                            a_type = 0;  end;
        %--------------------------------------------------------------------------
        % [X Y] = Coodinates of excitation field 'points' [m].
        % [X_field Y_field z_field] = Coodinates of reception field [m].
          S_z = cell(Nt,num_modes);
        for i = 1:Nt
            fprintf('\n %.1f�',theta(i))
            for j = 1:num_modes
                fprintf(' %s %i',modes{j},mode_type(j));
                [Ps,p_flag] = f_gen_excitation(O,s_type,s_delay,n_burst,r_type,a_type,num_p,num_s,num_p_s,x,X,Y,x_w,y_w,c,theta(i),N,f0,f_min,f_max,fs,p_max,t,p_flag,0);
                          S = f_extract_spectrum(num_p,f_max,fs,W{j}/(2*pi),Ps); % Compute spectra for finite plane wavefront.
                   S_z{i,j} = f_THS_compute(f_cph_mapping,mode_type(j),num_p,d,a,N,Nf(j),Nt,Nx,Ny,X_field,Y_field,z_field,X,Y,S,t,W{j},K{j},c_ph,alfa,beta,Mu,f_quiet);
            end 
        end
        k0 = K{1};
%        Ncph = Nt;
        %--------------------------------------------------------------------------
    end
end

               et = toc;   % THS Enlapsed time [s]
[minutes,seconds] = f_convert_time(et);

%--------------------------------------------------------------------------
% Check time window: plot 1st. and last 'THS' signals. 
f_plot = 1;     %  S_z = zeros(Nx,Ny,N);
if ~f_cph_mapping && f_plot
    figure(f_plate_handle+6); hold on; grid on;
    for i = 1:Nt
        for j = 1:num_modes
             s(:,:) = S_z{i,j}(ii_near(1),ii_near(2),:); % Extract 1st. signal.
            s2(:,:) = S_z{i,j}(ii_far(1),ii_far(2),:);   % Extract last. signal.
           plot(t,s,'b');
           plot(t,s2,'r');
        end
    end
    M = cell(2,1);
    M{1} = '1st signal';
    M{2} = 'last signal';
    xlabel('t [s]','FontSize',f_font);  
    ylabel('THS-signals [m]','FontSize',f_font);
    legend(M,'FontSize',f_font)
    if f_pause, disp(' Program paused. Press any key to continue...'); pause;
    else  pause(2); 
    end
end
%delete(figure(f_plate_handle+6));
fprintf('THS done! tt = %i:%.1f  :)\n',minutes,seconds);




                
                