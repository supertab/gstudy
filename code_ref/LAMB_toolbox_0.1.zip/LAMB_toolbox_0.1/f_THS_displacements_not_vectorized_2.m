function [U] = f_THS_displacements_not_vectorized_2(N,Nf,d,mode_type,P,a,r,z,t,w0,k0,alfa,beta,Mu)
% This funtion computes the out-plane displacements for simmetric and anti-simmetric 
% straiht crested Lamb waves for a free layer; based on the work:
% "The influence of Finite-Sice Sources in Acousto-Ultrasonics"�
% from:  B.N.Pavlakovic & Joseph L. Rose (NASA report. 1994).
% The main difference with its predecessor 'f_THS_displacements' is the use
% of 'inline' coding in the core calculations.
%
% Obs.:
%             N = Number of points in time signal.
%            Nf = Number of frequency points to simulate in mode 'm'. 
%             d = plate thickness [m].
%     mode_type: 0 -> Symmetric modes.
%                1 -> Anti-symmetric modes.
%             P = Acoustic pressure frequency spectrum matrix (modulus,phase);
%             a = Radius of circular region [m]
%             r = Radial distance from origin to calculation point.
%             z = Vertical coodinate within the plate [m].
%             t = Time domain vector for signal [s].
%            w0 = Frequency vector [Rad/s].
%            k0 = Wavenumber vector [Rad/m].
%          k_tl = Longitudinal wavenumber [Rad/m].
%          k_ts = Tranverse wavenumber [Rad/m].
%          alfa = Longitudinal bulk wave velocity [m/s].
%          beta = Transversal bulk wave velocity [m/s].
%            Mu = Lame constant [Pa].
%             U = 'N-Point' displacement matrix:  [u_r0  u_z0
%                                                  u_r1  u_z1
%                                                     ... 
%                                                  u_rN  u_zN]
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    01/06/2008       Use non vectorized coding to avoid out of memory problems.
% ver 2.0    01/12/2008       Derivative terms corrected thanks 2 Dimitry Zakharov suggestions!!! :)

    
%--------------------------------------------------------------------------  
 k_tl = sqrt(((w0/alfa).^2) - (k0.^2));    % Longitudinal Lamb wavenumber vector [Rad/m].
 k_ts = sqrt(((w0/beta).^2) - (k0.^2));    % Transversal Lamb wavenumber vector [Rad/m].


%--------------------------------------------------------------------------
%  Observation 2 remember: We have intentionally omit the division by 'k0'
% in 'F0'; because later this term cancells out with one equal included in 
% the numerators of 'u_r' and 'u_z'.
%                    besselj(nu,Z)
  F0 = (a.*P(:,1).*besselj(1,k0*a))./k0;          % 'Hankel trasform*k0' of 'Piston-like' radial axisymmetric normal traction distribution.
% F1 = (2.*P(:,1).*besselj(2,k0*a))./(k0.^2);     % 'Hankel trasform*k0' of 'Parabolic' radial axisymmetric normal traction distribution.  
%--------------------------------------------------------------------------
%  H = besselh(nu,Z) uses K = 1.
H0_1 = besselh(0,k0*r);                           % Hankel funtion of order '0' with k = 1.
%H1_1 = besselh(1,k0*r);                          % The same but: order '1' with k = 1 (4 radial displacements only!)
                 
 u_z = zeros(Nf-1,1);
   u = zeros(1,N);
   U = zeros(1,N);
switch mode_type
    case 0   
    %----------------------------------------------------------------------
    % "Symmetric" mode displacements
%   [d_delta_s] = f_cal_delta_s_numeric_3(w0,k0,d/2,alfa,beta);
    [d_delta_s] = f_cal_delta_s3(w0,k0,k_tl,k_ts,d/2,alfa,beta);  
    [gamma_s_z] = f_cal_Gamma_s_functions(k0,k_tl,k_ts,d/2,z);  % Calculate Gamma coefficients.    
    
            M_s = k0.*gamma_s_z./d_delta_s;
            u_z = abs( (i*pi/(2*Mu)).*F0.*M_s.*H0_1 );
            
    case 1
    %----------------------------------------------------------------------
    % "Anti-symmetric" mode displacements
%   [d_delta_a] = f_cal_delta_a_numeric_3(w0,k0,d/2,alfa,beta);    
    [d_delta_a] = f_cal_delta_a3(w0,k0,k_tl,k_ts,d/2,alfa,beta);  
    [gamma_a_z] = f_cal_Gamma_a_functions(k0,k_tl,k_ts,d/2,z);  % Calculate Gamma coefficients.
               
             M_a = k0.*gamma_a_z./d_delta_a;
             u_z = abs( (i*pi/(2*Mu)).*F0.*M_a.*H0_1 );

    otherwise
    disp('Mode type error! "0" and "1" only allowed...')
    error(' :(  ')
%            M_a = real(k0.*gamma_a_z./d_delta_a);
%            u_z = real( (i*pi/(2*Mu)).*F0.*M_a.*H0_1 );
%            u_z = abs( 1./d_delta_a );
%            u_z = (i*pi/(2*Mu)).*F0.*M_a.*H0_1;            
end % End switch.


%--------------------------------------------------------------------------
% Calc. of out-of-plane displacements using non vectorized 
% code to avoid out of memory problems.
for n = 1:Nf
    phase = k0(n)*r - w0(n).*t - P(n,2); % Calculate the phase part.
        u = u_z(n)*exp(i*phase);         % Comp. Out-of-plane displacement signal.
        U = U + u;                       % Add z_displacement signal for frequency point {w0(n);k0(n)}.
end
%--------------------------------------------------------------------------
% We use only (N/2) possitive frequencies in 'ifft'algorithm
% of 'N' possible freqs; from which only 'Nf' are not '0'.
U = real((1/(N/2))*U)';  % Return final vector w/out_of_plane displacement [m].





% % %----------------------------------------------------------------------
% % % Apply freq. response of circular transducer
% % load matlab_data_transf_TT1-MHz
% %  f0 = w0/(2*pi);
% %   S = interp1(F2,S2,f0,'cubic');
% %   S = S(:,1)/max(S(:,1));
% % u_z = u_z.*S;
% % %----------------------------------------------------------------------




