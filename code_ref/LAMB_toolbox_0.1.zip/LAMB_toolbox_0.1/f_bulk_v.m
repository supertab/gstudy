function [alfa,beta] = f_bulk_v(ro,lambda,mu)
% This function computes the propagation 
% bulk-wave velocities for the 3-layer system
% Obs:    
%     Lame-consts. units = [Pa] 
%           Density (ro) = [Kgr/m^3]
%              alfa/beta = [m/s]
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0    04/06/2007   
% ver 1.1    15/06/2007   Simplified version

%--------------------------------------------------------------------------
% Material layer bulk wave velocities.
alfa = sqrt((lambda + 2*mu)/ro);     % Longitudinal bulk-wave velocity for L1
beta = sqrt(mu/ro);                  % Shear bulk-wave velocity for L1

