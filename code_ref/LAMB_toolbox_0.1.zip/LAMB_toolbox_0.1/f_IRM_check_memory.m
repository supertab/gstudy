function [N_total] = f_IRM_check_memory(N_limit,Nx2,Ny2,N4)
% Check computer available memory for IRM calculations.
%            
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
%
% ver 1.0    28/12/2008
% ver 1.1    02/12/2009


fprintf(' Checking available memory... \n');
%--------------------------------------------------------------------------
      v = ver('matlab');
N_total = Nx2*Ny2*N4*8;
if v.Version(1) == '6'
    if N_total > N_limit
        fprintf(':( Sorry: not enought memory... decrease number of points! \n')
        fprintf('   N_total = %.2f MB!    N_limit = %.2f MB \n',N_total/(1024^2),N_limit/(1024^2));
        error(' ')
    else
        fprintf('   N_total = %.2f MB     N_limit = %.2f MB \n',N_total/(1024^2),N_limit/(1024^2));
    end
else
    fprintf(' Ups! uncomplete code 4 Matlab %s\n',v.Version)
    disp('(o_o) Warning: continuing without memory check...')
%     max_mem_block = feature('memstats'); %See also -> 'out = daqmem' or  'chkmem' (matlab 7.4)
%     if N_total > max_mem_block
%         fprintf('(o_o) Warning: maximum memory block lengh exceeded... decrease number of points! \n')
%     end
%    fprintf(':) N_total = %.2f MB  Large block = %.2f MB \n',N_total/(1024^2),max_mem_block/(1024^2));
    fprintf(' Memory used = %.2f MB  \n',N_total/(1024^2));
end
%--------------------------------------------------------------------------



