function [alfa_r_i,alfa_i] = f_IRMc_alfa_i_opt2 (c,i_T0,i_TD,N,T0,TSi,TD,t,z,di)
% Funcion de calculo de los angulos  'alfa_i'
%
% ver 1.0
% ver 2.0                 Agregado de epsilon a sigma p/evitar problemas de div. x cero
% ver 3.0    30/07/2004   F. Optimizada
% ver 4.0    15/10/2004   Cambio en la Def. de alfa_r_i, ver '*'
% ver 5.0    26/11/2004   greg. '<=' en:  (T0 <= t(i)) && (t(i) <= TSi)
% ver 5.1    28/01/2008   Uso de vectores columna p/'h'.
% ver 5.2    12/01/2009   Change in name: 'f_cal_alfa_i_opt2' --> 'f_IRMc_alfa_i_opt2'.


alfa_r_i = zeros(N,1);
  alfa_i = zeros(N,1);   
 epsilon = 10^-6;         % Esto es p/ evitar la division x cero, en caso de que sigma sea nulo

for i = i_T0:i_TD
      if (T0 <= t(i)) && (t(i) <= TSi)  % Los '<=' incluyen los puntos de contacto de la esfera al moment. del arribo y llegada al borde
         alfa_r_i(i) = sign(di) * pi/2;    % '*', agregado de:  sgn(di), ver Fin Apendix B paper
         
      elseif (TSi < t(i)) && (t(i) <= TD)
          r_sigma = sqrt((c*t(i))^2 - z^2);
          if  di > r_sigma
             disp(' Error!:   di > r_sigma  => alfa_i  superara val. limites (+-pi/2)');
             pause
          elseif r_sigma <= epsilon
             r_sigma = epsilon;
                  di = 0;    % por seguridad forzamos que alfa_i de cero...
             disp('Cuidado!, sigma cercano a "0",  o negativo.....................');
          end               
         alfa_r_i(i) = sign(di) * asin (abs(di)/r_sigma);
           alfa_i(i) =  alfa_r_i(i);       % tanto alfa_r_i, como alfa_i son =, para t>TSi
      end    
end

%1;

