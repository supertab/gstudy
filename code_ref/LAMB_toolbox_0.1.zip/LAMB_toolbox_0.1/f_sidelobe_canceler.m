function [t2,y,y_fil] = f_sidelobe_canceler(d,M,N,n_level,fs_IRM,f_min,f_max,t3,Ps3,n1,n2,f_def_x_a)
% This function implements a sidelobe canceler (SLC) for a given set of
% signals of N point, coming from 'M' sensors.
% Parameters:
%           d = Space between sensors [m].
%           M = Number of sub-array sensor elements.
%           N = Longitude of block data for SLC.
%     n_level = Level in [W] of WG noise added.
%      fs_IRM = Imput data sampling frequency [Hz].
%          t3 = Imput data time vector [s].
%         Ps3 = Imput data 'column' signal matrix.
%       n1,n2 = Input data cutting window.
%   f_def_x_a = Type of definition of 'x_a' signal
%           0 -> x_a = Ps2(:,central censor).
%           1 -> x_a@theta 0�.
%           2 -> x_a@theta A0�.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   25/03/2010

%-----------------------------
% Prepare data.
          
         N1 = n2-n1+1
    Ps1(:,:) = Ps3; % Ps3{1}(:,1,:);
%         Ps1 = Ps1';
 [N3,Npts3] = size(Ps1);
        Ps1 = Ps1(n1:n2,:);
         t1 = t3(n1:n2,1);
%-----------------------------
% Add WG noise        
n_level_dB = 10*log10(n_level); % Here 'n_level' is expressed in [W].
%Ps2n = zeros(N1,Npts3);
for j = 1:Npts3
           s = Ps1(:,j) + wgn(N1,1,n_level_dB);  % ->  s = s + n;
    Ps1(:,j) = s(:);
end
%----------------------------
% Downsample data.
   dt = max(t1) - min(t1);
  fs2 = fs_IRM;  %fs_IRM/10;
   N2 = N1;  %floor(dt*fs2);
   t2 = (0:1/fs2:(N2-1)/fs2)'+min(t1);  
  Ps2 = zeros(N2,Npts3);
for j = 1:Npts3
           s = Ps1(:,j);
    Ps2(:,j) = f_resample_data(N1,N2,fs_IRM,fs2,t1,t2,s(:),1);           
end
%-----------------------------
% Define signals: 'x_mc' & 'x_a'
     n_a = ((M-1)/2)+1 % Central sensor of sub-array.
  cph_S0 = 5440;        
  cph_a0 = 2550;
delta_s0 = d/cph_S0;  
delta_a0 = d/cph_a0;    
    x_mc = 0; 
     x_a = zeros(N2,M);
for j = 2:M
        s = Ps2(:,j);
     %---------------------        
     % x_mc => S0   
    delay = -(j-1)*delta_s0;
     [s0] = f_delay_signal(fs2,N2,delay,s(:),1);
     x_mc = x_mc + s0; % x_mc = s(n) + i_mc(n) + w(n)
     %---------------------       
     % x_a => A0
     if f_def_x_a == 1
         disp('Def.1:  x_a@0�')
         x_a(:,j) = s(:);  % x_a = s(n) + i_mc(n) + w(n);   s(n) < w(n)
     elseif f_def_x_a == 2
         disp('Def.2:  x_a@Theta_A0� ')
         delay = -(j-1)*delta_a0;
            a0 = f_delay_signal(fs2,N2,delay,s(:),1);
      x_a(:,j) = a0;  % x_a = s(n) + i_mc(n) + w(n);   s(n) < w(n)
     else
         % Old. definition.
         disp('Def.0:  x_a = Ps2(:,n_a) ')
         x_a(:,j) = Ps2(:,n_a);  % x_a = s(n) + i_mc(n) + w(n);   s(n) < w(n)
     end
end
%delay = (n_ele_sub_a-2)*delta_s0;
% x_mc = f_delay_signal(fs_IRM,N1,delay,x_mc(:),1);

%-----------------------------
% Obtain analytical signals.
 Ps2 = hilbert(Ps2);
x_mc = hilbert(x_mc);
 x_a = hilbert(x_a);
%----------------------------
%         Apply SLC
% delay = 0, M = 200, W = 0.0001
%----------------------------
    y = zeros(N2-M+1,1);
for n = 1:N2-N+1        
        %-----------------------------
        % R = x_a(n:n+M-1)*x_a(n:n+M-1)'; % Old. wrong definition.
        %-----------------------------
        X = Ps2(n:n+N-1,1:M);             % Input data matrix.
%        X = Ps2(n:n+N-1,M:-1:1);             % Input data matrix.
       Ra = X'*X;                         % Estimate of the correlation matrix.       
      Rai = inv(Ra);
     r_ma = (x_a(n,:).').*x_mc(n)';
      c_a = Rai*r_ma;
     y(n) = x_mc(n) - c_a'*(x_a(n,:).');
end

    y = real(y);
y_fil = f_ideal_bp_filter(y(:),f_min,f_max,fs2,1);

