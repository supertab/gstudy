function [s] = f_FRM_compose_ele_signal(X3,Y3,Z3,Ps3,theta_k,N3,i_x,j_y,f_plot_ele,f_handle)
% This function compose the total acoustic pressure signal for a single receiving element; 
% by adding all 'Ps3' point signals belonging to indexs% [i_x j_y].
% Paramenters:
%               X3,Y3,Z3 = Coodinates of receiving field.
%                    Ps3 = IRM data cell array:  Ps = cell(Nt,1) zeros(Nx3,Ny3,N3);
%                theta_k = Index for incident angle (theta) of THS excitation field.
%                     N3 = Number of points of signals.
%                i_x,j_y = Indexs of signals corresponding to element 'i' on receiver aperture.
%             f_plot_ele = 1 -> Plot points corresponding to receiving element.
%                          0 -> Do not plot.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    06/01/2009


num_s = length(i_x);  % Number of signals to add for receiving element.
    s = zeros(1,N3);
   ps = zeros(1,N3);
for k = 1:num_s
       ps(1,:) = Ps3{theta_k}(i_x(k),j_y(k),:);
             s = s + ps;    % Calculate total signal by superposition of all Lamb modes simulated!
             if f_plot_ele
                 figure(f_handle);
                 if f_impar(f_plot_ele,2)  plot3(X3(i_x(k),j_y(k))',Y3(i_x(k),j_y(k))',Z3(i_x(k),j_y(k))','g.');
                 else                      plot3(X3(i_x(k),j_y(k))',Y3(i_x(k),j_y(k))',Z3(i_x(k),j_y(k))','y.');  end;
             end        
end        

s = s'; % Return signals by columns.



