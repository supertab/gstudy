function [d_delta_s] = f_cal_delta_s3(w0,k0,k_tl,k_ts,h,alfa,beta)
% This funtion calculates the derivatives of the dispersion functions 
% for straight crested symmetric Lamb wave modes in a free layer.
% Calculation are based on the work : 
%                          "The influence of Finite-Sice Sources in Acousto-Ultrasonics"�
%                    from:  B.N.Pavlakovic & Joseph L. Rose (NASA report. 1994)
% 
% Obs.:      w0 = Angular frequency vector [rad/s].
%            k0 = Wavenumber vector [Rad/m].
%             h = Half plate thickness [m].
%          k_tl = Longitudinal wavenumber [Rad/m].
%          k_ts = Tranverse wavenumber [Rad/m].
%          alfa = Longitudinal bulk wave velocity [m/s].
%          beta = Transversal bulk wave velocity [m/s].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    04/09/2007   
% ver 2.0    01/12/2007  Correction maded:  '/diff(k0)' added!
% ver 2.1    04/01/2008  'd' parameter eliminated.
% ver 3.0    19/06/2008  New code based in analitic derivative!
% ver 4.0    21/06/2008  New code based in analitic derivative from NASA Report.
% ver 5.0    19/11/2008  Changes from Dimitry Zakharov suggestions.

%--------------------------------------------------------------------------
% Dispersion function and its derivative for simmetric modes.
%   delta_s = ((((k_ts.^2) - (k0.^2)).^2).*cos(v_l).*sin(v_s)) + ((4.*(k0.^2).*k_tl.*k_ts).*sin(v_l).*cos(v_s)); 
% d_delta_s = diff(delta_s)./diff(k0);        % Old code...

%------------------------------------------------
% New code from Dimitry analysis :)

        q = (((w0./beta).^2) - (2.*(k0.^2)));
        p = sqrt(((w0./alfa).^2) - (k0.^2));  % = k_tl
        s = sqrt(((w0./beta).^2) - (k0.^2));  % = k_ts

d_delta_s = (( - ( 8.*q.*k0.*cos(p.*h).*sin(s.*h) )...
               + ( ((q.^2).*h.*k0.*sin(p.*h).*sin(s.*h))./p )... 
               - ( ((q.^2).*h.*k0.*cos(p.*h).*cos(s.*h))./s )...
             )...  
             +...
             (   ( 8.*k0.*p.*s.*sin(p.*h).*cos(s.*h))...
               - ( (4.*(k0.^3).*s.*sin(p.*h).*cos(s.*h))./p )... 
               - ( (4.*(k0.^3).*p.*sin(p.*h).*cos(s.*h))./s )... 
               - ( 4.*(k0.^3).*s.*h.*cos(p.*h).*cos(s.*h) )... 
               + ( 4.*(k0.^3).*p.*h.*sin(p.*h).*sin(s.*h) )... 
             ));




                                     
% %------------------------------------------------
% % Code as NASA in report.
%          d = 2*h;
%        v_l = k_tl.*(d/2);
%        v_s = k_ts.*(d/2);
% %
% % d_delta_s = (k0.*((k_ts.^2) - (k0.^2))).*( (-8.*cos(v_l).*sin(v_s)) +...
% %                                            ( ((k_ts.^2) - (k0.^2))*( (d./(2.*k_tl)).*sin(v_l).*sin(v_s) + (d./(2.*k_ts)).*cos(v_l).*cos(v_s) ) )...
% %                                          )...
% %                                          + ( k0.*( 8.*k_tl.*k_ts - 4.*(k0.^2).*(k_ts./k_tl + k_tl./k_ts)  ).*sin(v_l).*sin(v_s) )...
% %                                          + ( 2.*(k0.^3).*( k_ts.*d.*cos(v_l).*cos(v_s) + k_ts.*d.*sin(v_l).*sin(v_s) ) );
% 
% %------------------------------------------------
% % Code with corrections...
% d_delta_s = (k0.*((k_ts.^2) - (k0.^2))).*( (-8.*cos(v_l).*sin(v_s)) +...
%                                            ( ((k_ts.^2) - (k0.^2))*( (d./(2.*k_tl)).*sin(v_l).*sin(v_s) - (d./(2.*k_ts)).*cos(v_l).*cos(v_s) ) )...
%                                          )...
%                                          + ( k0.*( 8.*k_tl.*k_ts - 4.*(k0.^2).*(k_ts./k_tl + k_tl./k_ts)  ).*sin(v_l).*cos(v_s) )...
%                                          - ( 2.*(k0.^3).*( k_ts.*d.*cos(v_l).*cos(v_s) - k_tl.*d.*sin(v_l).*sin(v_s) ) );

                                     
                                     

                                     
                                     
                                     
        








