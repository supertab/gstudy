function [t_delay_FOPD] = f_cal_t_delay_FOPD(c,R,N,O_ref,O_ele,j,k,ang_deflec,f_plot,f_handle,f_font,f_color,f_quiet)
% Funcion de calculo de los tiempos de demora necesarios p/generar un FOPD
% (Frente de Onda Plano Deflectado). 
% Obs. este FOPD puede tener deflexion nula tambien...
% Donde si: 
%             ang_deflec > 0   =>   deflecta horario
%             ang_deflec < 0   =>   deflecta anti-horario
%
% 
% ver 1.0     29/03/2006
% ver 1.1     28/02/2007    Inversion d/convesion de signos de giro.
% ver 2.0     09/01/2009    Simplify version w/no plotting capability.
% ver 3.2     05/02/2009    Quiet flad added.
% ver 3.3     23/02/2009    Simplified version.
% ver 3.4     02/12/2009    Selective plot figure added.

if f_plot
    if (f_handle <= 0) || isempty(f_handle)
        f_handle = 999005; 
    end
    figure(f_handle); hold on; grid on;    
    xlabel('X [m]','FontSize',f_font); ylabel('Y [m]','FontSize',f_font); zlabel('Z [m]','FontSize',f_font);
end
%--------------------------------------------------------------------------
if abs(ang_deflec) <= 80
    % -------------------------------------------------
    % Deteccion del plano del array (extraccion de coordenadas utiles).
    [plane_index] = f_array_plane(O_ele);
    switch plane_index
        case 1  % Array defined in YZ-plane
            if ~f_quiet  disp('     YZ-plane active..');  end;
            xy_ref = O_ele(:,2:3);
             O_ref = [O_ref(2) O_ref(3)];
        case 2  % Array defined in XZ-plane
            if ~f_quiet  disp('     XZ-plane active..');  end;
            xy_ref = [O_ele(:,1) O_ele(:,3)];
             O_ref = [O_ref(1) O_ref(3)];
        case 3  % Array defined in XY-plane
            if ~f_quiet  disp('     XY-plane active..');  end;
            xy_ref = O_ele(:,1:2);
             O_ref = [O_ref(1) O_ref(2)];
        otherwise
            disp(' :( Error! Array-plane definition...can not be other than coord. planes!!'); error(' ');
    end
    % -------------------------------------------------
    % Calcula los puntos de interseccion 'Ai' del FOP
    [m_fop,b,y] = f_recta_P0_P1(O_ref,xy_ref(j,:),xy_ref(k,:),1);     % recta del Frente de Onda Plano principal 
    FOP_k = [xy_ref(j,:) ; xy_ref(k,:)];    
    
    if f_plot  figure(f_handle); plot3(FOP_k(:,1),[0 0],FOP_k(:,2),'r'); end % Plot del Frente de Onda Plano    
    % -------------------------------------------------
    % Calcular p/ FOPD(ang_deflec�)
    ang_deflec_r = ang_deflec*pi/180;  
         [Di,id] = f_frente_onda_def(O_ref,xy_ref,m_fop,ang_deflec_r,j,k,N,-R,f_plot,f_handle,f_color);  % cal. distancias/puntos de ecualizacion p/FOPD    
    % -------------------------------------------------
     t_advance_FOPD = id*(1/c);                             % tiempos de 'avance' del FOPD en [seg.]
             t_FOPD = max(t_advance_FOPD) - t_advance_FOPD; % Conversion a tiempos Demora del FOPD p/c/u de los eles. del Array
    % -------------------------------------------------
    % Puesta a zero de los delay de los eles. no-utilizados
       t_delay_FOPD = zeros(N,1);
  t_delay_FOPD(j:k) = t_FOPD(j:k);   % tiempos de demora finales de los eles. utilizados p/FOP.
%--------------------------------------------------------------------------
else
    disp('(o_o) Warning: can not computu delays for angles > +/-60�...')
    disp(' Nothing to do... :( ')
end

