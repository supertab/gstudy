function [s] = f_s_burst_square(s_amp,f0,t,nro_b,w_type)
% Function for computing a square burst signal.
% Where:
%     s_amp = Burst maximum amplitude; typically in [Pa] or [V].
%        f0 = Senoid frequency.
%         t = Time axis vector [s].
%     nro_b = Number of burst cycles.
%    w_type = window type:   
%             0 -> rectangular   
%             1 -> sinusoidal window. 
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    16/02/2009
% ver 2.0    27/02/2009     Anti-simmetric burst type added.
% ver 2.1    14/01/2010     Correction on 't' vector.

t = t - min(t); % Reset time vector.

if nro_b >= 0  
    if nro_b == 0 
        disp(' (o_o) Warning. Using default setting:  nro_b = 10 ');
        nro_b = 10;
    end
    f_anti_simmetric = 0;
else
    nro_b = abs(nro_b);
    f_anti_simmetric = 1;
end

[N,N2] = size(t);
if N <= N2   
    N = N2;  t = t';   % Convert row vector in column vector.
end  

%--------------------------------------------------------------------------
% Generate sinusoidal signal....and count corresp. samples for 'nro_b' cycles.
w = 2*pi*f0;
       
       
 n = 1:nro_b; 
Ti = 1/f0;     %frecuencia 

 
% Creacion del vector de la senyal de salida
    s = zeros(N,1);    
   iy = 1;
 flag = 1;
 tmax = 0;
    h = 1;
for i = 1:(nro_b*2)
    tmax = tmax + Ti/2;  % Tiempo en el cambia la se�al de salida
    while t(iy) < tmax
        s(iy) = flag;
           iy = iy + 1;
    end
    if flag == 1 
        flag = -1; 
    else 
           h = h + 1;
        flag = 1;  
    end
end
s = s_amp*s;

%--------------------------------------------------------------------------
ii = find(abs(s));
if ii > N*0.9
   disp('Warning: Burst aproaching "t_max" limit...') 
   figure (880); hold; grid; plot(b,'b'); plot(b,'r.'); pause
elseif ii >= N
   disp('Error: Burst signal has reached max. longitude limit "N"!! ') 
   disp(' :('); error(' ');
end    

%--------------------------------------------------------------------------
% Apply selected window!
if f_anti_simmetric  fprintf(' Anti-simmetric ');
else                 fprintf(' Simmetric ');    end;
switch(w_type)
    case 0
        fprintf('square burst w/Rectangular window @%i cycles \n',nro_b)
    case 1
        fprintf('square burst w/Sinusoidal window @%i cycles \n',nro_b)
        w = sin(w/(2*nro_b)*t);
        s = w.*s;
    otherwise
        disp(' :(  Ups! Windowing not implemented yet!! see: "f_s_burst_sin"...')
        pause;  disp(' :( ');  error(' ');
end

%--------------------------------------------------------------------------
% If anti-simmetric flag active... then convert signal.
if f_anti_simmetric
       ii = find(s < 0);
    s(ii) = 0;
end


% figure(1234); hold on; grid on;
% plot(t,s); plot(t,s,'g.');





