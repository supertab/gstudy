function [W0,K0,Cg0,Nf,num_modes,mode_type,lambda] = f_THS_extract_BW(f_cph_mapping,modes,mode_type,f_s,f0,f,F,K,d,a,plate_type,f_font,f_title)
% This funtion extracts the mode frequencies contained in the selected bandwidth.
% for the point load time signal calculations.
% Obs.:   
%      f_cph_mapping = Flag 4 frequency-phace velocity mapping tool.
%                      0 -> Disable
%                      1 -> Enable mapping -> 's_type = sinusoidal' only.
%              modes = Lamb modes to simulate in string format.
%          mode_type = Type of Lamb modes:   
%                      0 -> Simetric
%                      1 -> Anti-simetric
%                f_s = Frequency step in bandwidth = fs/N [Hz].    
%                 f0 = Central frequency in bandwidth [Hz].    
%                  f = Desired operating frequency bandwidth [Hz].    
%                  F = Cell array w/frequency mode vectors [Hz].
%                  K = Cell array w/wavenumber mode vectors [Rad/m].
%                  d = Plate width [m];
%                  a = Radius of circular region [m].
%         plate_type = String w/plate type material name.
%             f_font = Axis labels font size eg. 14.
%            f_title = Plot Title w/font size 14,etc.                0 -> Do not plot titles.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    05/09/2007
% ver 1.1    15/09/2007   Elimination of {0} entries in cell arrays.
% ver 1.2    11/09/2007   Calculation of minimum wavelengt: 'lambda_min' added.
% ver 2.0    29/11/2007   Simplified version.
% ver 2.1    11/12/2007   All mode's common frequency vector 'f'. 
% ver 2.2    19/03/2008   Return of group velocity data 'Cg0' + plot or curves in differnt colors.
% ver 3.0    07/05/2008   Variable number of freqs. for mode added.
% ver 3.1    29/12/2008   Simplified printing version.
% ver 3.2    15/01/2009   One frequency possibility problem solved! 
% ver 3.3    09/03/2009   Plot of titles & 'plate_type' added.
% ver 3.4    21/03/2010   Return waveleght info at f0 added.
% ver 3.4.1  12/05/2010   Error corr. in cal. of lambda0


%--------------------------------------------------------------------------
figure(991); hold on; grid on; 
xlabel('f [Hz]','FontSize',f_font); 
ylabel('Phase velocity: Cph [m/s]','FontSize',f_font);
if f_title > 0
    title(['Lamb wave dispersion curves for ',plate_type,' plate @',num2str(d*1000),' mm'],'FontSize',f_title);
end
ah = gca;                  % Obtain current axis handle.
set(ah,'FontSize',f_font); % Set axis font size.

figure(992); hold on; grid on; 
xlabel('f [Hz]','FontSize',f_font); 
ylabel('Group velocity: Cg [m/s]','FontSize',f_font); 
if f_title > 0
    title(['Lamb wave dispersion curves for ',plate_type,' plate @',num2str(d*1000),' mm'],'FontSize',f_title); disp(' ');
end
ah = gca;                  % Obtain current axis handle.
set(ah,'FontSize',f_font); % Set axis font size.
%--------------------------------------------------------------------------
% Mode frequencies interpolation
   
if isempty(f)
    disp(' :(  Frequency vector should contain at least 1 frequency...');
    delete(figure(991));  delete(figure(992));  error(' ');
else    
  num_modes = max(size(mode_type));
         Nf = zeros(num_modes,1);                              % Vector with number of frequencies for mode.
         K0 = cell(num_modes,1);                               % Wave numbers for mode 'm'.
         W0 = cell(num_modes,1);                               % Frquencies for mode 'm'. 
        Cg0 = cell(num_modes,1);                               % Group velocities for mode 'm'.   
          i = 1;
          n = num_modes;
   %--------------------------------------------------------------------------
   for m = 1:num_modes
                  N = max(size(F{m}));                         % Number of frequency points in mode 'm'.
                 Cg = (diff(2*pi*F{m})./diff(real(K{m})));     % Compute total group velocity curve [m/s].
                 Cg = [Cg ;Cg(N-1)];                           % Correct vector longitud by 1 loosed sampled.
                Cph = 2*pi*F{m}./real(K{m});                   % Initial phase velocity vector.
          [N_f,W_0] = f_THS_find_mode_freq(f_cph_mapping,f,F{m},modes{m});
          
          if ~isempty(N_f)
                  Nf(i) = N_f;
                  W0{i} = W_0;
              if N_f == 1
                     W1 = [W_0; (f+f_s)*(2*pi)];                    % Auxiliar vector for group velocity calculation.
                  K0{i} = interp1(2*pi*F{m},K{m},W1,'spline');     % Interpolate wavenumbers for mode 'm'.        
                 Cg0{i} = (diff(W1)./diff(real(K0{i})));           % Compute used group velocity part [m/s].
                  K0{i} = K0{i}(1);
              else
                  K0{i} = interp1(2*pi*F{m},K{m},W0{i},'spline');  % Interpolate wavenumbers for mode 'm'.        
                 Cg0{i} = (diff(W0{i})./diff(real(K0{i})));        % Compute used group velocity part [m/s].
                 Cg0{i} = [Cg0{i} ;Cg0{i}(Nf(i)-1)];               % Correct vector longitud by 1 loosed sampled.             
              end      
              m_type(1,i) = mode_type(m);
                     Cph0 = W0{i}./real(K0{i});                    % Final phase velocity vector.
                       k0 = interp1(F{m},K{m},f0,'spline');   % Interpolate wavenumber at f0   
                     
              lambda(1,i) = min(2*pi./real(K0{i}));                % Calculate minimum wavelenght for mode 'i'.
              lambda(2,i) = 2*pi/real(k0);                         % Calculate wavelenght at f0 mode 'i'.
              lambda(3,i) = max(2*pi./real(K0{i}));                % Calculate maximum wavelenght for mode 'i'.        
        
              f_THS_plot_Lamb_modes(mode_type(m),modes{m},F{m},Cph,Cg,'b.',W0{i}/(2*pi),Cph0,Cg0{i});
              i = i + 1;
          else
              f_THS_plot_Lamb_modes(mode_type(m),modes{m},F{m},Cph,Cg,'r.',[],[],[]);
              if num_modes > 1
                  fprintf(' (o_o)  Warning: mode  %s  is outside BW... \n\n',modes{m});
                  n = n - 1;
                  Nf = Nf(1:n);   W0 = {W0{1:n}}';   K0 = {K0{1:n}}';   Cg0 = {Cg0{1:n}}';
              else
                  fprintf(':(  Selected BW did not include mode:  %s !! \n',modes{m});  error(' ');
              end
          end
   end % end for m...
   %--------------------------------------------------------------------------   
   if ~isempty(Nf)
       num_modes = max(size(Nf));  % Final active 'num_modes'.
       mode_type = m_type;
    else
        fprintf('\n\n :(  Selected BW: %d; %d  does not include any modes: \n', min(f),max(f));
        modes
        error(' ');
    end      
end % if max(size(f))...



