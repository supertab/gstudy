function [SNR_dB] = f_estimate_SNR(fs,f0,s,DC_level,f_plot)
% Returns the Signal to Noise Ratio (SNR) in dB of a given signal.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    28/02/2009



      s = s(:);
      N = length(s);
      t = (0:1/fs:(N-1)/fs)';
%---------------------------------------------------------      
% Determinate filter parameters.
  f_fil = f0/10          % Criteria choosed for determination of cutoff freq. of the moving average filter (maf).
  N_maf = fs/f_fil;      % Number of samples to average within input signal.
  N_maf = round(N_maf);
 if ~f_impar(N_maf,2)
     N_maf = N_maf + 1;  % If not odd num. then convert to odd!
 end
 fprintf(' Filtering signals by moving average method... \n')
 fprintf(' f_cutoff_fil = %.3f MHz   @N_ave = %i \n',f_fil/10^6,N_maf)
%---------------------------------------------------------      
% Filter input signal to separate usefull data fro noise.
  s_aux = abs(s);
     s1 = smooth(s_aux,N_maf); 
  index = find(abs(s1) > DC_level);  % Find values in envelop signals > DC_level (signal window).

if ~isempty(index)  
  n_index = length(index);
       s2 = zeros(N,1);
    for i = 1:n_index
        s2(index(i)) = s(index(i));  % Extract windowed version from signal.
    end
        n = s - s2;                  % Determinate noise signal by simply substraction.
    rms_n = norm(n)/sqrt(N-n_index); % Estimate RMS value of noise.
   rms_s2 = norm(s2)/sqrt(N);        % Cal. RMS value of extracted signal.   
   SNR_dB = 20*log10(rms_s2/rms_n);  % Calculate final Signal to Noise Ratio.
     
    fprintf(' @%i  samples detected from  N = %i \n',n_index,N);
    if f_plot
        figure(9999); hold on; grid on;
        plot(t,s,'b');
        plot(t,s2,'g');
        plot(t,s1,'r');
        plot(t,DC_level*ones(N,1),'k');
    end
else
    fprintf(' :( Ups! DC_level too high to get a usefull signal from input data...')    
    fprintf(' Please decrease DC_level value.');
end
