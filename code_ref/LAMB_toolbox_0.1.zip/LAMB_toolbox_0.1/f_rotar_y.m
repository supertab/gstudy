function [P2] = f_rotar_y(P,ang_ele)
% Funcion de transformacion de un punto del Espacio x Rotacion del sistema de coordenadas
% en torno al eje Y referido a O'(0,0,0),  a un nuevo sistema  O''(0'',0'',0'') 
% girado 'ang_ele' [Rad] en el espacio.
% Obs.: Por el momento, solo contemplamos el giro del eles. en torno a sus ejes 'Y'.
% Accion:
%            P'(x,y,z)  ->   P''(x'',y'',z'')   
%
% ver 1.0   3/11/2004    Por el momento esta ver. solo hace el giro en torno al eje 'Y')
% ver 2.0   4/11/2004    Uso de '*' en Mult.de matrices,(Q = X*Y). 
% ver 3.0   9/11/2005!!! Corr. en matriz de transf. en: Beta(1,3) y Beta(3,1) y cambio nombre de var. Alfas --> Beta
% ver 3.1  26/01/2008    Cambio en nombre:  'f_rotacion' -> 'f_rotar_y'.

Beta = zeros(3,3);

    % Matriz de transfomacion x giro sobre el eje 'Y' de un punto coordenado.
    Beta(1,1) = cos(ang_ele);
    Beta(1,3) = sin(ang_ele);
    Beta(2,2) = 1;                   % Ya que la rotacion es en torno al eje 'Y'
    Beta(3,1) = -sin(ang_ele);
    Beta(3,3) = Beta(1,1);

% Transf x rotaci�n
P2 = Beta*P';   % el simbolo  '  a la derecha de P, significa transposicion en matlab, P(j,i) <-- P(i,j).


