function [Vs3_2,N_s_ele] = f_FRM_convert(Z0,k_couple,x_s3,y_s3,N_s_ele,Nxc3,Nyc3,Ps3_1,Nt,N3,fs)
% This function post-process the signals for the aperture receiving elements.
% Parameters:
%                     Z0 = c*ro  Is the air characteristic impedance of a plane wave in [N.s/m^3] or [Rayls].
%               k_couple = Velocity to electric signal coupling constant. Typ.value  k = 32.6 [V/m/s].
%              x_s3,y_s3 = Width & high dimension of receiving elements.
%                N_s_ele = Matrix w/individual number of sub-eles. by reception element: zeros(Nxc3,Nyc3).
%              Nxc3,Nyc3 = Number of receiver elements (X,Y) on reception aperture (array).
%            Xc3,Yc3,Zc3 = Receiving elements center's coordinates.
%                  Ps3_1 = Composed array data pressures signals:  Ps3_1 = zeros(Nxc3,Nyc3,N3);
%                     N3 = Number of points of signals.
%                     fs = Sampling frequency [Hz].
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    07/01/2009    Using data from engine: 'f_IRM_main_2D_2v3' v1 (11/12/2008).
% ver 2.0    09/01/2009    Add of incident angle vector 'theta'.
% ver 2.1    29/01/2009    Change of name: 'f_FRM_convert_signals' --> 'f_FRM_convert'.
% ver 2.2    28/02/2009    Change in 'fs_IMR' --> 'fs' because of use downsampled data (but not used yet...).


%--------------------------------------------------------------------------
% 3.2.2 Convert element signals: [Pa] --> [V]...
disp('3.2.2 Converting data: [Pa] -> [V]')

A_ele = x_s3*y_s3;              % Area of receiving element [m^2].
   ps = zeros(1,N3);
Vs3_2 = zeros(Nt,Nxc3,Nyc3,N3); % Composed & converted array signals for steering angle(n).

for k = 1:Nt
    for i = 1:Nxc3
        for j = 1:Nyc3
            ps(1,:) = Ps3_1(k,i,j,:);
             ps_ave = ps'/N_s_ele(i,j); % Average pressure at reception element(i,j).
                 vs = ps_ave/Z0;        % Pressure [Pa] to --> Velocity conversion [m/s].
                 es = vs*k_couple;      % Velocity [m/s] to --> Electrical, final signal conversion [V].
     Vs3_2(k,i,j,:) = es;
        end
    end
end

N_s_ele = mean(mean(N_s_ele));
fprintf('        A_ele = %.1f mm^2  N_s_ele = %.1f \n',A_ele*10^6,N_s_ele);
