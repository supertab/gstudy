function [d] = f_dist_P1_P2 (P1,P2)
% Funcion que calcula la distancia 
% entre 2 puntos dados


d = norm(P1-P2);

