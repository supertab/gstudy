function f_THS_draw_plate(num_p,num_s,a,p_max,d,plate_type,plate_O,plate_dim,plate_color,f_handle,f_font,f_title)
% Draw a prism 'patch' object simulating a plate under test!
% Parameters:
%         plate_type = String w/plate type material name.
%            plate_O = Plate origin [m].
%          plate_dim = Plate dimesions [m].
%        plate_color = Plate color type: 1,2,3 & 4. 
%                      Other numbers -> plain color w/no possibility of interp shading.
%             f_font = Axis labels font size eg. 14.
%            f_title = Plot Title w/font size 14,etc.                0 -> Do not plot titles.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    14/12/2008
% ver 2.0    31/12/2008     Plot of emission elements added.
% ver 3.0    08/01/2009     Change on reception field dimensions: [Nx Ny]=size(X_field) --> S_z = zeros(Nx,Ny,N)
% ver 3.1    19/01/2009     Change in name: 'f_draw_plate' --> 'f_THS_draw_plate' & elimination of elements drawing.
% ver 3.2    09/03/2009     Code simplification by 'plate_type' added.


%-----------------------------
% Define plate dimension &  verices coordinates.
  xw = plate_dim(1)/2;
  yw = plate_dim(2)/2;
  zw = plate_dim(3);

O(1) = xw/4 - plate_O(1);        % e.g.  plate_dim = [0.2 0.1 d]. 
O(2) = yw/2 - plate_O(2);        %         plate_O = [P_field_2(1)/2  P_field_2(2)  P_field_2(3)].
O(3) = zw - plate_O(3);          % <-- Change in definition (19/01/2009).
O(3) = O(3) + plate_dim(3)*0.01; % This is for allowing later a proper surface plotting with no overlapping with eles. plots...

   X = xw*[0 1 1 0 0 0;...
           1 1 0 0 1 1;...
           1 1 0 0 1 1;...
           0 1 1 0 0 0] - O(1);

   Y = yw*[0 0 1 1 0 0;...
           0 1 1 0 0 0;...
           0 1 1 0 1 1;...
           0 0 1 1 1 1] - O(2);

   Z = zw*[0 0 0 0 0 1;...
           0 0 0 0 0 1;...
           1 1 1 1 0 1;...
           1 1 1 1 0 1] - O(3);

%-----------------------------
% Choose plate color
switch plate_color
    case 1
        C = [1 1 0 0 0 0;...
             1 1 1 0 0 0;...
             1 0 0 1 1 1;...
             1 0 1 1 0 1];
    case 2
        C = [1 0 0 0 1 1;...
             1 1 0 1 1 0;...
             0 0 0 1 0 1;...
             1 1 0 1 1 0];
    case 3
        C = [1 0 0 0 1 1;...
             0 0 0 0 0 0;...
             0 0 1 0 1 0;...
             1 0 1 0 0 1];
    case 4
        C = round(rand(4,6));
    otherwise
        disp('(o_o) Warning: Activating interp shading ...will delete the plate draw!')
        disp(' If you want ...choose other type of plate_color: 1,2,3 & 4.')
        C = 3*ones(4,6);          
end        

%-----------------------------
% Draw plate.
figure(f_handle); 
fill3(X,Y,Z,C); 

%-----------------------------
% Plot title & axis.
if f_title > 0
    title(['THS simulated Lamb wave system ',plate_type,' plate @',num2str(d*1000),'mm; p-max = ',num2str(p_max),...
     'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p),'; num_s = ',num2str(num_s),],'FontSize',f_title);
end
xlabel('X [m]','FontSize',f_font);   
ylabel('Y [m]','FontSize',f_font); 
zlabel('Z [m]','FontSize',f_font); 
ah = gca;                  % Obtain current axis handle.
set(ah,'FontSize',f_font); % Set axis font size.

%-----------------------------
% Draw axis.
       O = [0 0 plate_O(3)];
axis_dim = (xw/5)*ones(1,3);
f_draw_axis(O,axis_dim);
axis equal
%axis([-0.5*xw 0.8*xw -0.8*yw 0.8*yw -0.5*yw 0.5*yw]);


