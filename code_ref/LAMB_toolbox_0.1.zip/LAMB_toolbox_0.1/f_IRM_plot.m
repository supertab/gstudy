function f_IRM_plot(f_delete_figs,Ps_movie,Ps_feature_type,Ps_delay_type,r3_type,a,p_max,num_p,Z0,fs,Ps,S,t3,N3,Nt,Nf,theta,fs_IRM,f,x_w3,y_w3,x_s3,y_s3,X3,Y3,Z3,Ps3,ang_alfa,ang_beta,ang_gamma,f_norm_plots,f_4D_plot,f_pause,f_font,f_title)
% Plotting function for IRM output data features.
%
% Parameters:
%  f_delete_figs = 1 -> Deletes IRM figures before quit.          0 -> Do not delete figures.
%       Ps_movie = 1 -> Display movie feature.                    0 -> Do not. 
%Ps_feature_type = 0 -> Maximum.  
%                  1 -> Pick-to-pick value.
%                  2 -> Energy.                                
%              value -> Time instant 'photo' (index between 1:N).
%        r3_type = Acoustic reception region type:
%                  0 -> "Rectangular" region. This include: single point; line and plane (Plane).
%                  1 -> Square/Rectangular circle filled (Plane).
%                  2 -> Circular/Ellipse circle filled (Plane).
%                  3 -> Cylindrical/spherical Shell!
%              a = Radius of excitation 'points' [m].
%          p_max = Maximun excitation pressure [Pa].
%          num_p = Number of THS excitation 'points'.
%             Z0 = c*ro. Air characteristic impedance in [N.s/m^3] or [Rayls].
%             fs = THS Sampling frequency [Hz].
%             Ps = Input excitation signal data matrix:  Ps = zeros(N,Nx);
%              S = Input excitation spectrum cell array:  S = cell{1,1}(Nf,2);
%             t3 = Signal's temporal axis [s].
%             N3 = Number of points in signal traces.
%             Nt = Number of incidence angles (theta).  In case of 3D-map --> Nt = Ncph.
%             Nf = Number of frequencies to compute of Lamb wave time signals.
%          theta = Plane wave incidence angle vector [Deg].
%           c_ph = Phase velocities vector for 3D-map [m/s].
%         fs_IRM = IRM Sampling frequency [Hz].
%              f = Frequency vector [Hz].
%      x_w3,y_w3 = X-axis & Y-axis widths of reception field [m].
%      x_s3,y_s3 = Step between points in reception field following X & Y axis resp. [m].
%       X3,Y3,Z3 = Reception field coodinates of simulated IRM acoustic field [m].
%            Ps3 = IRM output cell array data 'structure'. ->  Ps3 = cell(Nt,1)(Nx3,Ny3,N3).
%       ang_alfa = Rotation of plane 'Ps' around axis 'X3'.Ej.90� -> plane 'X3-Z3'
%       ang_beta = Rotation following axis 'Y3' It's orientation have to be studied later...
%      ang_gamma = Rotation following axis 'Z3'.
%   f_IRM_nplots = 1 -> Normalize IRM plot amplitudes.            0 -> Do not.
%      f_4D_plot = 1 -> Activate IRM-color surfaces.              0 -> Use common 3D surfs.
%        f_pause = 1 -> Activate program pause.                   0 -> Do not.
%         f_font = Axis labels font size eg. 14.
%        f_title = Plot Title w/font size 14,etc.                 0 -> Do not plot titles.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    20/12/2008     
% ver 1.1    15/01/2009     Air characteristic impedance parameter added.
% ver 1.2    17/02/2009     Inter program 'f_pause' flag added.


  movie_delay = 0;    %0.02    % Delay between movie frames [s].
 
 f_save_movie = 0;             % 1 -> Save movie into a file '*.avi'.
                               % 0 -> No.                               
    ds_factor = 10;            % Downsample frequency factor (fs2 = fs/ds_factor) to speed-up movies!

%----------------------------------------------------------------------------------------------------------------
% 2) Plot features for reception field.
%----------------------------------------------------------------------------------------------------------------
disp('2.4. Plotting IRM results...');
[Nx3 Ny3] = size(X3);          % Number of points of reception field.
if (Ny3 == 1) && (Nx3 == 1) 
    %------------------------------------------------------------------
    % 1) Single reception point at 'Nt' incidence angle(s) :)
    f_IRM_plot_1(N3,fs_IRM,t3,Ps3,X3,Y3,Z3,Nt,theta,a,p_max,num_p,Z0,fs,Ps,f,S,f_title,f_font,f_delete_figs,f_norm_plots,f_pause);
    
elseif ((Nx3 > 1)&&(Ny3 == 1)) || ((Nx3 == 1)&&(Ny3 > 1))
    %------------------------------------------------------------------        
    % 2) Line/Arc reception region.
    f_IRM_plot_2(Ps_feature_type,Ps_delay_type,N3,Z0,fs_IRM,t3,Ps3,f,S,X3,Y3,Z3,r3_type,Nt,theta,ang_alfa,ang_beta,ang_gamma,a,p_max,num_p,f_title,f_font,f_delete_figs,Ps_movie,movie_delay,f_save_movie,ds_factor,f_norm_plots,f_pause);
        
elseif (Nx3 > 1) && (Ny3 > 1)
    %------------------------------------------------------------------
    % 3) Plane % shell type reception regions.
    f_IRM_plot_3(f_4D_plot,Ps_feature_type,Ps_delay_type,N3,Z0,fs_IRM,t3,Ps3,X3,Y3,Z3,r3_type,Nt,theta,ang_alfa,ang_beta,ang_gamma,a,p_max,num_p,f_title,f_font,f_delete_figs,Ps_movie,movie_delay,f_save_movie,ds_factor,f_pause);
        
elseif (Nx3 > 1) && (Ny3 > 1) && ((r3_type == 1) || (r3_type == 2))
    %------------------------------------------------------------------
    % Circular/elliptical reception grid type.
    fprintf(':( Sorry: no plotting code available now. \n');     
    fprintf('   Available types  r3_type = 1 o 2');
else
    fprintf(':( Error: Unknow reception field region type. \n'); 
    fprintf('Nx3 = %i   Ny3 = %i   r3_type =',Nx3,Ny3,r3_type);  error(' ');
end
fprintf(' Done... IRM finish!  :) \n\n')












%  [M] = f_max(S_z) % Detect maximum value in calculated data structure.

%----------------------------
% Figures example code
% set(get(gcf,'CurrentAxes'),'FontSize',f_font);
% text(F(jj),U_max,[' �',num2str(theta(n))],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);  drawnow;
% if f_title title(['Displacement signal amplitude spectrum @p-max = ',num2str(p_max),'Pa'],'FontSize',f_title); end;    
% xlabel('f [Hz]','FontSize',f_font);  ylabel('Normalized amplitude','FontSize',f_font); 

