function [plane_index] = f_array_plane(O_ele)
% This function determines the plane in which is defined a give array.
% Obs:   
%        plane_index = 1  -->  YZ-plane
%                    = 2  -->  XZ-plane
%                    = 3  -->  XY-plane
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    10/01/2009
% ver 2.0    01/12/2009   New detection code.


plane = sum(abs(O_ele));

if plane(1) == 0 
    plane_index = 1;    % YZ-plane
elseif plane(2) == 0 
    plane_index = 2;    % XZ-plane
elseif plane(3) == 0 
    plane_index = 3;    % XY-plane
else
    disp('Error in array plane index definition...program paused!')
    error(':( ')
end
    
    

