function f_IRM_plot_1(N3,fs_IRM,t3,Ps3,x,y,z,Nt,theta,a,p_max,num_p,Z0,fs,Ps,f,S,f_title,axis_font,f_delete_figs,f_norm_plots,f_pause)
% Plot features for: 1) Single reception point with "theta" incidence angles :)
%
% Parameters:
%             N3 = Number of points in signal traces.
%         fs_IRM = IRM Sampling frequency [Hz].
%             t3 = Signal's temporal axis [s].
%            Ps3 = IRM output cell array data 'structure'. ->  Ps3 = cell(Nt,1)(Nx3,Ny3,N3).
%          x,y,z =
%             Nt = Number of incidence angles (theta).  In case of 3D-map --> Nt = Ncph.
%          theta = Plane wave incidence angle vector [Deg].
%              a = Radius of excitation 'points' [m].
%          p_max = Maximun excitation pressure [Pa].
%          num_p = Number of THS excitation 'points'.
%             Z0 = c*ro. Air characteristic impedance in [N.s/m^3] or [Rayls].
%             fs = THS Sampling frequency [Hz].
%             Ps = Input excitation signal data matrix:  Ps = zeros(N,Nx);
%              f = Frequency vector [Hz].
%              S = Input excitation spectrum cell array:  S = cell{1,1}(Nf,2);
%        f_title = 1 -> Activate title plot.                0 -> Do not.
%      axis_font = Title & axis font size.
%   f_norm_plots = 1 -> Apply amplitude normalization.      0 -> Do not.
%  f_delete_figs = 1 -> Deletes figures before quit.        0 -> Do not delete figures.
%        f_pause = 1 -> Activate program pause.             0 -> Do not.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    20/12/2008
% ver 2.1    15/01/2009     Corr. of energy calculation by adding air characteristic impedance.
% ver 2.2    17/02/2009     Inter program 'f_pause' flag added.


fprintf('2.4.1. Single reception point with  Nt = %i incidence angle(s) :) \n',Nt)

     [c_type] = f_assign_color(Nt);
    c_p_index = round(num_p/2);    % Index of central excitation signal for input spectrum 'S'.
           S0 = S{c_p_index};
    %---------------------------------------------------------------------------------------------------------------    
    % 1.1. Plot for pressure signals.
    h1 = figure(50001); hold on; grid on; 
    set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
    xlabel('t [s]','FontSize',axis_font);   ylabel('[Pa]','FontSize',axis_font); 
    if f_title     
        title(['Pressure signal(s) at (',num2str(x),' ;',num2str(y),' ;',num2str(z),') @p-max = ',num2str(p_max),'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p)],'FontSize',f_title); 
    end;
    %---------------------------------        
    % 1.2. Plot for amplitude spectrum.
    h2 = figure(50002); hold on; grid on; 
    set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
    xlabel('f [Hz]','FontSize',axis_font); 
    if f_title     
        title(['Amplitude spectrum of pressure signal(s) at (',num2str(x),' ;',num2str(y),' ;',num2str(z),') @p-max = ',num2str(p_max),'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p)],'FontSize',f_title);
    end;
    %---------------------------------        
    % 1.3. Plot for phase spectrum.
    h3 = figure(50003); hold on; grid on; 
    set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
    xlabel('f [Hz]','FontSize',axis_font);   ylabel('[Rad]','FontSize',axis_font); 
    if f_title     
        title(['Phase spectrum of pressure signal(s) at (',num2str(x),' ;',num2str(y),' ;',num2str(z),') @p-max = ',num2str(p_max),'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p)],'FontSize',f_title); 
    end;
    %---------------------------------
    % Detect maximum amplitude val. of excitation signals.
    [Ps3_max] = f_max(Ps3);        
    for k = 1:Nt
        s(:,:) = Ps3{k}(1,:,:);
         [S,F] = f_cal_spectra(fs_IRM,s);   
      S_m(k,1) = max(S(:,1));   % Save max. spectrum ampltitude value.
    end  
    S_m = max(S_m); % Absolute maximum spectrum val. used in normalization.
    %---------------------------------    
    if f_norm_plots
        %--------------------------------------
        % Plot central excitation signal & normalized spectrum.
                 N0 = length(Ps(:,c_p_index));
                 t0 = (0:1/fs:(N0-1)/fs)';
        [Ps_max,i1] = max(Ps(:,c_p_index));
        [S0_max,j1] = max(S0(:,1));
            S0(:,1) = S0(:,1)/S0_max;
        figure(h1); plot(t0,Ps(:,c_p_index)/Ps_max,'k');   text(t0(i1),Ps_max,'s0','VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
        figure(h2); plot(f,S0(:,1),'k');                   text(f(j1),max(S0(:,1)),'S0','VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
        figure(h3); plot(f,S0(:,2),'k');                   text(f(j1),max(S0(:,2)),'S0','VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
        %--------------------------------------   
        figure(h2); ylabel('Normalized amplitude','FontSize',axis_font);
    else
        Ps3_max = 1;
           S_m2 = S_m;
            S_m = 1;
        figure(h2); ylabel('Amplitude','FontSize',axis_font);
    end
    %---------------------------------        
    for k = 1:Nt
            s(:,:) = Ps3{k}(1,:,:);
        [s_max,i2] = max(s);
                 E = (norm(s)^2)/(Z0*N3); % Signal energy: E = ps*v [J]  ; v = ps/Z0
             [S,F] = f_cal_spectra(fs_IRM,s);  
            S(:,1) = S(:,1)/S_m;
        [S_max,j2] = max(S(:,1));
    
        figure(h1); plot(t3,s/Ps3_max,c_type(k));      text(t3(i2),s_max/Ps3_max,[num2str(theta(k)),'� ','  Energy = ',num2str(E),' J',],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
        figure(h2); plot(F,S(:,1),c_type(k));  text(F(j2),S_max,[num2str(theta(k)),'� '],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
        figure(h3); plot(F,S(:,2),c_type(k));  text(F(j2),S_max,[num2str(theta(k)),'� '],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
        drawnow;
%        pause;
    end
    fprintf(' num_p = %i   S0@c_p_index = %i \n\n',num_p,c_p_index)
    
%--------------------------------
% Adjust spectrum figure axis.    
[f1,i1] = min(f);
[f2,i2] = max(f);
if f_norm_plots
    figure(h2); axis( [f1*0.9  f2*1.1  0  1] );
else
    figure(h2); axis( [f1*0.9  f2*1.1  0  S_m2] );
end
    
%--------------------------------
if f_delete_figs && f_pause
    pause;  
    delete(figure(h1)); delete(figure(h2)); delete(figure(h3));
elseif f_delete_figs
    delete(figure(h1)); delete(figure(h2)); delete(figure(h3));
end

