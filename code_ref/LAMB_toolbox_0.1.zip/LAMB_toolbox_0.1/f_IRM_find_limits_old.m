function [D_min,D_max,P_near,P_far] = f_IRM_find_limits_old(Nx2,Ny2,X2,Y2,Z2,Nx3,Ny3,X3,Y3,Z3)
% This function returns the limit points P_near,P_far for the IRM emission
% and reception fields: [X2 Y2 z2] & [X3,Y3,Z3] respectively.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
% 
% ver 1.0    26/12/2008   Elimination of returning P_near,P_far.
% ver 2.0    08/01/2009   Change in reception field dimensions: [Nx Ny]=size(X_field) --> S_z = zeros(Nx,Ny,N)

I3_min = zeros(Nx2,Ny2);
J3_min = zeros(Nx2,Ny2);
D3_min = zeros(Nx2,Ny2);

I3_max = zeros(Nx2,Ny2);
J3_max = zeros(Nx2,Ny2);
D3_max = zeros(Nx2,Ny2);
     
%--------------------------------------------------------------------------------
for i2 = 1:Nx2       
    for j2 = 1:Ny2
        % [X2(i2,j2) Y2(i2,j2) z2]
        %---------------------------------------------------------------           
        % Adapt reception coodinates for emission element (i2,j2).
        X = X3 - X2(i2,j2);     % Translate coords. from: O2[X(i2,j2) ;Y(i2,j2)] --> O2' (center in O2'(0,0)).
        Y = Y3 - Y2(i2,j2);
        Z = Z3 - z2;  % We expressly assume that 'z2' is just a scalar value, not a matrix.
        N = zeros(Nx3,Ny3);
        %---------------------------------------------------------------
        % Sweep reception region centered on P_field_3 cal. distances to emission element (i2,j2).
        for i3 = 1:Nx3
            for j3 = 1:Ny3
                N(i3,j3) = norm([X(i3,j3) Y(i3,j3) Z(i3,j3)]);
            end    
        end            
        
        % Find shortest distance to emission point [X2(i2,j2) Y2(i2,j2) z2].
        [D3_min(i2,j2),I3_min(i2,j2)] = min(min(N')); 
                    [d,J3_min(i2,j2)] = min(min(N));
        % Find longest distance.
        [D3_max(i2,j2),I3_max(i2,j2)] = max(max(N')); 
                    [d,J3_max(i2,j2)] = max(max(N));
    end    
end

% Detect final nearest point.
[D_min,ii_min] = min(min(D3_min')); 
    [d,jj_min] = min(min(D3_min));
   P_near(1,1) = X3(I3_min(ii_min,jj_min),J3_min(ii_min,jj_min));
   P_near(1,2) = Y3(I3_min(ii_min,jj_min),J3_min(ii_min,jj_min));
   P_near(1,3) = Z3(I3_min(ii_min,jj_min),J3_min(ii_min,jj_min));

% Detection of farthest point.
[D_max,ii_max] = max(max(D3_max)); 
    [d,jj_max] = max(max(D3_max'));
    P_far(1,1) = X3(I3_max(ii_max,jj_max),J3_max(ii_max,jj_max));
    P_far(1,2) = Y3(I3_max(ii_max,jj_max),J3_max(ii_max,jj_max));
    P_far(1,3) = Z3(I3_max(ii_max,jj_max),J3_max(ii_max,jj_max));
    
%---------------------------------------------------------
% Checking code...    
% Find corresponding near & far points of excitation field.
 P_near_2(1,1) = X2(ii_min,jj_min);
 P_near_2(1,2) = Y2(ii_min,jj_min);
 P_near_2(1,3) = z2;
   
  P_far_2(1,1) = X2(ii_max,jj_max);
  P_far_2(1,2) = Y2(ii_max,jj_max);
  P_far_2(1,3) = z2;

        d_near = norm(P_near - P_near_2);
         d_far = norm(P_far - P_far_2);
         
%[d_near d_far]
%[D_min D_max]
 
plot3(P_near(1),P_near(2),P_near(3),'y+');
plot3(P_near_2(1),P_near_2(2),P_near_2(3),'k*');

plot3(P_far(1),P_far(2),P_far(3),'co');
plot3(P_far_2(1),P_far_2(2),P_far_2(3),'m*');


%1;