function [N,t] = f_cal_t_power_2 (fs,t_old)
% This function change the longitude of a given time axis 't_old'
% with 'N_old' points to -> a new time axis 't' with: 'N = 2^n' points.
%            
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
%
% ver 1.0    17/12/2008    
% ver 1.1    02/12/2009    % Return of 'N' added.


t_min = min(t_old);        % Minimum time value [s].
t_max = max(t_old);        % Maximum time value [s].
N_old = length(t_old);

% -------------------------------------------------------------------------
% Convert time to power of 2!
        i = 0;
       N2 = 0;
not_ready = 1;    
while not_ready
    if N2 < N_old
        i = i + 1;
       N2 = 2^i;
       N3 = 2^(i-1);
       N_limit = 1.25*(2^(i-1)); % Half point between:  2^(i-1) y 2^i.
    elseif N_old <= N_limit
        t_max = t_min+(N3-1)/fs;
    not_ready = 0;
    else
        t_max = t_min+(N2-1)/fs;
    not_ready = 0;
   end
end
% -------------------------------------------------------------------------

t = (t_min:1/fs:t_max)';   % Final converted time vector.
N = max(size(t));           % New longitude '2^n' multiple.

fprintf(' 2^n power longitude = %i \n',N)


    
    
    
    
    
    
    
    
    
    