function [Ps_feature,Ps_delay] = f_cal_Ps_feature(feature,delay_type,Z0,N,fs,t,theta,Ps,h1,h2,X,Y,axis_font)
% Plot signal features for a given acoustic field data set 'Ps'.
% Obs.:
%            Ps = IRM data cell array:  Ps = zeros(Nx3,Ny3,N3);
%             h ~ 0 -> Plot feature in y-axis
%             h = 0 -> Plot feature in z-axis
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    25/12/2008
% ver 2.1    15/01/2009    Corr. of energy calculation by adding air characteristic impedance.


[d1,d2] = size(X);
if (d1 > 1) && (d2 > 1) % Is X a matrix?
    x = X(1,1); y = Y(1,1); % Yes!
else
    x = X(:); y = 0;    % No, X is a vector.
end

if feature >= 0
    figure(h1);
    switch round(feature)
        case 0 % Max. +value detection.
            [Ps_feature] = f_cal_Ps_max(theta,Ps,x,y,axis_font);
            if  y == 0  ylabel('Max. pick [Pa]','FontSize',axis_font);
            else        zlabel('Max. pick [Pa]','FontSize',axis_font); end
        case 1 % Pick-to-pick value.
            [Ps_feature] = f_cal_Ps_p2p(theta,Ps,x,y,axis_font);
            if y  == 0  ylabel('Pick-2-pick [Pa]','FontSize',axis_font);
            else        zlabel('Pick-2-pick [Pa]','FontSize',axis_font); end
        case 2 % Signal's energy calculation.
            [Ps_feature] = f_cal_Ps_energy(Z0,theta,Ps,x,y,axis_font);
            if y == 0   ylabel('Power [W]','FontSize',axis_font);
            else        zlabel('Power [W]','FontSize',axis_font); end
        otherwise % Time instant (photo); index between 1:N.
            N = length(t);
            if feature <= N
                [Ps_feature] = f_cal_Ps_photo(theta,t,feature,Ps,x,y,h1,axis_font);
                if y == 0  ylabel('Instant value [Pa]','FontSize',axis_font);
                else       zlabel('Instant value [Pa]','FontSize',axis_font); end            
            else
                fprintf(':( Error: Time instant outside t_max! \n');
                fprintf('N = %i   n = %i',N,feature); 
                delete(figure(h1));  delete(figure(h2));  error(' ');
            end
    end
    %-----------------------------------------------------------------------------      
    figure(h2);
    [Ps_delay] = f_cal_Ps_delay(theta,delay_type,N,fs,Ps,t,h2,x,y,axis_font);
    if Y == 0  ylabel('Ps_delay [us]','FontSize',axis_font);
    else       zlabel('Ps_delay [us]','FontSize',axis_font); end
    %-----------------------------------------------------------------------------      
else
    fprintf(':( Error: Feature type must be an integer >= 0 \n');
    fprintf('feature  = %f \n',feature); 
    delete(figure(h1));  delete(figure(h2));  error(' ');
end

