function [D] = f_IRM_D_rad_element(c,a,f,theta)
% This function calculates an aproximate value for the directivity of a single reception IRM element; 
% based on the directivity analitical expresion for a circular type hydrophone.
%
% Refs.: 1) "Beam profile measurements and simulations for ultrasonic transducers operating in air"
%            Graham Benny & Gordon Hayward.  Centre for Ultrasonic Engineering, Dep. of Electronic & Electrical Engineering, University of Strathclyde, Glasgow G1 1XW, UK.
%            J. Acoust. Soc. Am. 107 (4), April 2000
%
%        2) "A theoretical model for a finite-size acoustic receiver"
%            Adrian Neild & David A. Hutchins. School of Engineering, University of Warwick, Coventry CV4 7AL, UK.
%            J. Acoust. Soc. Am., Vol. 115, No. 4, April 2004
% 
%        3) Book: "Fundamentals of Acoustics". 
%           L. E. Kinsler and A. R. Frey.  2nd ed. (Wiley, New York, 1962, Chap. 8).
%
% Parameters:
%            c = Speed of sound i air [m/s].
%            a = Hydrophone radius [m].
%            f = Vector w/frequencies of directivity interest [Hz].
%        theta = Angle of reception [Rad].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
%
% ver 1.0    25/01/2009     Based on code from: 'f_cal_D_rad_hidrofono' v1.2  (12/01/2009).



     k = (2*pi/c)*f;         % Wavenumber [Rad/m].
    z0 = (k*a/2)*sin(theta); 
%---------------------------------------------------
% Correction of zero-cross to do not divide by zero.
ii_k = find((z0 == 0));
if ~isempty(ii_k)
    for n = 1:length(ii_k)
        z0(ii_k(n)) = 10^-6; 
    end;          
end
%---------------------------------------------------
     
[J1,msg] = besselj(1.00001,z0);   % Bessel 1er orden function (nu = 1.00001), if msg = 0 calculation ok!
       D = (2*J1./z0);            %  L0 = ((1+cos(theta))/2).*(J1_s./z0);  We have intentionally extract the term '(1+cos)/2'
       D = abs(D);                %  to follow the aproximation of 'Graham Benny' paper. 
                                  %  In any case, the  difference it is not much significative even for biger angles.

                                               
                                               
%--------------------------------------------------------------------------
% Old code                                               
%       D = ((1+cos(theta))/2).*(2*J1./z0);  
                                               

                                  
