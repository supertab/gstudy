function [Vs3_2] = f_freq_filter(N,fs,f_min,f_max,s,f_filter,f_plot,f_handle)
% This function applies the sensor's frequency response to the array received signals.
% Parameters:
%                     fs = Sampling frequency [Hz].
%                  f_min = Inferior BW-frequeny limit for integration [Hz].
%                  f_max = Superior BW-freq. limit [Hz].
%                      s = sa(:) or Vs3_2(Nt,Nxc3,Nyc3,N) Final (composed & converted) array signals.
%              Nxc3,Nyc3 = Number of receiver elements (X,Y) on reception aperture (array).
%                     Nt = Number of incident angles. 
%                      N = Number of points of signals.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    22/12/2009
% ver 2.0    07/01/2010   Name change:  'f_FRM_freq_filter' -> 'f_freq_filter'

%--------------------------------------------------------------------------
% Apply array frequency response.
if f_filter
    disp(' Applying sensor�s frequency response...')    
    load matlab_data_C2_array_freq_response.mat
       f_s = fs/N;                  % Frequency spacing 'step' [Hz].
         f = (f_min:f_s:f_max)';    % Operating frequency bandwidth [Hz].    
     i_min = round((f_min/f_s)+1);  % Index of 1st. non null filter value.
         A = zeros(N,1);
        Nf = max(size(f));          % Number of frequencies in BW.          
    filter = interp1(f_filter,C2_filter_n,f,'cubic'); % Extract filter respose by imterpolation of exp. data.
    %------------------------------------------------
    % Construct sensor's filter response.
           A(i_min:Nf+i_min-1,1) = filter(1:Nf,1);    % Main part (0:f_s:fs/2).
    A(N-i_min-Nf+3 :N-i_min+2,1) = filter(Nf:-1:1,1); % Complementary frequencies (fs/2:f_s:fs).
    %------------------------------------------------
    switch ndims(s)
        %------------------------------------------------------
        case 2 
            if ((size(s,1)==1) && (size(s,2)>1)) || ((size(s,1)>1) && (size(s,2)==1))
                % Row or column vector.
                Nxc3 = 1;
                   s = s(:);
            elseif (size(s,1)>1) && (size(s,2)>1)
                % Column Matrix
                [Nxc3,N3] = size(s);
            else
                % Single scalar.
                disp(':( Error: data for filter is a simple scalar.')
                error(' ');
            end
            for j = 1:Nxc3
                    S = fft(s(:,j));
                S_fil = S.*A; 
                s_fil = real(ifft(S_fil));
                Vs3_2 = s_fil(:);
            end
        %------------------------------------------------------            
        case 4 
            Vs3_2 = s; clear s;
            [Nt,Nxc3,Nyc3,N3] = size(Vs3_2);
            for k = 1:Nt
                for i = 1:Nxc3
                    for j = 1:Nyc3
                        s(1,:) = Vs3_2(k,i,j,:);
                        S = fft(s(:));
                        S_fil = S.*A; 
                        s_fil = real(ifft(S_fil));
                        Vs3_2(k,i,j,:) = s_fil;
                    end
                end
            end
        otherwise
            disp(':| Ups! Code not implemented yet...')
            error(' ');
    end
    %--------------------------------------------------------------------------
else
    disp(' Frequency filter OFF -> Using ideal response.')
    Vs3_2 = s;
end










