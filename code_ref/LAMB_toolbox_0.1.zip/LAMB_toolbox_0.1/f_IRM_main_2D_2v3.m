function [et,c,ro,Z0,Ps3,X3,Y3,Z3,Xc3,Yc3,Zc3,t3,N3,N_ele,Npts3,a_3,b_3,P_field_3] = f_IRM_main_2D_2v3(f_plot_eles,f_cph_mapping,num_modes,S_z,X2,Y2,z2,P_field_2,theta,Nt,Nx2,Ny2,x_w2,y_w2,x_s2,y_s2,T_amb,Hr,P,t,N,fs,fs_IRM,f0,f_min,f_max,trace_duration,r3_type,ele_order_3,P_field_3,R_3,x_w3,y_w3,x_s3,y_s3,n_a3,n_b3,ang_alfa,ang_beta,ang_gamma,theta_3,phi_3,psi_3,f_D,f_pause,f_font,f_title,f_normals,f_plate_handle)
%--------------------------------------------------------------------------~=
% This set of routines computes the radiated acoustic field in air for a predefined 
% emission region in a vibrating plate. 
% It is based on the paper: 
%                          "Diffraction impulse response of rectangular transducers"
%                      from: J.L.San Emeterio & L.Ullate {J.Acoust.Soc.Am. 92(2) (August 1992)}.
%
% Last version available:  'Main_FIRST_2D_2v3' (17/04/2008).
%--------------------------------------------------------------------------~=
% Obs.:      Units defined in the SI system. 
%            All dimensions in [m].
%            All angles if not specified in degrees [Deg].
%            
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
%
% ver 1.0    11/12/2008     Using IRM-2D core: 'Main_FIRST_2D_2v3' (17/04/2008)
% ver 2.0    09/01/2009     Add of incident angle vector 'theta'.
% ver 2.1    19/01/2009     Draw of plate moved to THS & 'theta_3'parameter added.
% ver 2.2    17/02/2009     Inter program 'f_pause' flag added.
% ver 2.2.1  23/02/2009     Added devolution of possible modified parameter 'P_field_3'.
% ver 2.3    28/02/2009     Downsampling code for output data added.


if ~f_cph_mapping
    %--------------------------------------------------------------------------
    % 2. Begin calculations for Impulse Response Method (IRM)!
    %--------------------------------------------------------------------------
    % 2.1 Check input variables...
    fprintf(' 2. Initializing IRM ------------------------------- \n');
    [x_w2,y_w2,x_s2,y_s2,P_field_3,x_w3,y_w3,x_s3,y_s3,n_a3,n_b3] = f_IRM_check_input_data (T_amb,Hr,P,P_field_2,x_w2,y_w2,x_s2,y_s2,fs_IRM,f0,f_min,f_max,trace_duration,P_field_3,R_3,x_w3,y_w3,x_s3,y_s3,n_a3,n_b3,Nt,theta,ang_alfa,ang_beta,ang_gamma,theta_3,phi_3,psi_3,r3_type,f_pause); 
    fprintf('N = %i    ',N);
    
%     %--------------------------------------------
%     % 2.2 Cal coors. of EMISSION Field...JUST FOR GETTING THE IMAGE!
%             O = [0 0 0]
%     P_field_1 = [-0.0051 0 P_field_3(3)]
%     [Xc33,Yc33,Zc33,Nxc33,Nyc33,X33,Y33,Z33,Nx33,Ny33,a_33,b_33,Alfa33,Beta33,Gamma33] = f_IRM_reception_coords(r3_type,O,P_field_1,x_w3,y_w3,x_s3,y_s3,n_a3,n_b3,ang_alfa,-ang_beta,ang_gamma,R_3,phi_3,psi_3,f_plate_handle,f_plot_eles(3),f_normals);
    %--------------------------------------------
    % 2.2 Calculate coordinates of reception field.
    [Xc3,Yc3,Zc3,Nxc3,Nyc3,X3,Y3,Z3,Nx3,Ny3,a_3,b_3,Alfa3,Beta3,Gamma3] = f_IRM_reception_coords(r3_type,ele_order_3,P_field_2,P_field_3,x_w3,y_w3,x_s3,y_s3,n_a3,n_b3,ang_alfa,ang_beta,ang_gamma,R_3,phi_3,psi_3,f_plate_handle,f_plot_eles(3),f_normals);    
    %--------------------------------------------
    % 2.3 Determinate new time axis for IRM (d1/c shifted  &  d2/c longer).    
    fprintf(' 2.3 Pre-adjusting trace longitudes to reception field.\n')
    [c,atte_air_dB,ro,Z0] = f_cal_air_properties(T_amb,Hr,P,f0); % Calculate speed of sound in air [m/s].
    [D3_min,D3_max,P3_near,P3_far] = f_IRM_find_limits(Nx2,Ny2,X2,Y2,z2,Nx3,Ny3,X3,Y3,Z3); % Return reception [min max] distances to emission field.
    [N2,t_max2,t2] = f_cal_t_max_time(fs,c,D3_min,D3_max,trace_duration,t);
    %--------------------------------------------
    % 2.4 Pre-process input data from THS.
    [a,b,N3,t3,f3,f_s3,Nf3,S_z] = f_IRM_pre_process_THS_data(c,N,f_min,f_max,fs,fs_IRM,t2,N2,Nx2,Ny2,P_field_2,x_w2,y_w2,x_s2,y_s2,R_3,D3_min,D3_max,P_field_3,a_3,b_3,Nt,num_modes,S_z,f_D);
    %--------------------------------------------
    % 2.5 Draw plate emission elements.
%    f_IRM_draw_emission_elements(a,b,Nx2,Ny2,X2,Y2,z2,f_plot_eles(2),f_plate_handle);
    %--------------------------------------------
    % 2.6 Estimate IRM calculation time...    
    [minutes,seconds,N_ele,Npts3] = f_IRM_estimate_time(T_amb,Hr,P,P_field_2,Nx2,Ny2,Nt,n_a3,n_b3,a_3,b_3,Nxc3,Nyc3,Nx3,Ny3,N3,Nf3,fs_IRM,f_s3,f3,t3,P_field_3,theta,f_pause);
    %--------------------------------------------
    % 2.7 Start calculations of pressures in reception region (Ps).
    % If  'baffle = 0'  ->  Riggid-Baffle; if not... Soft-Baffle.
      baffle = 0; 
    [et,Ps3] = f_IRM_init(baffle,T_amb,Hr,P,theta,Nt,Nx2,Ny2,a,b,P_field_2,X2,Y2,z2,S_z,fs_IRM,t3,N3,f3,f_s3,Nf3,theta_3,r3_type,X3,Y3,Z3,f_D);    
    %--------------------------------------------------------------------------
else
    disp('"f_cph_mapping" flag set... IRM nothing to do! :( ')
    Ps = 0
end








