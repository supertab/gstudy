function [V_mf,S,F] = f_multifocal_DAS(mf_length,mf_step,N,fs,c,Vs,P_field_2,X_field_2,Y_field_2,z_field_2,P_field_3,O_ele,Nxc3,f_handle)
% This function implements a multifocal Delay And Sum (DAS) beamformer on the plate surface.
% Parameters:
%              mf_length = Lenght (on the plate) of focus area [m].
%                mf_step = step between focal points [m].
%                      N = Number of points of signals.
%                     fs = Sampling frequency [Hz].
%                      c = Speed of sound in air [m/s].
%                     Vs = Vs(N,Nxc3) Final element signals of the array.
%              P_field_2 = Reference field point (center) of calaized area on the plate.
% X_field_2,Y_field_2,z_field_2 = -> Coordinates of "actual" IRM emitters on the plate.
%              P_field_3 = Reception aperture field center point.
%                  O_ele = Receiving elements coordinate center's.
%                   Nxc3 = Number of receiving elements on reception aperture (1D arrays by now).
%               f_handle = Main LAMB program figure number.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 2.0    19/03/2010


fprintf(' 3.3.2.1 Multipoint DAS enable!  :)\n')
 x = [-mf_length/2:mf_step:mf_length/2]' + P_field_2(1);
nx = max(size(x));
 y = zeros(nx,1);
 z = P_field_2(3)*ones(nx,1);

if (min(x) < min(X_field_2)) || (max(x) > max(X_field_2))
    fprintf('(o_o) Warning! MF-DAS area outside radiation zone...\n')    
    d = max(x) - max(X_field_2);
    fprintf(' x_diff = %.1f mm \n',d*1000);
end
if f_handle
    figure(f_handle); plot3(x,y,z,'k.');
    plot3(O_ele(:,1),O_ele(:,2),O_ele(:,3),'go')
end

%----------------------------------------------------------------------
% Cal. delays
Td = zeros(Nxc3,nx);
for j = 1:nx
    for i = 1:Nxc3
        Td(i,j) = norm(O_ele(i,:)-[x(j) y(j) z(j)])/c; % Cal. delay times from emitter(j) to array eles. [s].
    end
    Td(:,j) = Td(:,j) - min(Td(:,j)); % Determinate advance time for signals at focalized plate emitter(j).
end
 t_max = N/fs;
td_max = max(max(Td));
if td_max > t_max
    fprintf('(o_o) Warning: Max. t_limit passed, adding null signals!!\n')        
end

%----------------------------------------------------------------------
% Delay signals for MF-DAS
f_quiet = 1;
 V_mf = zeros(N,nx);
for j = 1:nx
    for i = 1:Nxc3
%         if j==51 && i==3
%            i
%            j
%         end
                s = Vs(:,i);
            delay = -Td(i,j);  % It's < 0 because we have to "advance" the signal(i) at focus(j).
              s_d = f_delay_signal(fs,N,delay,s(:),f_quiet);
        V_mf(:,j) = V_mf(:,j) + s_d;
    end
end

%----------------------------------------------------------------------
% Cal. 2D FFT for field spectra.
[S,F] = f_cal_spectra([fs 1/mf_step],V_mf);
































