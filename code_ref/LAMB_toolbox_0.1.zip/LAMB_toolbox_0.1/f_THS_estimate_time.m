function [minutes,seconds] = f_THS_estimate_time(f_cph_mapping,s_type,s_delay,n_burst,r_type,a_type,p_max,O,t_max,num_modes,mode_type,num_p,num_s,num_p_s,x,X,Y,x_w,y_w,c,Nx,Ny,N,Nf,Nt,W,K,t,f,f_min,f_max,plate_type,d,a,f0,fs,f_s,c_ph,alfa,beta,Mu,f_pause,f_font,f_title)
% Estimate time taken by THS calculations.
%
% Parameters:
% f_cph_mapping =  3D Frequency-phace_velocity map tool:         0 -> Disable.    1 -> Enable mapping.  
%       s_type  =  Signal excitation type.
%       s_delay =  Initial commonn delay time for excitation signals [s].
%      n_burst  =  Number of cicles in burst-type signal (only used w/burst signals).
%       r_type  =  Region type.
%       a_type  =  Apodizing amplitude profile type. If  's_type = 0'  they don't apply.
%        p_max  =  Excitation signal max. amplitude [Pa].
%            O  =  Central point of excitation field.
%        t_max  =  Maximum time limit [s].
%    num_modes  =  Number of THS simulated Lamb modes.
%    mode_type  =  Lamb mode type:                               0 -> Simmetric.  1 -> Anti-simmetric.
%        num_p  =  Total number of points in excit field. 
%        num_s  =  Number of Y-strip lines in excit. field.
%      num_p_s  =  Number of 'points' by Y-strip line.
%      [x,X,Y]  =  Excitation field coordinates [m].
%          x_w  =  With of region in 'x' direction [m].
%          y_w  =  With of region in 'y' direction [m].
%            c  =  Velocity of acoustic signal eg. air @21�C: 343.81 [m/s].
%      [Nx Ny]  =  Number of excitation 'points'.
%            N  =  Number of time points in signal trace.
%            Nf =  Number of frequencies to compute of Lamb wave time signals.
%            Nt =  Number of incident angles or phase-velocities in 3D-map.
%         [W K] =  Lamb waves dispersion curve vectors for modes to compute.
%             t =  Time trace vector [s]
%             f =  Signal's frequency vector [Hz].
%         f_min =  Inferior BW-frequeny limit for integration [Hz].
%         f_max =  Superior BW-freq. limit [Hz].         
%    plate_type =  String w/material plate type.
%             d =  Width of material layer e.g.: Aluminium @0.001 [m].
%             a =  Radius of finite circular region [m].
%            f0 =  Signal's central-BW frequency [Hz].
%            fs =  Sampling frequency [Hz].
%           f_s =  Samplig step in frequency vector 'f' [Hz].
%          c_ph =  Phase velocity vector for 3D Freq.-Phase_velocity map tool [m/s].
%   [alfa beta] =  Longitudinal and transversal bulk wave speeds in plate. 
%            Mu =  Lame constant of matrial plate [Pa].
%       f_pause =  Inter-program's pause flag.
%        f_font = Axis labels font size eg. 14.
%       f_title = Plot Title w/font size 14,etc.                0 -> Do not plot titles.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    05/12/2008
% ver 2.0    28/12/2008     Printing mode enhanced.
% ver 3.0    17/02/2009     Simplified version.
% ver 3.1    27/02/2009     's_delay' parameter added.


%--------------------------------------------------------------------------
% Calculate estimated time for total calculations [s].
fprintf('1.2. Estimating computing time... \n')
 
if f_cph_mapping
    %----------------------------------------------------------------------
    % Estimate total time for frequency-phase velocity map.
    if num_p > 1
        disp(' :(  Number of excitation points > 1 in 3D map...')
        fprintf(' num_p = %i... Change to 1 please. \n\n',num_p); error(' ');
    end    
  f_quiet = 1;
 n_trials = 50;
       et = zeros(n_trials,1); 
   s_type = 1;
    d_max = 0.1;
mode_type = 1;            % Just 4 test prove w/anti-simmetric modes
      Nf2 = 1;            % Test time computation just 4 one frequency...   
      Nt2 = 1;            % ... and one phase velocity only.
       f0 = W(1)/(2*pi);
     S{1} = [1 0];        % Use ideal normalized input spectrum for 3D map calculations.
                          % This is implicitly assumed because 's_type = 1' (sinusoidal signal).       
         tic; 
    for i = 1:n_trials
        u = f_THS_compute(f_cph_mapping,mode_type,num_p,d,a,N,Nf2,Nt2,Nx,Ny,d_max,0,d/2,0,0,S,t,W(1),K(1),c_ph(1),alfa,beta,Mu,f_quiet);
    end
    %---------------------------------------        
    % Estimated calculation mean time for local computer; by  'point-point-sample-frequency' in [s].
      t_pp = toc/(n_trials)          % Mean elapsed time for point-to-point.
    e_time = (t_pp*Nf*Nt*num_modes); % Global estimated calculation duration time [s].
else
    %----------------------------------------------------------------------
    % Estimate total time for 'Nt' angle calculations..
     f_quiet = 0;
    n_trials = 5;
          et = zeros(n_trials,1); 
           S = cell(1,1);
          W0 = W{1};          % Lamb mode frequencies.
          K0 = K{1};          % and wavenumbers (use only mode A0 for test).
          Nf = max(size(W0)); % Number of frequencies to test.
   mode_type = mode_type(1);  d_max = 0.1;  
      num_p2 = 1;               Nt2 = 1; 
         Nx2 = 1;               Ny2 = 1;
    %---------------------------------------        
    % Test & plot THS excitation signal.
           if s_type == 0  
               s_type = 2;  % If field loaded... use another signal to test time.
           elseif s_type < 0  
               s_type = abs(s_type);
           end;
           s = f_gen_signal(N,n_burst,s_type,p_max,f0,fs,0,t); % Generate arbitrary signal for time test.
       if s_delay   
           % Add fix delay 2 signal to avoid filtering problems.
           fprintf('Adding fix delay of %f us to improve filtering process..\n',s_delay*10^6);  
           s = f_delay_signal(fs,N,s_delay,s,f_quiet);    
       end
       s_fil = f_ideal_bp_filter(s,f_min,f_max,fs,0);      % Filter excitation signal within BW.
     [S2,f2] = f_cal_spectra(fs,s_fil);                    % Compute spectrum of final filtered signal.
        S{1} = interp1(f2,S2,W0/(2*pi),'spline');          % Interpolate spectrum in Lamb frequency points.
    %---------------------------------------        
    % Plot used signal w/spectrum.
    figure(993); hold on; grid on;       plot(t,s,'b');     plot(t,s_fil,'g');
    if f_title > 0
        title([' Excitation signal for ',plate_type,' plate @',num2str(d*1000),'mm; p-max = ',num2str(p_max),...
        'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p),'; num_s = ',num2str(num_s),],'FontSize',f_title);
    end
    xlabel('t [s]','FontSize',f_font);   ylabel('Signal pressure [Pa]','FontSize',f_font); 
    ah = gca;                            % Obtain current axis handle
    set(ah,'FontSize',f_font);           % Set axis font size.
    
    figure(994); hold on; grid on;       plot(f2,S2(:,1));  plot(W0/(2*pi),S{1}(:,1),'g.');
    if f_title > 0
        title([' Excitation spectrum for ',plate_type,' plate @',num2str(d*1000),'mm; p-max = ',num2str(p_max),...
        'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p),'; num_s = ',num2str(num_s),],'FontSize',f_title);
    end
    xlabel('f [Hz]','FontSize',f_font);  ylabel('Spectrum amplitude ','FontSize',f_font); 
    ah = gca;                            % Obtain current axis handle
    set(ah,'FontSize',f_font);           % Set axis font size.
    %---------------------------------------        
       et = zeros(n_trials,1);
    for i = 1:n_trials
          t0 = cputime; 
           u = f_THS_compute(f_cph_mapping,mode_type,num_p2,d,a,N,Nf,Nt2,Nx2,Ny2,d_max,d_max,d/2,0,0,S,t,W0,K0,c_ph,alfa,beta,Mu,f_quiet);
       et(i) = cputime - t0;
    end
    %---------------------------------------        
    % Estimated calculation mean time for local computer; by  'point-point-sample-frequency' in [s].
        Nf = 1;          % We use this val. because 'f_THS_conpute' already include 'Nf' freqs. in the cal.
      t_pp = mean(et);   % Mean elapsed time for point-to-point.
    e_time = (t_pp*Nf*num_modes*num_p*Nx*Ny*Nt);  % Global estimated calculation duration time [s].    
end

%----------------------------------------------------------------------------------------------
% Convert time to min:secs.
[minutes,seconds] = f_convert_time(e_time);
fprintf('  t_pp = %.3fs   et = %i:%.1f \n',t_pp,minutes,seconds);

if f_pause
    disp(' Program paused. Press any key to continue.')
    pause;
end

fprintf('\n\n');

