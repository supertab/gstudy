function [h] = f_IRMc_IR_RB_point_fast (P,a,b,c,t,h,N,zone,t_max)     
% Funcion que computa la Respuesta Impulsional 'h' (Rigid-Baffle)
% p/un punto de coordenadas P(x,y,z) ref. a un elemento rectangular
% situado en el Origen O(0,0,0) y perpendicular al eje 'Z'.
% Basada en paper:  "J.L.San Emeterio & L.Ullate" *****
% Donde:
%      P(x,y,z) = Coord. del punto de campo a calcular [m].
%             a = Semi-ancho de la aperura rectangular [m].
%             b = Semi-alto de la aperura rectangular [m].
%             c = Velocidad del sonido en el aire [m/s].
%             N = Nro. de puntos de la traza 'h'.
%          zone = Zona de computo (1,2,3,4).
%         t_max = Tiempo maximo de duracion trazas: t_max = t_duracion + d_max/c; ver -> 'f_cal_t_max_time'
%          h(t) = Impulse response vector [m/s].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1-7    Based on core: 'f_cal_IR_RB_point' --> 'f_IRMc_IR_RB_point'. Also dims. conversion: [mm] --> [m].
% ver 7.0.1  12/01/2009      Using fast 'h' routines & receive 'h' vector as a parameter to improve speed!
% ver 7.1    16/01/2009      Add of detection of null 'h'.

     
    % Definiciones fundamentales de las distancias desde el punto de campo 'P':
    % Distancias 'rectas a las extensiones de los lados del elemento'
    d1 = abs(P(1)) - a;   
    d2 = abs(P(2)) - b;   % Obs. aqui se incluyen todos los cuadrantes ref. al 1ero.
    d3 = abs(P(1)) + a;   % en cual se basan los calculos del paper.
    d4 = abs(P(2)) + b;   % el abs(), produce esta referenciacion...
    
    TA = (sqrt(d1^2 + d2^2 + P(3)^2))/c;   % Tiempos a los vertices 'A','B','C' y 'D'
    TB = (sqrt(d2^2 + d3^2 + P(3)^2))/c;
    TC = (sqrt(d1^2 + d4^2 + P(3)^2))/c;
    TD = (sqrt(d3^2 + d4^2 + P(3)^2))/c;   % Tiempo max. del punto 'P' a la sup. del elemento
    
    TS1 = (sqrt(d1^2 + P(3)^2))/c;         % Tiempos a los lados: 'S1', 'S2','S3' y 'S4'
    TS2 = (sqrt(d2^2 + P(3)^2))/c;
    TS3 = (sqrt(d3^2 + P(3)^2))/c;
    TS4 = (sqrt(d4^2 + P(3)^2))/c;
   
     T0 = abs(P(3))/c;                     % Tiempo minimo de 'P' a la sup. del elemento.


%-------------------------------------------------------------------------    
% :) Using new fast code...
           [i_T0,i_TD] = f_IRMc_time_indexes_fast (N,t,T0,TD);
     [alfa_r_1,alfa_1] = f_IRMc_alfa_i_opt2_fast (c,i_T0,i_TD,N,T0,TS1,TD,t,P(3),d1);
     [alfa_r_2,alfa_2] = f_IRMc_alfa_i_opt2_fast (c,i_T0,i_TD,N,T0,TS2,TD,t,P(3),d2);
     [alfa_r_3,alfa_3] = f_IRMc_alfa_i_opt2_fast (c,i_T0,i_TD,N,T0,TS3,TD,t,P(3),d3);
     [alfa_r_4,alfa_4] = f_IRMc_alfa_i_opt2_fast (c,i_T0,i_TD,N,T0,TS4,TD,t,P(3),d4);
%----------------------------------------------------------
    switch zone    
      case 1
        [h] = f_IRMc_h_I_opt_fast (i_T0,i_TD,N,t,h,TA,TB,TC,TD, alfa_1,alfa_2,alfa_3,alfa_4);  % Cal. 'h' dentro de la zona I        
      case 2
        [h] = f_IRMc_h_II_opt_fast (i_T0,i_TD,N,t,h,TA,TB,TC,TD  ,TS2,  alfa_1,alfa_2,alfa_3, alfa_4,alfa_r_4);  % Cal. 'h' dentro de la zona II
      case 3
        [h] = f_IRMc_h_III_opt_fast (i_T0,i_TD,N,t,h,TA,TB,TC,TD  ,TS1,  alfa_1,alfa_2, alfa_3,alfa_r_3, alfa_4);  % Cal. 'h' dentro de la zona III
      case 4
        [h] = f_IRMc_h_IV_opt_fast (i_T0,i_TD,N,t,h,TA,TB,TC,TD  ,T0,  alfa_1,alfa_2,alfa_3,alfa_4, alfa_r_1,alfa_r_2,alfa_r_3,alfa_r_4);  % Cal. 'h' dentro de la zona IV                
      otherwise
         fprintf(' :( Zone error: zone = %i \n',zone); error(' ');  %f_pichichitus(8192);
    end       
%-------------------------------------------------------------------------    
    h = h*(c/(2*pi));  % Paso de 'omega',[rad] -> h(t)[m/s].
    
%--------------------------------------------------------------------------
% COMENTED FOR SPEED IMPROVEMENT...?
%--------------------------------------------------------------------------
    if (min(h) < -0.000001) || (max(h) > c) 
        disp(':( Error: Impulse response NEGATIVE or outside max_value...');  
        error(' ');
    elseif max(h) == 0
        fprintf('\n(o_o) Warning: Null IMPULSE RESPONSE...... \n');  
           disp('      Check "t_max" parameter or increase "fs"... ');
%        pause
    end    


%-------------------------------------------------------------------------    
% % Debug code only ------------------------------------------------------
%         figure(10); hold on; grid on; plot(h); plot(h,'r.')
%                
%         figure(222) hold on; grid on; % <------ estas pueden ser las problematicas
%         plot(alfa_1,'b');  plot(alfa_2,'r'); 
%         plot(alfa_3,'m');  plot(alfa_4,'k')
%         %---------------------
%   
%         figure(30); hold on; grid on;
%         plot(alfa_r_1,'b.');  plot(alfa_r_2,'r.')
%         plot(alfa_r_3,'m.');  plot(alfa_r_4,'k.')        
%         drawnow        
%--------------------------------------------------------------------------
