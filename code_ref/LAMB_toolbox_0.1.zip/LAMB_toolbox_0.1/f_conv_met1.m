function [s_c] = f_conv_met1(N,s1,s2)
% Funcion de convolucion alternativa
% metodo 1;  por FFT inversa
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   5/11/2004
% ver 1.1  17/12/2008    Old code active + elim. N = length(s1);

%---------------------------------------
% Old code active to save time! 
  S1 = fft(s1);
  S2 = s2;%fft(s2);
 S_C = S1.*S2;
 s_c = real(ifft(S_C));

  
%---------------------------------------
% New code with zero padding... inactive!!
% ya que no habia diferencias...
%
% ver 2.0   22/06/2005  Agregado de Zero-padding p/mejorar exactitud
% S1 = fft([s1; zeros(N-1,1)]);
% S2 = fft([s2; zeros(N-1,1)]);
% 
% S_C = S1.*S2;
% s_c = real(ifft(S_C));
% s_c = s_c(1:N,1);
%---------------------------------------

 




