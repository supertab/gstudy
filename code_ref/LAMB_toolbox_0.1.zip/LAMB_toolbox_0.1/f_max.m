function [M] = f_max(A)
% This function detects the maximum value 'M' for a
% cell array type data structure.
%            S_z = THS data cell array:  S_z = cell{Nt,num_modes}(Ny,Nx,N);
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    05/12/2008

M = 0;
if iscell(A)
    % Detection for "cell-array" data structures.
    [d1,d2] = size(A);
    for i = 1:d1
        for j = 1:d2
            d = size(A{i,j});
            switch(max(size(d)))
                case 1
                    M2 = max(A{i,j});
                case 2
                    M2 = max(max(A{i,j}));
                case 3
                    M2 = max(max(max(A{i,j})));
                otherwise
                    disp('Ups! Array size > 3 ;code not implemented yet... :)');
                    error('See: f_max routine...')                    
            end
            if M2 > M
                M = M2;
            end
        end
    end
else
    % Detection for "matrix-type" data structures.
    d = size(A{i,j});
    switch(max(size(d)))
        case 1
            M2 = max(A{i,j});
        case 2
            M2 = max(max(A{i,j}));
        case 3
            M2 = max(max(max(A{i,j})));
        otherwise
            disp('Ups! Array size > 3 ;code not implemented yet... :)');
            error('See: f_max routine...')                    
    end
    if M2 > M
        M = M2;
    end
end



