function [s] = f_s_pulsed(s_amp,f0,t)
% This function computes a pulsed signal 's(t)' of acoustic pressure in air using the 
% J.L.San Emeterio & L.G. Ullate model:  "Diffraction impulse response of rectangular transducers" 
%                                         J.Acoust. Soc. Am. 92(2) August 1992.
%
% Where:
%          s_amp = Signal's amplitude; typicaly in [Pa].
%             f0 = Bandwidth's (BW) central frequency.
%              t = Time axis [s].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   13/12/2006   English version. 
% ver 2.0   05/01/2008   Simplified ver.

[N,N2] = size(t);
if N <= N2
    N = N2;
    t = t';   % Convert row vector in column vector.
end    
    s = zeros(N,1);    

 beta = 3.25;           % Measurement adjustment parameter.
    k = 2;              % Value from San Emeterio & Ullate paper.        
    x = exp(-k*f0.*t);  
    s = -(t.^beta).*x.*cos((2*pi*f0).*t); % Final signal. 
                                          % Obs. the '-1' for making coincidence with measured signal!
    s = (s_amp/max(s))*s;                 % De-normalization for making a 'real' pressure signal [Pa].
    


    
    