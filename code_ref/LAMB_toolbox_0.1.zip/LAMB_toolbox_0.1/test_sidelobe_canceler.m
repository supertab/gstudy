function [M] = test_sidelobe_canceler()
% Test are code for sidelobe canceler (SLC)
% Donde:
%        O = Coord. del centro
%        R = Radio.
%        N = Nro. de puntos del circulo.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   02/06/2006

        c = 343.8094       % Sound velocity in air [m/s].
   cph_S0 = 5440;          % S0 mode phase velocity [m/s].
   cph_a0 = 2550;          % A0 mode phase velocity [m/s].

       f0 = 0.850*10^6     % Signal's main frequency [Hz].
     f0_i = 0.300*10^6     % Signal's main frequency [Hz].
     
    f_min = 0.02*10^6       % Inferior BW-frequeny limit for integration [Hz].
    f_max = 2.00*10^6       % Superior BW-freq. limit [Hz].         
       fs = 100*10^6       % Sampling frequency for THS [Hz].
                           % f_s = fs/N  Frequency step spacing [Hz].                               
    t_min = 0              % Minimum limit for temporal displacement signals [s].
    t_max = 0.000100       % Maximum limit [s].

   s_type = 1              % 1 -> Sinusoidal (CW).
    s_amp = 10^-6          % Main signal amplitude.
  s_amp_i = 10*10^-6       % Interference signal amplitude.
       P0 = 0;             % Initial phase of main sinus signal [Rad].
     P0_i = 0;             % Initial phase of interference sinus signal.

       
        M = 5              % Number of sub-array elements.
        d = 0.0004         % Separation between sensors [m]
        
       Nd = 100            % Longitude of block data for SLC.
       n1 = 1;             % Data cutting window 
       n2 = 10000;
  n_level = 1*10^-12 % 0.06*10^-12  % If > 0 Add fixed white Gaussian 'noise_level' to FRM signals in [W] @R_load = 1ohm.
f_def_x_a = 1;             % Type of 'x_a' signal definition.

%---------------------------------
% Generate dummy data
n_level_dB = 10*log10(n_level);  % 'n_level' is expressed in [W].
   n_burst = 0;   
  t = (t_min:1/fs:(t_max-1/fs))';
  N = max(size(t));
  s = f_gen_signal(N,n_burst,s_type,s_amp,f0,fs,P0,t);       % Main signal.
s_i = f_gen_signal(N,n_burst,s_type,s_amp_i,f0_i,fs,P0_i,t); % Interference signal.


delta_s0 = d/cph_S0;  
delta_a0 = d/cph_a0;    
Ps = zeros(N,M);
for j = 1:M
    delay = (j-1)*delta_s0;
      s_d = f_delay_signal(fs,N,delay,s(:),1);
      
    delay = (j-1)*delta_a0;
    s_d_i = f_delay_signal(fs,N,delay,s_i(:),1);
        w = wgn(N,1,n_level_dB);
  Ps(:,j) = s_d + s_d_i + w;
end
    
% figure(1); hold on; grid on;   
% plot(t,Ps(:,1),'b');
% plot(t,Ps(:,j),'k');
% plot(t,s_i,'c');
% plot(t,s,'g');

%---------------------------------
% Call SLD
n_level_2 = 0;
[t2,y,y_fil] = f_sidelobe_canceler(d,M,Nd,n_level_2,fs,f_min,f_max,t,Ps,n1,n2,f_def_x_a);

  [S,F] = f_cal_spectra(fs,s);
[S_i,F] = f_cal_spectra(fs,s_i);
 [Sp,F] = f_cal_spectra(fs,Ps(:,1));
%[Syf,F2] = f_cal_spectra(fs/10,y_fil);
 [Syf,F2] = f_cal_spectra(fs,y_fil);


figure(100); hold on; grid on;   %plot(t2(1:N2-M+1),y);
plot(t2(1:max(size(y_fil))),y_fil,'r');
plot(t,s,'g');


figure(210); hold on; grid on;   
plot(F,log10(Sp(:,1)),'b');
plot(F,log10(S_i(:,1)),'c');
plot(F,log10(S(:,1)),'g');

plot(F2,log10(Syf(:,1)),'r');
axis([0*10^6 1.2*10^6 -20 2])





1
2




