function [Vs3_3] = f_FRM_post_process(c,N_r_ele,Nxc3,Nyc3,r3_type,R_3,P_field_3,Xc3,Yc3,Zc3,Vs3_2,theta,steer_ang,Nt,Ns,N3,fs,f_plot,f_handle,axis_font)
% This function post-process the signals for the aperture receiving elements.
%
% 1. By now, this implies only delay the receiving signals for a given reception angle.
%    This assumes delay profiles along X-axis only (equal delays along Y-strip lines).
%
% Parameters:
%                      c = Speed of sound in air [m/s].
%                N_r_ele = Nxc3*Nyc3 -> Number of receiving elements on reception aperture.
%              Nxc3,Nyc3 = Number of reception elements of the aperture.
%                r3_type = Type of reception region (point, line, plane & shell).
%                    R_3 = Curvature radius of field reception region [m].
%              P_field_3 = Reception aperture field center point.
%            Xc3,Yc3,Zc3 = Receiving elements coordinate center's.
%                  Vs3_2 = Composed & converted array data signals: Vs3_2 = zeros(Nt,Nxc3,Nyc3,N3).
%                  theta = Incident angle vector [Deg].
%              steer_ang = Aperture steering angle vector [Deg].
%                     Nt = Number of incident angles.
%                     Ns = Number of steering angles of reception diagram.
%                     N3 = Number of points of signals.
%                     fs = Sampling frequency [Hz].
%                 f_plot = Flag for plotting figures: 1 -> Plot.   0 -> Do not.
%               f_handle = Figure number.
%              axis_font = Size of font title.
%
%  Vs3_3(Nt,Ns,Nxc3,Nyc3,:) = Matrix w/delayed signals 4 'Nt' field-incident Angs & 'Ns' steering dirs.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    07/01/2009     Using data from engine: 'f_IRM_main_2D_2v3' v1 (11/12/2008).
% ver 2.0    09/01/2009     Add of incident angle vector 'theta'.
% ver 2.1    29/01/2009     Assume delays along X-axis only & name change 'f_FRM_post_process_signals' -> 'f_FRM_post_process'.
% ver 3.0    05/02/2009     Cal. for steering angle vector added.
% ver 3.1    23/02/2009     Added 'P_field_3' parameter.
% ver 3.2    28/02/2009     'Amp_gain' added + Change in 'fs_IMR' --> 'fs' because of use downsampled data.
% ver 3.3    29/03/2009     Detection of single element aperture: 'N_r_ele' param. added.


fprintf('3.3.  Post-precessing data... \n');
%--------------------------------------------------------------------------
% 3.3 Post-processes of element's signals: filter, delay, etc...
if r3_type == 0 
    R_3 = min(max(Zc3));  % If use of plane grid...then assing fixed distance to normal vector at ele. center's.
end
%--------------------------------------------------------------------------------------------------------------
% Begin delay process...
if N_r_ele > 1    
if (Ns == 0) || isempty(Ns)
    %--------------------------------------------------------------------------------------------------------------
    % Post process data for 'Nt' incident angles.
    fprintf('3.3.1 Delaying signals alogn X-axis. Nt = %i ',Nt); for i=1:Nt fprintf('@%.1f',theta(i)); end; fprintf('� \n'); 
      f_color = 'b';
      
   s_t = zeros(1,N3);
  s_t0 = zeros(1,N3);
%  figure(900);
            s = zeros(1,N3);
    ele_delay = zeros(Nxc3,Nt);         % We assume delay profiles along X-axis only (equal delays along Y-strip lines).
        Vs3_3 = zeros(Nt,Nxc3,Nyc3,N3); % Composed & delay array data signals for 'Nt' incident angles.
    for k = 1:Nt
    steer_ang = 0;                      % Set null steering angle 4 equalize possible concave array shape
        O_ele = [Xc3(:,1) Yc3(:,1) Zc3(:,1)];  % Coord. vector for X-line central receiving elements.
        if (Nt > 1) && (k > 1) f_plot = 0; end % Turn off plotting feature 4 rest of incident angles.
        ele_delay(:,k) = f_cal_t_delay_FOPD(c,R_3,Nxc3,P_field_3,O_ele,1,Nxc3,steer_ang,f_plot,f_handle,axis_font,f_color,0); % Cal. 'theta(k)' corresponding delay [s].
        for i = 1:Nxc3
%            i
            %------------------------------------------------------------------
            % Delay Y-strip line signals 4 element [Xc3(i,:) Yc3(i,:) Zc3(i,:)].
            for j = 1:Nyc3
                s(1,:) = Vs3_2(k,i,j,:);
                   s_d = f_delay_signal(fs,N3,ele_delay(i,k),s',1);
        Vs3_3(k,i,j,:) = s_d;
        
               s_t = s_t + s_d';
               s_t0 = s_t0 + s;
%                figure(900);
%                plot(s_t,'b'); 
%                hold on; grid on;
%                plot(s_t0,'r'); 
%                hold off; grid on;
            end
            %------------------------------------------------------------------
        end
    end
    if f_plot
        figure(30); hold on; grid on;
        plot(ele_delay*10^6);   plot(ele_delay*10^6,'bo');
        xlabel(' Reception element number','FontSize',axis_font);  ylabel(' t_delay [us]','FontSize',axis_font); 
        if max(ele_delay) < 0.1*10^-6   axis([1 Nxc3 0 1]);  end;
    end
    %--------------------------------------------------------------------------------------------------------------
else
    %--------------------------------------------------------------------------------------------------------------
    % Post process data for 'Ns' steering angles!
    fprintf('3.3.2 Steering signals alogn X-axis...  \n');   
    fprintf('      theta: ');
            s = zeros(1,N3);
    ele_delay = zeros(Nxc3,Ns);            % We set delays along X-axis only (equal delays along Y-strip lines).
        Vs3_3 = zeros(Nt,Ns,Nxc3,Nyc3,N3); % Composed & delay data matrix 4 'Nt' incident & 'Ns' steering angles.
    
    for k = 1:Nt
        % Process incident angle 'theta(k)'
        fprintf(' %.1f�',theta(k));
        for l = 1:Ns
%            [l steer_ang(l)]
            if l == 1                  f_color = 'b'; 
            elseif  steer_ang(l) > 0   f_color = 'g';   
            elseif  steer_ang(l) == 0  f_color = 'r';   
            else                       f_color = 'c';   
            end;
            if (Nt > 1) && (k > 1) f_plot = 0; end % Turn off plotting feature 4 rest of incident angles.
                     O_ele = [Xc3(:,1) Yc3(:,1) Zc3(:,1)];  % Coord. vector for X-line central receiving elements.
            ele_delay(:,l) = f_cal_t_delay_FOPD(c,R_3,Nxc3,P_field_3,O_ele,1,Nxc3,steer_ang(l),f_plot,f_handle,axis_font,f_color,1); % Cal. 'theta(k)' corresponding delay [s].
            if f_plot 
                figure(30); plot(ele_delay(:,l)*10^6,f_color); drawnow;
            end
            for i = 1:Nxc3
                % [steer_ang(l) i]
                %------------------------------------------------------------------
                % Delay Y-strip line signals 4 element [Xc3(i,:) Yc3(i,:) Zc3(i,:)].
                for j = 1:Nyc3
                              s(1,:) = Vs3_2(k,i,j,:);
                    Vs3_3(k,l,i,j,:) = f_delay_signal(fs,N3,ele_delay(i,l),s',1);
                end
                %------------------------------------------------------------------
            end
        end
    end
    %--------------------------------------------------------------------------------------------------------------
end
else % From -> if N_r_ele > 1 
    fprintf(':| No data to post-process:  N_r_ele = %i \n',N_r_ele);
    Vs3_3 = Vs3_2;
end
fprintf(' \n');

