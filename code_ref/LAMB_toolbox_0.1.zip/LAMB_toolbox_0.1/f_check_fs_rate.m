function [N2,t2,fs2,f,Signal2] = f_check_fs_rate(c,d,steer_s,N,t,fs,f_min,f_max,Signal,f_delay)
% Function for checking the sampling rate of a given matrix signals for later Beamforming.
% If the present 'fs' rate is lower than the desired beamformer steering
% angle step, then the column-matrix Signals is up-sampled.
%
% Parameters:
%            c = Speed of sound in air [m/s].
%            d = Separation between array's sensors.
%      steer_s = Minimum step of steering angle.
%            t = Signal's time vector [s].
%       Signal = zeros(Nt,Nxc3,Nyc3,N3) -> Composed array signals.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    17/12/2009


fs_2 = c/(d*sin(steer_s*pi/180));
 fs2 = f_round(fs_2,10^6,0);
if fs < fs2
    %----------------------------------------------------------------------
    % Upsample array signals.
         t2 = (min(t):1/fs2:max(t));  % New down-sampled time vector.
         N2 = max(size(t2));
    f_quiet = 0; % Plot info
    Signal2 = f_resample_data(N,N2,fs,fs2,t,t2,Signal,f_quiet);
    %----------------------------------------------------------------------
else
    %----------------------------------------------------------------------
    fprintf('        fs = %.1f MHz  Ok :) \n',fs/10^6);  
    fprintf('       fs2 = %.1f MHz   No up-sampling needed.\n',fs2/10^6);
    %----------------------------------------------------------------------
     N2 = N;         t2 = t;     
    fs2 = fs;   Signal2 = Signal;
end

f_s = fs2/N2;             % Frequency spacing 'step' between mode's frequency points [Hz].
  f = (f_min:f_s:f_max)'; % Frequency operating bandwidth [Hz].  

  
%--------------------------------------
% Correct time vector in 'f_delay' [s].
if f_delay
    t2 = t2 + f_delay;
end
  
  