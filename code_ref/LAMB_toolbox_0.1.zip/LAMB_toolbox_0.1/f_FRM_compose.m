function [Ps3_1,N_s_ele,N_r_ele] = f_FRM_compose(Nxc3,Nyc3,Xc3,Yc3,Zc3,x_s3,y_s3,X3,Y3,Z3,Ps3,theta,Nt,N3,t,f_handle,f_plot_ele)
% This function composes (add signals) the acoustic field received by individual
% elements of the reception aperture.
% Parameters:
%              Nxc3,Nyc3 = Number of receiver elements (X,Y) on reception aperture (array).
%            Xc3,Yc3,Zc3 = Receiving elements center's coordinates.
%              x_s3,y_s3 = Width & high dimension of receiving elements.
%               X3,Y3,Z3 = Coodinates of receiving field.
%                    Ps3 = IRM data cell array:  Ps = cell(Nt,1) zeros(Nx3,Ny3,N3);
%                  theta = Incident angles [Deg] vector of THS excitation field.
%                     Nt = Number of incident angles. 
%                     N3 = Number of points of signals.
%                      t = Time vector for signals [s].
%             f_plot_ele = 1 -> Plot points corresponding to receiving element.
%                          0 -> Do not plot.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    07/01/2009    Using data from engine: 'f_IRM_main_2D_2v3' v1 (11/12/2008).
% ver 2.0    09/01/2009    Add of incident angle vector 'theta'.
% ver 2.1    29/01/2009    Change of name: 'f_FRM_compose_signals' --> 'f_FRM_compose'.


%--------------------------------------------------------------------------
% 3.1 Compose individual element signals by adding points inside element boundaries.
disp('3.1. Composing sensor signals...')
%figure(f_handle+31); hold on; grid on; 
%  color = ['bgrcmk'];
%      n = 1; 
%     nc = 1;
N_r_ele = Nxc3*Nyc3;              % Number of array receiving elements!
N_s_ele = zeros(Nxc3,Nyc3);       % Matrix with individual number of sub-eles. by reception element.
  Ps3_1 = zeros(Nt,Nxc3,Nyc3,N3); % Composed array signals.
      
for k = 1:Nt % Index for incident angle (theta) of THS excitation field.
        M = max(max(max((Ps3{k}))));
    for i = 1:Nxc3
        for j = 1:Nyc3
            if f_plot_ele 
                figure(f_handle); plot3(Xc3(i,j),Yc3(i,j),Zc3(i,j),'co'); 
%                f_plot_ele = n;
            end;
            % Compose signals for receiving element: [Xc3(i,j) Yc3(i,j) Zc3(i,j)].
                 [i3,j3] = find( (abs(X3 - Xc3(i,j)) <= x_s3/2) & (abs(Y3 - Yc3(i,j)) <= y_s3/2) );
                      ps = f_FRM_compose_ele_signal(X3,Y3,Z3,Ps3,k,N3,i3,j3,f_plot_ele,f_handle); 
          Ps3_1(k,i,j,:) = ps;
            N_s_ele(i,j) = length(i3);  % Save number of points inside element(i,j).
%                       n = n + 1;
                       
%            figure(f_handle+31);  plot(t,ps + i*j*M,color(nc));  drawnow;
        end
    end
%     if nc < 6, nc = nc + 1;
%     else       nc = 1;  end;
end

%---------------------------------------------------------
% Plot 1st. element.
figure(f_handle); 
plot3(Xc3(1,1),Yc3(1,1),Zc3(1,1),'ro'); 
plot3(Xc3(1,1),Yc3(1,1),Zc3(1,1),'g*'); 





