function [zc_time] = f_cal_zero_cross_signal(delay_type,N,fs,s)
% Funcion de deteccion del cruce x zero de una se�al
% a partir del valor maximo positivo(si hay +1, toma el 1ero.).
%
% Obs: no olvidar a tener en cuenta como se toma el origen del vector de
%      tiempos 't' si comienza en: t(1) = 0,  o  t(1) = 1/fs
% 
% Obs.2:   
%         delay_type =  0 -> Cal. a partir del pico(+)
%                       1 -> Cal. a partir del pico(-)
%                       2 -> Cal. a partir envolvente de la se�al x T.Hilbert!
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    7/11/2004
% ver 1.1   29/03/2006      

        y_max = 0;
[s_max,i_max] = max(s);   % Deteccion del pico maximo positivo y su indice
[s_min,i_min] = min(s);   % Deteccion del pico maximo negativo y su indice

n = 1;
switch delay_type
    case 0  % Calculo a partir del pico(+)
        i = i_max;
        while i < N
            if s(i) > 0
                i = i + 1;
            else    
                n = i;  
                i = N+1; 
            continue           
            end  
        end   

        if (n==1)
            n=2; 
        end    
        n = (s(n)/(s(n-1)-s(n))) + n; % Interp. lineal p/detect. cruce x '0'
        zc_time = (n-1)/fs;           % Es 'n-1', ya que:  t(1) = 0, sino seria '(n)/fs'

    case 1 % Calculo a partir del pico(-)
        disp('Ups! Case for delay_type = (-)pic not implemented yet!...  sorry :) ');  error(' ');        
        
    case 2 % Calculo a partir de la envolvente de la se�al!!!
              y = hilbert(s);
              y = abs(y);
[y_max,y_index] = max(y);   % Obs. descartamos el computo del val. max. xque es mayor que el verdadero debido a T.Hilbert
        zc_time = y_index/fs;
    otherwise
        disp('Error case not defined 4 delay_type  variable!');
        error(' ');        
end
    


