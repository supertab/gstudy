function [C_A_z] = f_THS_C_a_z_Ach(h,z,P,k,p,q,Mu)
% This function calculate's the 'Anti-Symmetric' coeficients 'C_A_z'  
% for the ifft sumation of Lamb modes based on the paper from:
% J.D.Achenbach aproach. "Use of elastodynamic reciprocity to 
% analize point-load generated axisymmetric waves in a plate". 
% Elsevier, Wave Motion 30 (1999) 57-67.
% Obs.:   
%             h = d/2 plate thickness [m].
%             z = Z coordinate on the plate.
%             P = Pressure spectrum matrix (modulus,phase) applied in circular region [Pa].
%             k = wavenumber [Rad/m].
%             p = Longitudinal wavenumber [Rad/m].
%             q = Tranverse wavenumber [Rad/m].
%            Mu = Lame constant [Pa].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0  06/06/2005
% ver 2.0  21/08/2008     English version.

B = 1;     % ALWAYS (because of dummy solution...)

% A N T I - S Y M M E T R I C coeficients --------------------------------------------
%     a1 = 2*sin(q*h);                              % Used for radial displacements only.
%     a2 = (-((k.^2)-(q.^2))./(k.^2)).*sin(p*h);    % Used for radial displacements only.
      a3 = -2*(p./k).*sin(q*h);
      a4 = (((k.^2)-(q.^2))./(q.*k)).*sin(p*h);
      
     W_A = B*( (a3.*cos(p*z)) + (a4.*cos(q*z)) ); 

  c_A_1  =  ( ((k.^2)-(q.^2)).*((k.^2)+(q.^2))./(2*(q.^3).*(k.^3)) ) .*  ( (2.*q.*h.*((k.^2)-(q.^2))) + (((k.^2)+(7*(q.^2))).*sin(2.*q.*h)) );
  c_A_2  =  ( ((k.^2)+(q.^2))./(p.*(q.^3)) ) .* ( (4.*(k.^2).*p.*h) - (2.*((k.^2)-(2.*(p.^2))).*sin(2.*p.*h)) );

     I_A = Mu*( (c_A_1.*((sin(p*h)).^2)) + (c_A_2.*((sin(q*h)).^2)) );
   
     D_A = (k.*P.*W_A)./(4*i*I_A);
   
   C_A_z = D_A.*( (a3.*cos(p*z)) + (a4.*cos(q*z)) );
%--------------------------------------------------------------------------