function [O_c_ele,O_ele,ang_ele,a] = f_FIRST_cal_coord_eles(apertura,ele_order,OA,N_ele,N_s_ele,a0,p,R,f_plate_handle)
% Funcion que calcula las coord. de los puntos centrales de las caras 
% de los elementos del array; referidas al origen de coord. del mismo:
% Parametros: 
%                'OA', centro geom�trico de la apertura o Array, referido a O(0,0) global,(ver def. paper Ullate)
%                 R = radio de curvatura del Array
%             N_ele = nro. de elementos del Array
%                 p = espacio entre elementos.Obs.: p < 0  --> translape de elementos
% Obs.:
%     'ele.'   -> 'elementos' c/u de los def. p/el Array
%     's_ele.' -> 'sub-elementos', c/u de los que compondran un 'ele.' indiv. del Array.
%
% Retorna: 
%           a =  semi-ancho final de los eles. o s_eles. "rectangulares" que componen la apertura definida.
%       O_ele =  coordenadas de los eles. o s_eles que compongan la apertura definida, referido a O(0,0) global.
%     ang_ele = 'angulos de giro' [Rad.] de c/u de los eles. o s_eles. de la apertura en torno al eje 'Y'.
%-----------------------------------------------------------------------------------------------
%
% ver 1.0    23/10/2004   
% ver 2.0    18/11/2004   Inclusion del Origen generalizado del Array 'OA'
% ver 3.0    05/10/2005   Reestruc. completa del code y agreg. cal. coord. sub-elementos con posible translape.
% ver 3.1    29/05/2006   Agregado devolucion centros elementos p/arrays c/SNIE's:  variable 'O_c_ele'
% ver 4.0    27/11/2009   Adaptation for LAMB program ver 0.1

if f_plate_handle > 0
    figure(f_plate_handle); hold on; grid on;
end

if  R == inf  R = 1000  % Solve problem of true 'plane array', by a concave one w/radius = 1kmt!
end
d = 2*a0+p;    % Distancia entre los centros de los elementos (paso).

switch apertura
    case {0,2}            % 1 ele. ideal(SIE) || Array de SIE's
        [ang_c_ele] = f_cal_ang_eles(ele_order,N_ele,d,R);       % Cal. angulos centros elementos Array 'ang_c_ele'
           O_ele = zeros(N_ele,3);                     % Origen de coord. de c/u de los eles. del array...
        for i = 1:N_ele
            O_ele(i,1) = R*sin(ang_c_ele(i));       % coord. 'x' (plano Y=0)
            O_ele(i,3) = R*(1-cos(ang_c_ele(i)));      % coord. 'z'
            O_ele(i,:) = O_ele(i,:) + OA;              % Translacion de coord de O(0,0,0) -> OA(x,y,z)
        end
        O_c_ele = O_ele;
        ang_ele = ang_c_ele;  % Esto solo esta, p/recordar que estamos trabajando con eles. en este caso.
              a = a0;                                  % Retorna el semi-ancho corresp. de las aperturas rectangulares mas peque�as donde se calcula 'h'           
    %----------------------------------------------------------------------
    case {1}              % 1 ele. no-ideal(SNIE) || Array de SNIE's
                   a_s = a0/N_s_ele                    % semi-ancho de los sub.eles. 
                   d_s = 2*a_s                         % distancia entre centros de lo sub.eles. para 'p=0', ya que van juntos x ser la discretizacion
         [ang_c_s_ele] = f_cal_ang_eles(ele_order,N_s_ele,d_s,R);% Cal. angulo sub-eles del unico elemento def.
                 O_ele = zeros(N_s_ele,3);             % Origen de coord. de c/u de los sub-eles.
       for i = 1:N_s_ele 
            O_ele(i,1) = R*sin(ang_c_s_ele(i));     % coord. 'x' (plano Y=0)
            O_ele(i,3) = R*(1-cos(ang_c_s_ele(i)));    % coord. 'z'
            O_ele(i,:) = O_ele(i,:) + OA;              % Translacion de coord de O(0,0,0) -> OA(x,y,z)
        end
        O_c_ele = O_ele;
        ang_ele = ang_c_s_ele;  % esto solo esta, p/recordar que estamos trabajando con sub-eles. en este caso.
              a = a_s;                                 % Retorna el semi-ancho corresp. a las aperturas a calcular 'h'.
    %----------------------------------------------------------------------
    case {3}              % Array de no-ideal(SNIE's)
                    a_s = a0/N_s_ele                   % semi-ancho de los sub.eles. 
                    d_s = 2*a_s                        % distancia entre centros de lo sub.eles. para 'p=0', ya que van juntos x ser la discretizacion
            [ang_c_ele] = f_cal_ang_eles(ele_order,N_ele,d,R);   % Cal. angulo eles.
          [ang_c_s_ele] = f_cal_ang_eles(ele_order,N_s_ele,d_s,R); % Cal. angulo sub-eles.
                N_t_ele = N_ele*N_s_ele;               % Nro. total de sub-elementos del array/apertura def.
                 O_ele = zeros(N_t_ele,3);             % Origen de coord. de c/u de los eles. del array...
                ang_ele = zeros(N_t_ele,1);            % ang. de giro de los sub-eles. en torno al eje 'Y'.
            k = 1;
        for i = 1:N_ele
            for j = 1:N_s_ele
               ang_ele(k,1) = ang_c_ele(i,1) + ang_c_s_ele(j,1); % suma angulos: 'ele' + 'sub_ele'
                O_ele(k,1) = R*sin(ang_ele(k,1));   % cal. coord. 'x' (plano Y=0)
                O_ele(k,3) = R*(1-cos(ang_ele(k,1)));  % cal. coord. 'z'
                                                       % Obs. la coord.'y' es siempre =0, ya que los eles. giran en torno al eje 'Y'
                O_ele(k,:) = O_ele(k,:) + OA;          % Translacion de coord de O(0,0,0) -> OA(x,y,z) donde debe estar el Array.
                f_plot_array(i,O_ele(k,:));            % Dibuja la apertura en colores tomando solo las coord. 'X' y 'Z' de 'O_ele'
                k = k + 1;
            end   
            O_c_ele(i,1) = R*sin(ang_c_ele(i));     % Cal. coord. 'x' centros de los eles. (plano Y=0)
            O_c_ele(i,3) = R*(1-cos(ang_c_ele(i)));    % Idem coord. 'z'
            O_c_ele(i,:) = O_c_ele(i,:) + OA;            % Translacion de coord de O(0,0,0) -> OA(x,y,z)
            plot(O_c_ele(i,1),O_c_ele(i,3),'r.')
        end             
        a = a_s      % Retorna el ancho corresp. a las aperturas a calcular 'h'
        if f_plate_handle > 0
            plot(O_ele(1,1),O_ele(1,3),'r+')   % 1er. ele./sub-ele.
            plot(OA(1,1),OA(1,3)+R,'ro')       % centro del Array 
        end
    %----------------------------------------------------------------------
    otherwise
     disp('Error en tipo de apertura: apertura no definida.')
     pause
end

%--------------------------------------------------------------------------
% Plot array element centers. 
% Remember the main array plane by definition is XZ-plane (see paper JASA: Ullate & Emeterio)
if f_plate_handle > 0
    plot3(O_ele(:,1),O_ele(:,2),O_ele(:,3),'bo');  % centros de los eles./sub-eles
    plot3(O_ele(1,1),O_ele(1,2),O_ele(1,3),'r.');  % 1er. ele./sub-ele.
    plot3(OA(1,1),O_ele(1,2),OA(1,3),'g+');        % Array center.
    view(0,0);
end




%--------------------------------------------------------------------------
% Optional code 4 cheking...
%
%     c_array = sqrt((O_ele(1,1)-O_ele(N_ele,1))^2 +... 
%                    (O_ele(1,2)-O_ele(N_ele,2))^2 + ...
%                    (O_ele(1,3)-O_ele(N_ele,3))^2)  % Cuerda subtendida entre los eles. extremos
%           
%     ang_array = acos(1 - (c_array^2)/(2*R^2));  % Ang. de apertura desde su centro a los eles. extremos
%     ang_array = ang_array*180/pi    % Pasaje de Radianes a Grados (�)  
% 
%     if N_ele > 1
%        t_max_array = (O_ele(N_ele,3) - OA(1,3))/c   % tiempo maximo p/hacer plano un frente de onda en todo el Array
%     else 
%        t_max_array = 0;
%     end
%--------------------------------------------------------------------------


