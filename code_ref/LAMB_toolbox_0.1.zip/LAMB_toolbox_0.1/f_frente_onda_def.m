function [Di,id] = f_frente_onda_def(O_ref,xy_ref,m_fop,alfa_r,j,k,N_ele,R,f_plot,f_handle,f_color)
% Calculos para arrays circulares de los puntos de interseccion y distancias del FOPD.
% Donde el FOPD se encuentra sub-tendido entre los eles. 'j' y 'k' del
% array, cuanquiera de los 'N' definidos p/el mismo.
% Obs.:
%       j = 1er.   elemento p/el FOPD   
%       k = ultimo elemento p/el FOPD   
% 
% ver 2.0     23/11/2005
% ver 2.1     29/03/2006   Agreg. dist. generalizada 'R' de las rectas
% ver 2.2     09/01/2009   Added plotting flag capability.
% ver 3.3     23/02/2009   New code.
% ver 3.3.2   01/12/2009   Selective figure plotting added.

if f_plot
    if (f_handle <= 0) || isempty(f_handle)
        f_handle = 999002; figure(f_handle); hold on; grid on;    
    end
end

m_low = 10^-14;
if O_ref(2) >= 0.9999*mean(xy_ref(:,2))  %Old condition:  sum(O_ref - mean(xy_ref)) >= 0
    %----------------------------------------------------
    % Para array's mirando hacia ordenadas negativas (-).
    if m_fop < 0  && alfa_r >= 0
            gama_r = atan(m_fop) - alfa_r;
               m_d = tan(gama_r);                           % Pendiente del FOPD que pasa x el elemento 'k' 
            FOPD_j = f_recta_P0_m(O_ref,xy_ref(j,:),m_d,-R);   % Recta del FOPD que pasa x el elemento 'k'
              FOPD = FOPD_j;
    elseif m_fop < 0  && alfa_r < 0
            gama_r = atan(m_fop) - alfa_r;
               m_d = tan(gama_r);                           % Pendiente del FOPD que pasa x el elemento 'k' 
            FOPD_k = f_recta_P0_m(O_ref,xy_ref(k,:),m_d,R); % Recta del FOPD que pasa x el elemento 'j'
              FOPD = FOPD_k;
    elseif m_fop > 0  && alfa_r >= 0
            gama_r = atan(m_fop) - alfa_r;
               m_d = tan(gama_r);                           % Pendiente del FOPD que pasa x el elemento 'k' 
            FOPD_j = f_recta_P0_m(O_ref,xy_ref(j,:),m_d,-R);% Recta del FOPD que pasa x el elemento 'k'
              FOPD = FOPD_j;
                 %R = -R;
    elseif m_fop > 0  && (alfa_r < 0)
            gama_r = atan(m_fop) - alfa_r;
               m_d = tan(gama_r);                           % Pendiente del FOPD que pasa x el elemento 'k' 
            FOPD_k = f_recta_P0_m(O_ref,xy_ref(k,:),m_d,R); % Recta del FOPD que pasa x el elemento 'k'
              FOPD = FOPD_k;
                 R = -R;
    elseif m_fop == 0 && alfa_r >= 0
             m_fop = m_low;
            gama_r = atan(m_fop) - alfa_r;
               m_d = tan(gama_r);                           % Pendiente del FOPD que pasa x el elemento 'k' 
            FOPD_j = f_recta_P0_m(O_ref,xy_ref(j,:),m_d,-R);   % Recta del FOPD que pasa x el elemento 'k'
              FOPD = FOPD_j;
    else  % m_fop == 0 && alfa_r <= 0
             m_fop = m_low;
            gama_r = atan(m_fop) - alfa_r;
               m_d = tan(gama_r);                           % Pendiente del FOPD que pasa x el elemento 'k' 
                 R = -R;
            FOPD_k = f_recta_P0_m(O_ref,xy_ref(k,:),m_d,R); % Recta del FOPD que pasa x el elemento 'j'
              FOPD = FOPD_k;
    end
    %----------------------------------------------------
else
    %----------------------------------------------------
    % Para array's mirando hacia ordenadas Positivas (+).
    %----------------------------------------------------
    if m_fop < 0  && alfa_r >= 0
        disp(':( Ups... not yet implemented!')
        error(' ');
    elseif m_fop < 0  && alfa_r < 0
        disp(':( Ups... not yet implemented!')
        error(' ');
    elseif m_fop > 0  && alfa_r >= 0
        disp(':( Ups... not yet implemented!')
        error(' ');
    elseif m_fop > 0  && alfa_r < 0
        disp(':( Ups... not yet implemented!')
        error(' ');
    elseif m_fop == 0 && alfa_r >= 0
             m_fop = m_low;
            gama_r = atan(m_fop) - alfa_r;
               m_d = tan(gama_r);                             % Pendiente del FOPD que pasa x el elemento 'k' 
            FOPD_j = f_recta_P0_m(O_ref,xy_ref(j,:),m_d,-R);   % Recta del FOPD que pasa x el elemento 'k'
              FOPD = FOPD_j;
    else  % m_fop == 0 && alfa_r <= 0
        disp(':( Ups... not yet implemented!')
        error(' ');
    end
end


if f_plot
    figure(f_handle);
    if alfa_r == 0
        plot3(FOPD(:,1),[0 0],FOPD(:,2),'b');
    elseif alfa_r > 0
        plot3(FOPD(:,1),[0 0],FOPD(:,2),'g');
    else
        plot3(FOPD(:,1),[0 0],FOPD(:,2),'c');
    end
    view(0,0);
end

id = zeros(N_ele,1);
Di = zeros(N_ele,2);
for n = j:k
    [r_normal_i_d] = f_recta_P0_m(O_ref,xy_ref(n,:),-1/m_d,R);    % Normal que pasa x 'i' y es perpend. al FOPD
                di = f_r_intersec(FOPD,r_normal_i_d);             % pto. intersect. de la Normal y el FOPD (punto 'Di')
                %------------------------------------------                
                % Correct possible non itersected lines by recalculation.
                if isnan(di(1)) || isnan(di(2)) || isempty(di(1)) || isempty(di(2))
        [r_normal_i_d] = f_recta_P0_m(O_ref,xy_ref(n,:),1/m_d,R); % Recal. deflected plane-wave front (DPW).
                    di = f_r_intersec(FOPD,r_normal_i_d);         % Recal. normal to DPW.
                    pause
                end;
                %------------------------------------------
         [Di(n,:)] = di;
             id(n) = f_dist_P1_P2(xy_ref(n,:),Di(n,:));           % Distancia del elemento 'i' al punto 'Di'
                
    if f_plot && (n == j)
        figure(f_handle);
        plot3(r_normal_i_d(:,1),[0 0],r_normal_i_d(:,2),f_color); % plot de la recta Normal del FOPD
        plot3(Di(n,1),[0 0],Di(n,2),'k.');
    end
end    

