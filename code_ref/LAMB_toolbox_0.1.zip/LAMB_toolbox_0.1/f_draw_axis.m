function f_draw_axis(O,axis_dim)
% Draw a X,Y and Z axis.
% Parameters:
%                 O = Axis origin [m].
%          axis_dim = Axis longitude dimesions [m].
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0 15/12/2008


%-----------------------------
% Define axis vectors.
X = [O(1) O(2) O(3); O(1)+axis_dim(1)  O(2)  O(3)];
Y = [O(1) O(2) O(3); O(1)  O(2)+axis_dim(2)  O(3)];
Z = [O(1) O(2) O(3); O(1)  O(2)  O(3)+axis_dim(3)];

plot3(X(:,1),X(:,2),X(:,3),'k');
plot3(Y(:,1),Y(:,2),Y(:,3),'k');
plot3(Z(:,1),Z(:,2),Z(:,3),'k');

text(X(2,1),O(2),O(3),'X','VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',12);
text(O(1),Y(2,2),O(3),'Y','VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',12);
text(O(1),O(2),Z(2,3),'Z','VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',12);

axis auto;


