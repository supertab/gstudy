function [t2] = f_check_t_max(c,f_cph_mapping,num_modes,s_type,O,P_far,t_max,W,K)
% This function verifies that the value for maximum signal's time (t_max) 
% is in correspondance to the farthest point to calculate (P_far). This is 
% for avoiding problems of cutting signal traces due to possibly circular 
% convolutions problems.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    01/12/2008    Complete new version!
% ver 1.1    29/01/2009    Plot of air speed value added.


if (~f_cph_mapping) && (s_type ~= 1)
    %--------------------------------------------------------------------------
    % Calculate maximum time needed by Lamb modes to reach farthest point.
       Vg = zeros(num_modes,1);
    for i = 1:num_modes
        Vg_min(i) = min(diff(W{i})./diff(real(K{i}))); % Minimum group velocity for mode 'i'.
    end
   Vg_min = min(Vg_min);      % Absolute all Lamb wave mode's group velocity [m/s].
    d_max = sqrt(((P_far(1) - O(1))^2) + ((P_far(2) - O(2))^2));
       t2 = 2*d_max/Vg_min;  % Mimimum time for traces 2 avoid convolution problems [s].
    fprintf(' Vg_min = %.1f m/s  \n',Vg_min);
    fprintf('      c = %.2f m/s \n',c);

    if t_max < t2
        disp('(o_o) Warning: possible "t_max" parameter overflow...')
        fprintf('      Suggestion: Increase t_max to = %f [s] \n', t2);
        disp(' Program paused... Press any key if you like 2 continue.')
        pause
    else
        fprintf('  t_lim = %.1f < %.1f = t_max [us]  Ok :)\n',t2*10^6,t_max*10^6);
    end
else
    fprintf('      c = %.2f m/s \n\n',c);
    t2 = t_max;
end


% % ver 2.3    11/12/2009     Check of trace longitudes 't_max' parameter added.
% 
%     %-----------------------------------------    
%     % Check if trace longitude 't_max' is enough for max. plate distance
%      ii = find(f0==f);
%     cg0 = Cg{1}(ii);





      
      