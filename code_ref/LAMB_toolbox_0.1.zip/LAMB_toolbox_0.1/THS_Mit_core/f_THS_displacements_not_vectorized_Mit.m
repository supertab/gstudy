function [U] = f_THS_displacements_not_vectorized_Mit(N,Nf,d,mode_type,P,a,r,z,t,w0,k0,alfa,beta,Mu)
% Mit model
%
% This funtion computes the out-plane displacements for simmetric and anti-simmetric 
% straiht crested Lamb waves for a free layer; based on the work:
% "The influence of Finite-Sice Sources in Acousto-Ultrasonics"�
% from:  B.N.Pavlakovic & Joseph L. Rose (NASA report. 1994).
% The main difference with its predecessor 'f_THS_displacements' is the use
% of 'inline' coding in the core calculations.
%
% Obs.:
%             N = Number of points in time signal.
%          Nf-1 = Number of frequency points to simulate in mode 'm'. 
%             t = Time domain vector for signal [s].
%            w0 = Mode frequency vetor [rad/s].
%             P = Acoustic pressure frequency spectrum matrix (modulus,phase);
%                 applied in circular region [Pa].                 
%             a = Radius of circular region [m]
%             r = Radial distance from origin to calculation point.
%             d = plate thickness [m].
%            k0 = wavenumber [Rad/m].
%          k_tl = Longitudinal wavenumber [Rad/m].
%          k_ts = Tranverse wavenumber [Rad/m].
%             U = 'N-Point' displacement matrix:  [u_r0  u_z0
%                                                  u_r1  u_z1
%                                                     ... 
%                                                  u_rN  u_zN]
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    01/06/2008       Use non vectorized coding to avoid out of memory problems.
% ver 2.0    23/08/2008       Change in core calculations to Mit aproach...
% ver 3.0    23/09/2009       Change in delta's cals. at "constant frequency"...!!!


k_alfa = sqrt( (k0.^2) - ((w0/alfa).^2) );        % Longitudinal Lamb wavenumber vector [Rad/m].
k_beta = sqrt( (k0.^2) - ((w0/beta).^2) );        % Transversal Lamb wavenumber vector [Rad/m]. 
%--------------------------------------------------------------------------
%                    besselj(nu,Z)
  F0 = (a.*P(:,1).*besselj(1,k0*a))./k0;          % 'Hankel trasform*k0' of 'Piston-like' radial axisymmetric normal traction distribution.
% F2 = (2.*P(:,1).*besselj(2,k0*a))./(k0.^2);     % 'Hankel trasform*k0' of 'Parabolic' radial axisymmetric normal traction distribution.  
%--------------------------------------------------------------------------
% Bessel funtion of order '0'.
%      besselj(nu,Z)
  J0 = besselj(0,k0*r);          
                 
 u_z = zeros(Nf,1);
   u = zeros(1,N);
   U = zeros(1,N);
switch mode_type
    case 0   
    %----------------------------------------------------------------------
    % "Symmetric" MIT mode displacements
%    [d_delta_s] = f_THS_delta_s_Vik_Mit(k0,w0,d/2,alfa,beta);
    [d_delta_s] = f_THS_delta_s_analitic_Mit(k0,d/2,k_alfa,k_beta);                  
        [H_s_z] = f_THS_H_s_z_Mit(d/2,z,k0,k_alfa,k_beta,Mu);
        
            u_z = abs( (H_s_z./d_delta_s).*F0 );      % Obs: the original Eq. was:  
                                                      % u_z = abs( (H_a_z./d_delta_a).*F0.*k0.*J0 );
                                                      % We have eliminated the term:      'k0.*J0'
                                                      % because they produce oscillations and 
                                                      % signal replicas on traces & the spectrum.
            
    case 1
    %----------------------------------------------------------------------
    % "Anti-simmetric" MIT mode displacements
%    [d_delta_a] = f_THS_delta_a_Vik_Mit(k0,w0,d/2,alfa,beta);
    [d_delta_a] = f_THS_delta_a_analitic_Mit(k0,d/2,k_alfa,k_beta);
        [H_a_z] = f_THS_H_a_z_Mit(d/2,z,k0,k_alfa,k_beta,Mu);
        
            u_z = abs( (H_a_z./d_delta_a).*F0 );      % Obs: the original Eq. was:  
                                                      % u_z = abs( (H_a_z./d_delta_a).*F0.*k0.*J0 );
                                                      % We have eliminated the term:      'k0.*J0'
                                                      % because they produce oscillations and 
                                                      % signal replicas on traces & the spectrum.
    
    otherwise
    disp('Mode type error! "0" and "1" only allowed...')
    error(' :(  ')
end % End switch.


%--------------------------------------------------------------------------
% Calc. of out-of-plane displacements using non vectorized 
% code to avoid out of memory problems.
for n = 1:Nf
    phase = k0(n)*r - w0(n).*t - P(n,2); % Calculate the phase part.
        u = u_z(n)*exp(i*phase);         % Comp. Out-of-plane displacement signal.
        U = U + u;                       % Add z_displacement signal for frequency point {w0(n);k0(n)}.
end
%--------------------------------------------------------------------------
% We use only (N/2) possitive frequencies in 'ifft'algorithm
% of 'N' possible freqs; from which only 'Nf' are not '0'.
U = real((1/(N/2))*U)';  % Return final vector w/out_of_plane displacement [m].

