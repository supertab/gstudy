function [S] = f_extract_spectrum(num_p,f_max,fs,f,Ps)
% This funtion calculates the spectrum (amplitude & phase) for 
% each of 'num_p' signals in the excitation matrix 'Ps'. 
% Parameters:
%           num_p = Total number of points in field matrix 'Ps'.
%          f_max  = Superior limit of frequency bandwith [Hz].         
%              fs = Sampling frequency [Hz].
%               f = Common mode's frequency vector [Hz].
%              Ps = Linear (1D) acoustic pressure signal's excitation matrix.
%                   (Signal are by columns).
% Output:
%               S = Spectrum cell array of 'num_p' sub-matrixes: [amplitude phase];
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    29/11/2007
% ver 1.1    03/12/2007    Coordinates 'X' for 1D escitation profile added!
% ver 2.0    07/02/2008    Returned variable 'X' eliminated.
% ver 3.0    11/02/2008    Simplified version.
% ver 3.1    06/04/2008    Maximum frequency limit checking added.

     S = cell(num_p,1); % Final excitation spectrum cell array.
n_freq = max(size(f));  % We assume that the frequency vector is the same for All Lamb modes.
%--------------------------------------------------------------------------
% Begin spectrum extraction and interpolation.
%warning('Assuming Global frequency vector for All Lamb modes...')

if f_max > fs/2
    fs2 = fs/2
    f_max
    error(' :(    Maximum frequency parameter should be:    "f_max <= fs/2" ')
else
       S2 = zeros(n_freq,2);
    for j = 1:num_p
        [S1,f1] = f_cal_spectra(fs,Ps(:,j));      % Compute spectrum for excitation point 'j'.
         
        S2(:,1) = interp1(f1,S1(:,1),f,'spline'); % Interpolate Amplitude spectrum.
        S2(:,2) = interp1(f1,S1(:,2),f,'spline'); % Interpolate Phase spectrum.
           S{j} = S2;                             % Save interpolated spectrum.
    end
end







