function [S_z] = f_THS_compute(f_cph_mapping,mode_type,num_p,d,a,N,Nf,Ncph,Nx,Ny,X_field,Y_field,z_field,X,Y,S,t,W0,K0,c_ph,alfa,beta,Mu,f_quiet)
% This function calculates the total THS Lamb wave signals for the complete reception field 
% from a given acoustic field excitation region.
%
% Parameters:
%         mode_type = Lamb mode type:  
%                     0 -> Simmetric.   
%                     1 -> Anti-simmetric.
%             num_p = Total number of points in excitation grid.
%                 N = Longitude of time domain signal (N� samples).
%                Nf = Number of frequencies to compute of Lamb wave time signals.
%                 d = Width of material layer e.g.: Aluminium @0.001 [m].
%                 a = Radius of finite circular region [m].
% [X_field Y_field] = Coodinates of reception field points [m].
%           z_field = 'Z' coordinate component for reception field. We use a single scalar
%                     since it's indentical to the surface of plate for all points.
%             [X Y] = Coodinates of excitation field 'point' [m].
%                 S = Cell array with spectrum of excitation signals [Modulus Phase].
%                 t = Time trace vector [s]
%           [W0 K0] = Dispersion curve vectors of actual Lamb mode to compute.
%       [alfa beta] = Longitudinal and transversal bulk wave speeds in plate. 
%                Mu = Lame constant of matrial plate.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    12/01/2008
% ver 1.1    15/01/2008     Change in parameter name:  'i1' -> 'num_p_s'.
% ver 1.2    07/02/2008     Change in parameter name:  'N0' -> 'Nf'.
% ver 2.0    11/02/2008     Excitation field scan through 'num_p'.
% ver 3.0    18/02/2008     Scan through total reception field added.
% ver 3.1    22/04/2008     Direct return of:  'real(u)'  added.
% ver 4.0    12/05/2008     Change in name:  'f_compute_THS' -> 'f_THS_compute'.
% ver 5.0    28/05/2008     1st use of inline coding: 'f_THS_displacements_inline'.
% ver 5.1    30/12/2008     %counter added + order of input parameters + clean of other core functions.
% ver 5.2    08/01/2009     Change on reception field dimensions: [Nx Ny]=size(X_field) --> S_z = zeros(Nx,Ny,N)


   pjc = 0;   
p_done = 0; 
 total = Nx*Ny*num_p;     % Total number of 'points' to complete the job.

u = zeros(N,1);    
if f_cph_mapping
    %--------------------------------------------------------------------------------------------------------------
    % Begin calculations for 3D mapping!
    %--------------------------------------------------------------------------------------------------------------
    % Calculate distance from excitation field to single reception point [m].
        R = sqrt((X - X_field).^2 + (Y - Y_field).^2);  
        f = W0/(2*pi);
      Nf2 = 1;                          % Dummy parameter: compute freq. by freq. (not vectorized).
      S_z = zeros(Ncph,Nf);             % Max. amplitude matrix for 3D vertical displacements mapp.      
    for j = 1:Nf                        % Begin sweep in frequecy.
            if ~f_quiet 
                fprintf('%.1f \n',f(j))
            end
           K0 = W0(j)./c_ph;            % Calculate corresponding wavenumber at constant frequency!
        for i = 1:Ncph                  % Compute 1st. 'Ncph' phase speeds.
            %----------------------------------------------------------
            % THS model
            u = f_THS_displacements_not_vectorized_2(N,Nf2,d,mode_type,S{1},a,R,z_field,t,W0(j),K0(i),alfa,beta,Mu);            
            %----------------------------------------------------------
            % Mit model
%            u = f_THS_displacements_not_vectorized_Mit(N,Nf2,d,mode_type,S{1},a,R,z_field,t,W0(j),K0(i),alfa,beta,Mu);
            %----------------------------------------------------------
            % Achenbach model
%             u = f_THS_displacements_not_vectorized_Ach(N,Nf2,d,mode_type,S{1},a,R,z_field,t,W0(j),K0(i),alfa,beta,Mu);
            
     S_z(i,j) = max(u);
        end
    end    
else
    %--------------------------------------------------------------------------------------------------------------
    % Start calculations for reception field.
    %--------------------------------------------------------------------------------------------------------------
      S_z = zeros(Nx,Ny,N);
    for i = 1:Nx
        for j = 1:Ny
            pjc = pjc + 1;   fprintf(' %02i',p_done); % Start percentage job counter.
            % [X_field(i,j) Y_field(i,j)] % Actual reception field point.
            R = sqrt((X - X_field(i,j)).^2 + (Y - Y_field(i,j)).^2);  % Distances from excit. field to single reception point [m].
            %------------------------------------------------------------------
            % Compute Total THS for single reception point:   All --> 1 phylosophy.
              s_z = zeros(N,1);% Clear accumulator.
            for n = 1:num_p
                % Start calculations for single 'point(n)' in excit. field matrix 'Ps'.
                %----------------------------------------------------------
                % THS model
                  u = f_THS_displacements_not_vectorized_2(N,Nf,d,mode_type,S{n},a,R(n),z_field,t,W0,K0,alfa,beta,Mu);
                %----------------------------------------------------------
                % Mit model
%                  u = f_THS_displacements_not_vectorized_Mit(N,Nf,d,mode_type,S{n},a,R(n),z_field,t,W0,K0,alfa,beta,Mu);
                %----------------------------------------------------------
                % Achenbach model
%                  u = f_THS_displacements_not_vectorized_Ach(N,Nf,d,mode_type,S{n},a,R(n),z_field,t,W0,K0,alfa,beta,Mu);
                
                  
                s_z = s_z + u; % Add cumulative vertical component.
            end            
            S_z(i,j,:) = s_z;  % Save computed Lamb wave signal!
                p_done = round((pjc*num_p*100)/total);  fprintf('\b\b\b'); % Cal.job done.
            %------------------------------------------------------------------
        end
    end
    %--------------------------------------------------------------------------------------------------------------
end



%--------------------------------------------------------------------------
% At this moment (30/12/2008) this THS core instructions has been discontinued because it is not as fast a being spected...
%  K00 = repmat(K0,[1 N]);     % Replicate vector 'K0' through colums in matrix 'K00'.
%    u = f_THS_displacements_inline_2(N,Nf,d,mode_type,S{n},a,R(n),z_field,t,W0,K0,alfa,beta,Mu,K00);


