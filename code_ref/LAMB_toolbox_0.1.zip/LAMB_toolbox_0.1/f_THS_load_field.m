function [x,X,Y,Ps,theta,num_p,num_p_s,a] = f_THS_load_field(s_path,s_file,s_delay,O,N,fs,a,t,f_handle)
% This function loads acoustic data from a file 'Ps_signals' matrix and 
% coordinates (X,Y); for simulations with the Time Harmonic solution Method (THSM).
% Parameters:
%       s_delay = Initial delay for loaded excitation fields [s].
%        s_File = Path + filename for loaded excitation fields.
%             O = Central point of excitation field [m].
%             N = Number of points of signal traces.
%            fs = Sampling frequency [Hz].
%             a = Radius of excitation 'points' [m].
%             t = Signal's temporal axis [s].
%----------------------------------------------------------
% Structure of loaded field:
%       fs_data = Loaded data sampling frequency [Hz].
%             x = data.x  Principal X-axis for Y-strips [mm].
%         num_p = Total number of points in X-Y grid.
%            Ps = Ps(N,Num_p)
%             X = X(Num_pts,1)
%             Y = Y(Num_pts,1)
% Obs:  
%     There is no 'Z' coordinates becouse they are assumed to be on the plate's surface.
%----------------------------------------------------------
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    05/02/2008   
% ver 1.1    17/02/2008    'Ps_theta' retunrning variable added.
% ver 1.2    03/01/2009     External figure handle added.
% ver 1.3    07/03/2009     Change in name: 'f_load_field' --> 'f_THS_load_field' + code re-organiz.(dowsampling go 1st).
% ver 2.0    27/11/2009     Adaptation for LAMB program ver 0.1


%--------------------------------------------------------------------------
% Load simulated data
if isempty(s_path) || isempty(s_file)
    [s_file,s_path] = uigetfile('*.mat','Matlab data file:');
end
File = [s_path s_file];
fprintf('\n Loading excitation field into memory...\n')
fprintf('%s \n',s_path)
fprintf('   %s \n',s_file)


          data = load(File);     % data = dlmread(File);   % Por que no usar 'dlmread' ?
   
       fs_data = data.fs;        % Data sampling frequency [Hz].
             x = data.x;         % Principal axis for y-strip line location [mm].
             X = data.X;
             Y = (-1)*data.Y;    % Minus is because coord. system for TC (O') is rotated 180� through X axis from 'O' in Lamb wave 'THS' coord. system. 
       Ps_data = data.Ps;        % Column signal matrix [Pa].
         theta = data.ang_beta;  % Incidence angle of the field (rotation through Y-axis) in [Deg�].
       num_p_s = data.num_p_s;   % Number of 'points' p/Y-strip line.
[N_data num_p] = size(Ps_data);  % 'num_p' -> Total number of points in X-Y grid.
if ~isempty(data.a)
    if a ~= data.a   fprintf('(o_o) Warning: redefining parameter "a" %.2f -> %.2f mm \n',a*1000,data.a*1000);  
        a = data.a;
    else             fprintf(' Using loaded parameter: a = %.2f mm \n',a*1000);  end;
else 
    fprintf(' Using defined radius: a = %.2f mm \n',a*1000); 
end;
        t_data = (0:1/fs_data:(N_data-1)/fs_data)';  % Data temporal axis [s].
    t_min_data = min(t_data);
    t_max_data = max(t_data);
    fprintf(' t.data: [%.1f %.1f] us \n',t_min_data*10^6,t_max_data*10^6); 
%--------------------------------------------------------------------------
% Conversion from [mm] -> [m] and trastation to new origin 'O'.  
disp(' (o_o) Warning: conversion [mm] -> [m] disabled...');
Z = O(3)*ones(num_p,1);  % Excitation 'points' are located on surface of the plate.
% f_convert = f_input(' Apply conversion [mm] -> [m] ? (y/n)',0,1);
% if (f_convert == 'y') || (f_convert == 'Y')
%     % Apply conversion [mm] -> [m].
%     x = O(1) + x*10^-3; 
%     X = O(1) + X*10^-3; 
%     Y = O(2) + Y*10^-3;
%     Z = O(3)*ones(num_p,1);  % Excitation 'points' are located on surface of the plate.
% else
%     % Do not, dims. already in [m].
%     x = O(1); 
%     X = O(1) + X; 
%     Y = O(2) + Y;
%     Z = O(3)*ones(num_p,1);  % Excitation 'points' are located on surface of the plate.
% end
%--------------------------------------------------------------------------
% Interpolate signals (downsampling).
   t2 = (t_min_data:1/fs:t_max_data)';
  Ps3 = zeros(length(t2),num_p);
fprintf('Interpolating input data: %.2f --> %.2f MHz \n',fs_data/10^6,fs/10^6);
for j = 1:num_p
    Ps3(:,j) = interp1(t_data,Ps_data(:,j),t2,'cubic');
end      
[N3,nump] = size(Ps3);
delete Ps2;  delete t2;

%--------------------------------------------------------------------------
% Correct trace longitudes.
Ps = zeros(N,num_p);
if max(t) > t_max_data
    % Correct signal's longitud by adding '0'.
    Ps(1:N3,:) = Ps3(:,:);
    fprintf(' Padding input signals with  %i "0"...\n',N-N3);
elseif t_max < t_max_data
    fprintf(' (o_o) Warning: loosing %i (%.1fus) samples from input data \n',N3-N,(N3-N)*fs/10^6);
    Ps(:,:) = Ps3(1:N,:);
end
delete Ps3;

%--------------------------------------------------------------------------
% If selected... add fix delay 2 signal to avoid filtering problems.
if s_delay
    fprintf('Adding fix delay of %.2f us  to input signals...\n',s_delay*10^6);  
    for j = 1:num_p
        Ps(:,j) = f_delay_signal(fs,N,s_delay,Ps(:,j),1);
    end          
end    
%--------------------------------------------------------------------------
% Cut initial null samples
figure(993); plot(t,Ps); grid; 
td = f_input('Minimum delay time "td[s]" to cut? ',0,0);
if (td > 0) && (td < max(t))    
    Ps4 = zeros(N,num_p);
    Nc = round(td*fs);
    fprintf('Cutting:  %d  1st. samples from loaded signals...',Nc)    
    Ps4(1:N-Nc+1,:) = Ps(Nc:N,:);
    delete Ps;
    Ps = Ps4;
end
delete(figure(993));

%--------------------------------------------------------------------------
% Normalize amplitudes.
Ps_max = max(max(Ps));
theta
if Ps_max > 1
    fprintf(' (o_o) Normalizing amplitudes @P_max = %.1f Pa...',Ps_max);
    Ps = Ps/Ps_max;
end
%--------------------------------------------------------------------------
% Plotting.
figure(f_handle);
plot3(O(1),O(2),0,'r+');  plot3(O(1),O(2),0,'ko'); % Plot origin in center of the plate.
plot3(X,Y,Z,'b.');      % Plot excitation 'points'.
for i = 1:num_p
    [xc,yc] = f_cal_circle([X(i) Y(i)],a,10);  % Plot circle excit. boundarys.
         zc = O(3)*ones(max(size(xc),1));
         if i == 1  plot3(xc,yc,zc,'r');  plot3(X(i),Y(i),Z(i),'r+');
         else       plot3(xc,yc,zc,'g');  end;
end


figure(9999); grid on; 
plot(t,Ps);
pause;  delete(figure(9999))
