function [Signal_max] = f_cal_s_max(theta,Signal,x,y,f_handle,axis_font)
% Extract maximum feature from a given "column" matrix of signals:  'Signal'.
% Obs.:
%             h ~ 0 -> Plot feature labels.
%             h = 0 -> Do not plot.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    05/02/2009


%disp('x.0 Calculating maximum pick data...');

[xs ys N] = size(Signal);
if N > 1
    %----------------------------------------------------------------------
    % Deteccion de maximos en matrices 3D.
    Signal_max = zeros(xs,ys);
    for i = 1:xs
        for j = 1:ys
            Signal_max(i,j) = max(Signal(i,j,:));
        end
    end
    if f_handle
        text(x,y,max(max(Signal_max)),['Max. pick @',num2str(theta),'�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',axis_font);
    end
else
    %----------------------------------------------------------------------
    % Detection for 2D matrix.
     [N,nro_s] = size(Signal);
    Signal_max = zeros(nro_s,1);
    for j = 1:nro_s
        Signal_max(j,1) = max(Signal(:,j));
    end
    if f_handle
        [y,jj] = max(Signal_max);
        text(x,y,[num2str(theta),'�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',axis_font);
    end
end




