function [minutes,seconds,N_ele,Npts3] = f_IRM_estimate_time(T_amb,Hr,P,P_field_2,Nx2,Ny2,Nt,n_a3,n_b3,a_3,b_3,Nxc3,Nyc3,Nx3,Ny3,N3,Nf3,fs_IRM,f_s3,f3,t3,P_field_3,theta,f_pause)
% Estimate time taken by IRM calculations.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    21/12/2008
% ver 1.1    12/01/2009     Use of core routine: 'f_IRMc_IR_RB_point_fast'  v6.4 @12/01/2009
% ver 1.2    17/02/2009     Inter program 'f_pause' flag added.


% Calculate density, speed & attenuation of sound in air [dB/m].
[c,atte_air_dB,ro] = f_cal_air_properties(T_amb,Hr,P,f3); 
%----------------------------------------------------------------------
% Estimate total time for 'Nt' angle calculations in Ps reception field
n_trials = 10;
   t_max = max(t3);
      et = zeros(n_trials,1); 
       a = 0.0005;
       b = 0.0075;
  P_test = P_field_3 - P_field_2;
   f_min = min(f3);
   f_max = max(f3);
   i_min = round((f_min/f_s3)+1); % Index of 1st. non null filter value.
       A = zeros(N3,1);
      ps = zeros(N3,1);
              
  s_a = f_gen_signal(N3,10,2,1,0.83*10^6,fs_IRM,0,t3); % Generate arbitrary signal for time test.
for j = 1:n_trials
     tic  % t0 = cputime;
     [zone,distance] = f_cal_zone(P_test(1),P_test(2),P_test(3),a,b);    % Distance to point P0 in [m].
     %------------------------------------------------
     % Construct attenuation filter.
     atte = 10.^(distance.*atte_air_dB./20);                % Calculate atte. corresponding 2 distance [ratio].
              A(i_min:Nf3+i_min-1,1) = atte(1:Nf3,1);       % Main part (0:f_s3:fs2/2).
     A(N3-i_min-Nf3+3 :N3-i_min+2,1) = atte(Nf3:-1:1,1);    % Complementary frequencies (fs2/2:f_s3:fs).
     %------------------------------------------------
        h = zeros(N3,1);                                    % Reserve memory for impulse response vector.
      [h] = f_IRMc_IR_RB_point_fast (P_test,a,b,c,t3,h,N3,zone,t_max); % Calculate impulse response 'h(P,t)'.
       ps = (ro/fs_IRM)*f_conv_met2(N3,h,s_a,A);            % Mul. by air-density [kg/m3].
     %------------------------------------------------
    et(j) = toc;  % = cputime - t0;
end
%----------------------------------------------------------------------------------------------
% Estimated calculation mean time for local computer; by  'point-point-sample-frequency' in [s].
            N_ele = Nx2*Ny2;  % Number of emission elements.
            Npts3 = Nx3*Ny3;  % Number of reception field points.
           factor = 1; %1.15;
             t_pp = mean(et);
           e_time = factor*(t_pp*Nt*Npts3*N_ele);             % Global estimated calculation duration time [s].
[minutes,seconds] = f_convert_time(e_time);
fprintf('         c = %.2f m/s \n',c);                        % Speed of sound in air [m/s].
fprintf('        Nt = %i  @ [',Nt); for i=1:Nt fprintf(' %.1f',theta(i)); end;  fprintf(']� \n'); % Number of present incidence angles.
fprintf('     N_ele = %i  @ %i x %i \n',N_ele,Nx2,Ny2);       % Plot number of 'plate' emission elements.
    disp(' Reception element parameters: ');
fprintf('   N_r_ele = %i = %i x %i @(%ix%i) \n',Nxc3*Nyc3,Nxc3,Nyc3,n_a3,n_b3); % Plot number of reception elements & number of sub-elements.
fprintf('r_s-ele_dims: [%.3f %.3f] mm ',1000*2*a_3,1000*2*b_3);% Plot sub-element dimensions [mm].
if a_3 == b_3  fprintf(' :) \n');
else           fprintf(' :( \n');  end;
fprintf('     Npts3 = %i  \n',Npts3);                         % Plot total number of signals in reception field.
fprintf('   N_total = %i @ %i x %i \n',N_ele*Npts3,N_ele,Npts3);                   % Plot total number of signals to compute!.
fprintf('      t_pp = %.4f   et = %i:%.1f \n',t_pp,minutes,seconds);

if f_pause
    disp('Program paused. Press any key to continue...')
    pause; 
end
fprintf('\n\n');

%1;

