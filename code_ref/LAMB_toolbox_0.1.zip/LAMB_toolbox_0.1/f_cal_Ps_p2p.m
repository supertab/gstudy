function [Ps_p2p] = f_cal_Ps_p2p(theta,Ps,x,y,axis_font)
% Extract pick-to-pick feature from a given acoustic field data set 'Ps'.
% Obs.:
%            Ps = IRM data cell array:  Ps = zeros(Nx3,Ny3,N3);
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    20/12/2008


disp('1. Calculating pick-2-pick values...');

[xs ys N] = size(Ps);
if N > 1
    %----------------------------------------------------------------------
    % Detection in 3D matrix.
    Ps_max = zeros(xs,ys);
    Ps_min = zeros(xs,ys);
    for i = 1:xs
        for j = 1:ys
            Ps_max(i,j) = max(Ps(i,j,:));
            Ps_min(i,j) = min(Ps(i,j,:));
        end
    end
    Ps_p2p = Ps_max + abs(Ps_min);
    if (x(1) ~= 0) && (y(1) ~= 0)
        text(x,y,max(max(Ps_p2p)),['Pick-2-pick [Pa] @',num2str(theta),'�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',axis_font);
    end
else
    %----------------------------------------------------------------------
    % Detection in 2D matrix.
    [nro_s,N] = size(Ps);
       Ps_max = zeros(nro_s,1);
       Ps_min = zeros(nro_s,1);
    for i = 1:nro_s
        Ps_max(i,1) = max(Ps(i,:));
        Ps_min(i,1) = min(Ps(i,:));
    end
    Ps_p2p = Ps_max + abs(Ps_min);
    if (x(1) ~= 0)
        [y,ii] = max(Ps_p2p);
        text(x(ii),y,[num2str(theta),'�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',axis_font);
    end
end




