function [X3,Y3,Z3] = f_rotate_matrix(U,V,W,ang_alfa,ang_beta,ang_gamma)
% This function rotates a given set of matrix coodinate points (U,V,W),
% by performing rotation tranformations around an auxiliary coordinate
% system (X,Y,Z) located in the reference point [U(i,j) V(i,j) W(i,j)]
% and following the ordering sequence:  
%                                 ang_alfa --> ang_beta ang --> gamma.
%
% Obs.: 
%                  ang_alfa  = Angle of rotation respect X-axis [Deg].
%                  ang_beta  = Angle of rotation respect Y-axis [Deg].
%                  ang_gama  = Angle of rotation respect Z-axis [Deg].             
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    16/11/2005
% ver 2.0    26/11/2008   Rotation sequence added!  1) ang_alfa --> 2) ang_beta --> 3) ang_gamma

%--------------------------------------------------------------------------
% Conversion de los angulos de giro a radianes.
 ang_alfa_r = ang_alfa*pi/180;  
 ang_beta_r = ang_beta*pi/180;  
ang_gamma_r = ang_gamma*pi/180;  

%------------------------------------------------------------------------------------------------------
% Definicion de la matrices de transfomacion x giro en torno al eje. X'' (recorrido x: 1�filas -> 2�columnas)
     Alfa = zeros(3,3);
Alfa(1,1) =  1;
Alfa(2,2) =  cos(ang_alfa_r);
Alfa(2,3) = -sin(ang_alfa_r);
Alfa(3,2) =  sin(ang_alfa_r);
Alfa(3,3) =  cos(ang_alfa_r);
%------------------------------------------------------------------------------------------------------
% Definicion de la matriz de transfomacion x giro en torno al eje. Y'' (recorrido x: 1�filas -> 2�columnas)
      Beta = zeros(3,3);
Beta(1,1) =  cos(ang_beta_r);
Beta(1,3) =  sin(ang_beta_r);
Beta(2,2) =  1;
Beta(3,1) = -sin(ang_beta_r);
Beta(3,3) =  cos(ang_beta_r);
%------------------------------------------------------------------------------------------------------
% Definicion de la matriz de transfomacion x giro en torno al eje. Z'' (recorrido x: 1�filas -> 2�columnas)
      Gama = zeros(3,3);
Gamma(1,1) =  cos(ang_gamma_r);
Gamma(1,2) = -sin(ang_gamma_r);
Gamma(2,1) =  sin(ang_gamma_r);
Gamma(2,2) =  cos(ang_gamma_r);
Gamma(3,3) =  1;


%------------------------------------------------------------------------------------------------------
% 1) Rotate coords. 1st following ang_alfa!
X1 = U*Alfa(1,1) + V*Alfa(1,2) + W*Alfa(1,3);
Y1 = U*Alfa(2,1) + V*Alfa(2,2) + W*Alfa(2,3);
Z1 = U*Alfa(3,1) + V*Alfa(3,2) + W*Alfa(3,3);

% 2) The rotate coords. 2nd. following ang_beta!!
X2 = X1*Beta(1,1) + Y1*Beta(1,2) + Z1*Beta(1,3);
Y2 = X1*Beta(2,1) + Y1*Beta(2,2) + Z1*Beta(2,3);
Z2 = X1*Beta(3,1) + Y1*Beta(3,2) + Z1*Beta(3,3);

% 3) Finally rotate coords. following ang_gamma!!!
X3 = X2*Gamma(1,1) + Y2*Gamma(1,2) + Z2*Gamma(1,3);
Y3 = X2*Gamma(2,1) + Y2*Gamma(2,2) + Z2*Gamma(2,3);
Z3 = X2*Gamma(3,1) + Y2*Gamma(3,2) + Z2*Gamma(3,3);





% %------------------------------------------------------------------------------------------------------
% Old code... discontinued because it did not respect completely the
% sequence of rotation: alfa -> beta -> gamma (26/12/2008)
%
% % Matriz generalizada de transfomacion
% T = Alfa*Beta*Gama;   % es lo mismo que:  (Alfa*Beta)*Gama
% 
% %------------------------------------------------------------------------------------------------------
% % Transformacion de de las coordenas, por rotaciones.
% X = U*T(1,1) + V*T(1,2) + W*T(1,3);
% Y = U*T(2,1) + V*T(2,2) + W*T(2,3);
% Z = U*T(3,1) + V*T(3,2) + W*T(3,3);













