function [S,F] = f_cal_spectra(fs,s)
% This funtion returns the spectrum of a given signal 's'.  
% Obs.: if 's' is a 2D matrix -> 'fs' must be a 2-element vector 
%       with temporal and spatial sampling frequencies.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0     2/12/2004
% ver 2.0    15/07/2005 
% ver 3.0    03/04/2006     2D-FFT added.
% ver 3.1    16/09/2007     English version + phase spectrum correction by 'unwrap'.
% ver 3.2    23/10/2007     Matrix frequencies fixed!.
% ver 3.3    29/11/2007     Amplitude spectrum corrected.

%figure(555); shading interp; set(gcf, 'Renderer', 'zbuffer');
%figure(556); shading interp; set(gcf, 'Renderer', 'zbuffer');
%--------------------------------------------------------------------------
if min(size(s)) == 1
    [N1,N2] = size(s);
   if N1 <= N2
      N1 = N2; 
       s = s';                           % We will use signals by rows only.
   end
   if f_impar(N1,2)
        n1 = floor(N1/2)+1;
   else
        n1 = floor(N1/2);
   end
         F = zeros(n1,1);
         S = zeros(n1,2);

        R2 = fft(s);                    % Cal. 1D De-normalized FFT.
         R = R2(1:n1,1);                % Exctract frequencies < fs/2.
    S(:,1) = abs(R);                    % Compute Amplitude spectrum.
    S(:,2) = unwrap(angle(R));          % Compute Phase spectrum [Rad].     
         F = (0:n1-1)'*(fs/N1);         % Generate frequency vector.
          
% %------------------------------------------          
% % This block perform's a hand maded 'ifft'!
% N = max(size(s))
% S = fft(s);
% A = abs(S);
% P = unwrap(angle(S));
% f = (0:N-1)'*(fs/N);
% t = (0:N-1)/fs;          
% E = zeros(N/2,N);
% %    figure(9); %hold; grid;
% for n = 1:N/2  % <- We only use possitive freq. only.
%     E(n,:) = A(n).*exp(i*(2*pi*f(n).*t + P(n)));
% %     plot(t,real(E(n,:)))
% %     drawnow
% end
% s2 = (1/(N/2))*real(sum(E,1))';   
% N;
% %------------------------------------------          
% % Parseval theorem check
%     E = sum((abs(s)).^2);                  % Energy of time signal.
%    E2 = (1/(N1/2))*sum((abs(S(:,1))).^2);  % Energy of frequency components.
% E_ratio = E2/E  
% %------------------------            
%   figure(555); hold; grid; plot(F{1},S{1}); plot(F{1},S{1},'g.');
%   figure(556); hold; grid; plot(F{1},S{2}); plot(F{1},S{2},'r.');
%--------------------------------------------------------------------------
else
          F = cell(2,1);
          S = cell(2,1);
    [N1,N2] = size(s);
    fprintf(' N1 = %i;  N2 = %i \n\n',N1,N2);
    if f_impar(N1,2)
         n1 = floor(N1/2)+1;
    else
         n1 = floor(N1/2);
    end
    if f_impar(N2,2)
         n2 = floor(N2/2)+1;
    else
         n2 = floor(N2/2)+1;
    end
    
%         R2 = (2/sqrt(N1*N2))*fft2(s);       % Cal. 2D normalized FFT.
         R2 = fft2(s);                   % Cal. 2D De-normalized FFT.
          R = R2(N1:-1:n1,1:n2)';        % Double frequencies extraction.
       S{1} = abs(R);                    % Calculate Amplitude spectrum.
       S{2} = unwrap(angle(R));          % Compute Phase spectrum in [Rad].
        
          f = (0:N1/2)'*(fs(1)/N1);      % Generate frequency vector.
          k = (0:N2/2)'*(2*pi*fs(2)/N2); % Generate wavenumber vector.
[F{1},F{2}] = meshgrid(f,k);             % Compute 'f,k' matrix.   

%   figure(555); surf(F{1},F{2},S{1}); shading interp;
%set(gcf, 'Renderer', 'zbuffer');
%   figure(556); surf(F{1},F{2},S{2}); shading interp;
%set(gcf, 'Renderer', 'zbuffer');
end
