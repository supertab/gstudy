function [N2,t_max2,t2] = f_cal_t_max_time(fs,c,d_min,d_max,t_long,t)
% Funcion de calculo del vector de tiempos 't' de las se�ales.
% Obs.:
%            d_min = Distancia minima entre puntos del campo emisor y receptor.
%            d_max = Idem, distancia maxima.
%
% 
%
% ver 1.0   05/06/2006     Redefinicion del vector de tiempos x elimacion 'tiempo de vuelo'
% ver 2.0   28/01/2008     Elim. de conversion:  t(N) -> t'(2^N) y bandas de protecion 
%                          en 't_min' y 't_max'(0.9,1.1)
% ver 3.0   26/12/2008     Simplificacion x eliminado de conversion a 2^N y cal. de distanacias min & max.
% ver 3.1   27/01/2009     Added warning for N2 too large...


if t_long <= 0  
    t_long = max(t);
    fprintf('t_long = %.1f us \n',t_long*10^6);
end

 t_min = d_min/c;                    % Tiempo de 'vuelo minimo' entre puntos del campo emisor y receptor...
 t_max = t_long + d_max/c;       % Tiempo de 'vuelo maximo' + duracion de la trama.
t_min2 = f_round(t_min,5*10^-6,-1);  % Redondeo de 't_min' a   (n)*5 micro-seg. 
t_max2 = f_round(t_max,5*10^-6,0);   % Redondeo de 't_max' a (n+1)*5 micro-seg. 
  t_d2 = t_max2 - t_min2;
% -------------------------------------------------------------------------
% Calculo longitud trazas de tiempo 'N'
   t2 = (t_min2:1/fs:t_max2)';       % vector de tiempo 't',(Origen de tiempos en '0'seg.)
   N2 = max(size(t2));               % Cantidad de puntos Base de las traza de tiempo
   
if (N2 > 10^5) || t_long > 0.001
    fprintf(' (o_o) Warning: number of trace points becaming too large... \n');
    fprintf('       t_long = %.1f us   N2 = %i > 10^5 \n',t_long*10^6,N2);
    disp(' Program paused. Press any key to continue...')
    pause
end

fprintf('Changing t_duration %.1f -> %.1f us @N2=%i \n',t_long*10^6,t_d2*10^6,N2);
fprintf('                N = %i -> N2 = %i \n',max(size(t)),N2);




