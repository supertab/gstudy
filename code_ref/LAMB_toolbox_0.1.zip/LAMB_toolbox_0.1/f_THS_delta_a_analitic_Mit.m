function [d_delta_a] = f_THS_delta_a_analitic_Mit(k0,h,k_alfa,k_beta)
% This funtion calculates the analitic derivatives for Anti-symmetric dispersion modes,
% based on Y.Shi PhD. thesis:  "Analisys of optimum Lamb wave tuning"
%                               Yijun Shi, Mit 2002
%
% Obs.:      w0 = Angular frequency vector [rad/s].
%            k0 = Wavenumber vector [Rad/m].
%             h = d/2 Half plate thickness [m].
%        k_alfa = sqrt( (k0.^2) - ((w0/alfa).^2) );  Longitudinal wavenumber [Rad/m].
%        k_beta = sqrt( (k0.^2) - ((w0/beta).^2) );  Tranverse wavenumber [Rad/m].
%          alfa = Longitudinal bulk wave velocity [m/s].
%          beta = Transversal bulk wave velocity [m/s].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    24/09/2009

%--------------------------------------------------------------------------
% Analitic derivative for Anti-symmetric modes:

d_delta_a = (  (8.*k0.*((k0.^2)+(k_beta.^2)).*sinh(k_alfa*h).*cosh(k_beta*h))...
             - (8.*k0.*k_alfa.*k_beta.*cosh(k_alfa*h).*sinh(k_beta*h))...
             - (4.*h.*(k0.^3).*k_beta.*sinh(k_alfa*h).*sinh(k_beta*h))...
             - (4.*h.*(k0.^3).*k_alfa.*cosh(k_alfa*h).*cosh(k_beta*h))...
             + ((h.*k0.*(((k0.^2)+(k_beta.^2)).^2).*cosh(k_alfa*h).*cosh(k_beta*h))./(k_alfa))...
             + ((h.*k0.*(((k0.^2)+(k_beta.^2)).^2).*sinh(k_alfa*h).*sinh(k_beta*h))./(k_beta))...
             - ((4.*(k0.^3).*k_beta.*cosh(k_alfa*h).*sinh(k_beta*h))./(k_alfa))...
             - ((4.*(k0.^3).*k_alfa.*cosh(k_alfa*h).*sinh(k_beta*h))./(k_beta))...
            );




                                     

         
         
         
         