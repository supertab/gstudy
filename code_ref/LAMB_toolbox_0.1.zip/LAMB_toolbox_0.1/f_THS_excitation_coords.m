function [x,X,Y,Ps,Ps_theta,num_p,num_s,num_p_s,a] = f_THS_excitation_coords(s_path,s_file,s_delay,O,s_type,r_type,a,x_w,y_w,N,fs,t,f_plot_eles,f_handle)
% This function creates the excitation field 'Ps', by loading a simulated field or generating a plane wave (PW).
% Obs.:
%       s_delay = Initial delay for loaded excitation fields [s].
%        s_File = Path + filename for loaded excitation fields.
%             O = Central point of excitation field.
%        s_type = Signal type.
%        r_type = Region type.
%             a = Radius of excitation 'points' [m].
%           x_w = With of region in 'x' direction [m].
%           y_w = With of region in 'y' direction [m].
%             N = Number of time points in signal trace.
%            fs = Sampling frequency [Hz].
%             t = Signal's temporal axis [s].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    14/02/2008
% ver 2.0    03/01/2009     Change in name: 'f_cal_excitation_coords' -> 'f_THS_excitation_coords' & ext fig. handle.
% ver 2.1    19/02/2009     'f_plot_eles' flag added... but not used yet!
% ver 2.2    27/11/2009     Adaptation for LAMB program ver 0.1

figure(f_handle); hold on; grid on;

if s_type == 0    
    [x,X,Y,Ps,Ps_theta,num_p,num_p_s,a] = f_THS_load_field(s_path,s_file,s_delay,O,N,fs,a,t,f_handle);
         num_s = max(size(x));  % Number of y-strip composing excit. field.
         %----------------------------------------------
         % Plotting of field maximum signal's.
         [Pm] = f_cal_Ps_max(Ps_theta,Ps',0,0,12);
         figure(9991); hold; grid; view([25 30]);
         plot3(X,Y,Pm,'b');  plot3(X,Y,Pm,'g.');  plot3(X(1),Y(1),Pm(1),'ro');
         
         delay_type = 2 
         [Pd] = f_cal_Ps_delay(Ps_theta,delay_type,N,fs,Ps',t,9992,0,0,12);
         figure(9992); hold; grid; view([25 30]);
         plot3(X,Y,Pd,'r');  plot3(X,Y,Pd,'b.');  plot3(X(1),Y(1),Pd(1),'go');         
         pause; delete(figure(9991)); delete(figure(9992));
else
    if (x_w < 0) || (y_w < 0)
        x_w
        y_w
        disp('Error in boundary size:  Negative grid parameter values not allow...'); error(' ');
    end
    switch(r_type)
        case 0
            %--------------------------------------------------------------- 
            % Sigle excitation 'point' of radius 'a'.
            disp(' Using single point region.')
            X = O(1);  Y = O(2); 
            x = 0; num_p = 1;   num_p_s = 1;  % Single point in main grid.
            % Plot boundary
            [xb,yb] = f_cal_circle(O,a,37);
                 zb = O(3)*ones(max(size(xb)),1);
            plot3(xb,yb,zb,'b');  plot3(X,Y,O(3),'b+');  plot3(X,Y,0,'r+')
        case 1
            %--------------------------------------------------------------- 
            % Rectangular region.
            [x,X,Y,Z,num_p,num_s,num_p_s] = f_gen_rect_grid(O,x_w,y_w,a,f_handle); 
            % Plot boundary
            boundary = [x_w/2 y_w/2 O(3); -x_w/2 y_w/2 O(3); -x_w/2 -y_w/2 O(3); x_w/2 -y_w/2 O(3); x_w/2 y_w/2 O(3)];
            plot3(boundary(:,1),boundary(:,2),boundary(:,3),'r')
        case 2
            %--------------------------------------------------------------- 
            % Circular/elliptical region.
                                 Rx = x_w/2;
                                 Ry = y_w/2;
            [x,X,Y,Z,num_p,num_p_s] = f_cal_coord_plano_3(O,Rx,Ry,a,f_handle);
        otherwise
            error(' Excitation region not defined:  "f_cal_excit_coords".')
    end
       Ps = 0;            % Signal matrix is null, because it will be generated later.
 Ps_theta = 0;            % This is also for 'Ps_theta' since it is replaced by 'theta' vector.
    num_s = max(size(x)); % Number of y-strips composing excit. field.
        Y = -Y;           % Invert sweep of axis 'Y'. 
                          % Obs.:  The sweep convention for a given grid (whatever type), is from point 
                          %       most positive to point most negative: (+x;+y) -> (-x;-y); through 
                          %       decreasing values of 'x'  -->  1st.'y-axis' then  'x-axis'.
                          
end

fprintf(' num_p = %i     num_s = %i \n',num_p,num_s);


