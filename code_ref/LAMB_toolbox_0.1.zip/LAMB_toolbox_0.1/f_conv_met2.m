function [s_c] = f_conv_met2(N,s1,s2,A)
% Funcion de convolucion alternativa metodo 1 por FFT inversa.
% Mas agreg. filtro de atenuacion.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1      19/12/2008    Old code active.

%---------------------------------------
% Old code active to save time! 
  S1 = fft(s1);
  S2 = fft(s2);
 S_C = S1.*S2.*A;
 s_c = real(ifft(S_C));


 
 
%---------------------------------------
% New code with zero padding... inactive!!
% ya que no habia diferencias...
%
% ver 2.0   22/06/2005  Agregado de Zero-padding p/mejorar exactitud
% S1 = fft([s1; zeros(N-1,1)]);
% S2 = fft([s2; zeros(N-1,1)]);
% 
% S_C = S1.*S2;
% s_c = real(ifft(S_C));
% s_c = s_c(1:N,1);
%---------------------------------------

 




