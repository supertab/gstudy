function [Signal_photo] = f_s_photo(theta,t,n,Signal,x,y,f_handle,axis_font)
% Extract time-instant value (feature photo) from a given column signal's matrix 'Signal'.
% Obs.:
%             h ~ 0 -> Plot feature in y-axis
%             h = 0 -> Plot feature in z-axis
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    05/02/2009


fprintf('x.3 Extracting time instant t = %.1f us from signals...',t(n)*10^6);

[xs ys N] = size(Signal);
if N > 1
    %----------------------------------------------------------------------
    % Detection in 3D matrix.
    Signal_photo = zeros(xs,ys);
    for i = 1:xs
        for j = 1:ys
            Signal_photo(i,j) = Signal(i,j,n); 
        end
    end
    if f_handle
        text(x,y,Signal_photo(1,1),['s(',num2str(10^6*t(n)),'us) @',num2str(theta),'�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',axis_font);
    end
else
    %----------------------------------------------------------------------
    % Detection in 2D matrix.
       Signal = Signal';
    [N,nro_s] = size(Signal);
     Signal_photo = zeros(nro_s,1);
    for j = 1:nro_s
        Signal_photo(j,1) = Signal(n,j); 
    end
    if f_handle
        [y,ii] = max(Signal_photo);
        text(x(ii),y,['s(',num2str(10^6*t(n)),'us) @',num2str(theta),'�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',axis_font);
    end
end




