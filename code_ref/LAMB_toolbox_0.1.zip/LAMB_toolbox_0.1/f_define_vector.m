function [v] = f_define_vector(v_min,v_max,v_s,v_type);
% Define a vector based on user input data.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    01/03/2009


if (v_max < v_min)
    switch v_type
        case 'time'
        case 'frequency'
        case 'angle'
        case 'cph' % Phase-velocity.
        otherwise
    end
else
end
    
    
            f = (f_min:f_s:f_max)';             % Desired frequency operating bandwidth [Hz].    














