function [c_type] = f_assign_color(num_s)
% Assign color to a set of signals 'num_s'.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    25/12/2008
           


color_list = ['b';'g';'r';'m';'c';'y';'k'];
% line_list = ['-';'-';'-';'-';'-';'-';':';':';':';':';':';':'];
     num_c = length(color_list);
    
        n = 1;
       ii = 1;
while n <= num_s    
    c_type(n,:) = color_list(ii,:);
%    l_type(n,:) = line_list(ii,:);
    if ii < num_c
        n = n + 1;
       ii = ii + 1;
    elseif ii == num_c
        n = n + 1;
       ii = 1;                 
    end
end
       
       
       
% %--------------------------------------------------------------------------
% % Old code.
% color_list = [0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0];
% line_list = ['-';'-';'-';'-';'-';'-';':';':';':';':';':';':'];       
% plot(t,m); drawnow;
% h2 = findobj(h);  set(h2(3),'Color',color(j,:),'LineStyle',line(j,:));



