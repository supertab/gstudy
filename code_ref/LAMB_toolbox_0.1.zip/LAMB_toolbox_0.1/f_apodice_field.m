function [Ps] = f_apodice_field(a_type,r_type,num_p,num_s,num_p_s,O,x_w,y_w,X,Y,Ps)
% This function apodizes in amplitude a given field excitation matrix 'Ps'.
% For square type regions, it applies only 1D apodiations through X-axis.
% While for cicular/elliptical regions, 1D X-axis profile is rotated to
% apply a 2D apodization.
% Parameters:
%            a_type = Apodizing amplitude profile type. If  's_type = 0'  they don't apply.
%            r_type = Region type.
%             num_p = Total number of points in field matrix 'Ps'.
%             num_s = Number of strips composing excitation field.
%           num_p_s = Number of 'points' per strip line.
%                 O = Central point of excitation field.
%               x_w = Width of reception field in X axis [m].
%               y_w = Width in Y axis [m].
%             [X,Y] = Coordinates matrix of field.
%                Ps = Pressure signal's matrix [Pa].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   

%--------------------------------------------------------------------------
% Obs. all apodization profile types are normalized (0-1).
%--------------------------------------------------------------------------
switch(a_type)
    case 1 % Gaussian.
     sigma = 5   % Normal standard distribution.
        Ps = f_apo_gauss(sigma,r_type,num_p,num_s,num_p_s,O,x_w,y_w,X,Y,Ps);
    case 2 % Triangular.
     level = 0.1  % Amplitude level (0-1) of base of the triangle.
      [Ps] = f_apo_triang(level,r_type,num_p,num_s,num_p_s,O,x_w,y_w,X,Y,Ps);
    case 3 % User defined vector.
        error('"f_apo_vector"  <- Not yet coded....')
        %Ps = f_apo_vector(r_type,num_p_s,x,Ps);
    otherwise
        error('Unrecongnized amplitude apodizing type: "a_type"')
end











