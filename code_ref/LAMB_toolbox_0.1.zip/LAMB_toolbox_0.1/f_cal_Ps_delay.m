function [Ps_delay] = f_cal_Ps_delay(theta,delay_type,N,fs,Ps,t,h,x,y,axis_font)
% Funcion que extrae los val. de 'delay' de un 'prisma'
% de presiones dado.
%
% ver 1.0     29/03/2006
% ver 2.0     09/02/2008   Deteccion de maximos en matrices 2D.
% ver 2.1     23/12/2008   Agreg. impresion de rotulos.


disp('Computing delay times...');
if h ~= 0
    figure(h);
end

[xs ys N] = size(Ps);
if N > 1
    %----------------------------------------------------------------------
    % Deteccion de maximos en matrices 3D.
      ps = zeros(1,N);
Ps_delay = zeros(xs,ys);
    for i = 1:xs
        for j = 1:ys
               ps(1,:) = Ps(i,j,:);
       [Ps_delay(i,j)] = f_cal_zero_cross_signal(delay_type,N,fs,ps);
        end
    end
    if (x(1) ~= 0) && (y(1) ~= 0)
        text(x,y,min(min(Ps_delay)),['Ps_delay [us] @',num2str(theta),'�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',axis_font);
    end
else
    %----------------------------------------------------------------------
    % Deteccion de maximos en matrices 2D.
   [nro_s,N] = size(Ps);
    Ps_delay = zeros(nro_s,1);
    for i = 1:nro_s
       [Ps_delay(i)] = f_cal_zero_cross_signal(delay_type,N,fs,Ps(i,:));
    end
    if (x(1) ~= 0)
        [y,ii] = min(Ps_delay);
        text(x(ii),10^6*y,[num2str(theta),'�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',axis_font);
    end
end






