function [x,X,Y,Z,num_p,num_s,num_p_s] = f_gen_rect_grid(O,x_w,y_w,a,f_handle)
% This function generates a rectangular grid of 'points' (circular excitation sub-regions)
% that fill the excitation field.
% Parameters:
%            O = Central point of excitation field [m].
%          x_w = With of region in 'x' direction. [m].
%          y_w = With of region in 'y' direction [m].
%            a = Radious of excitation 'points' [m].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    08/01/2008
% ver 1.1    11/12/2008   Agreg. devolucion handle "figure".
% ver 1.2    29/12/2008   Detection of warning: A_boundary = 0.
% ver 1.3    03/01/2009   External figure handle added.
% ver 1.4    29/11/2009   Switch plot capability: on/off if required added.


fprintf(' Rectangular region: \n')
%-----------------------------------------------------------
% Create field excitation grid
x_s = a*sqrt(3);        % Step between points in X-axis [m].
y_s = 2*a;              % Step between points in Y-axis [m].
if (x_w > 0) && (y_w < y_s)
    %-------------------------------------------------------
    % Generate X-line grid.
      x = O(1) + (x_w/2:-x_s:-x_w/2)';
  num_s = max(size(x)); % Number of strip lines in excitation grid.
num_p_s = 1;            % Number of 'points' per strip line.
  num_p = max(size(x)); % Total number of points in X grid.
      X = x;  Y = O(2)*ones(num_s,1);  Z = O(3)*ones(num_s,1);
elseif (x_w < x_s) && (y_w > 0)
    %-------------------------------------------------------
    % Generate Y-line grid.    
      y = O(2) + (y_w/2:-y_s:-y_w/2)';
  num_s = max(size(y)); % Number of strip lines in excitation grid.
num_p_s = num_s;        % Number of 'points' per strip line.
  num_p = max(size(y)); % Total number of points in Y grid.
      X = O(1)*ones(num_s,1);  Y = y;  Z = O(3)*ones(num_s,1);   x = O(1);
else
    %-------------------------------------------------------
    % Generate X-Y grid.
  x_limit = x_w/2;
        x = (x_limit:-x_s:-x_limit)';
        x = x - mean(x);
    num_s = max(size(x));   % Number of strip lines in excitation grid.
  num_p_s = zeros(num_s,1); % Number of 'points' per strip line.
        n = 0;
    for i = 1:num_s
        if f_impar(i,2)
            y_limit = y_w/2;
        else
            y_limit = (y_w/2) - a;
        end
                  y = (y_limit:-y_s:-y_limit)';
         num_p_s(i) = max(size(y));
        for j = 1:num_p_s(i)
            X(n+j,1) = x(i);
            Y(n+j,1) = y(j);
        end
        n = n + j;
    end
    num_p = max(size(X)); % Total number of points in X-Y grid.
        X = O(1) + X;     % Move grid 2 origin.
        Y = O(2) + Y;
        Z = O(3)*ones(num_p,1);
end

%--------------------------------------------------------------------------
% Plotting.
if f_handle > 0 
    figure(f_handle); hold on; grid on; %axis equal;
    plot3(O(1),O(2),O(3),'r+');  plot3(O(1),O(2),O(3),'ko'); % Plot origin.
    plot3(X,Y,Z,'b.');   % Plot excit. 'points'.
end
Nc = 36;
for i = 1:num_p
    [xc,yc] = f_cal_circle([X(i) Y(i)],a,Nc);  % Plot excit. circle boundary.
         zc = O(3)*ones(max(size(xc),1));
         if f_handle > 0 
             plot3(xc,yc,zc,'b');  % drawnow
         end
end

%--------------------------------------------------------------------------
% Area filling ratio.
  A_filled = num_p*(pi*a^2);
A_boundary = x_w*y_w;
if A_boundary > 0
    A_ratio = A_filled/A_boundary;
    fprintf('\b Filling_ratio = %.2f \n',A_ratio);
end






