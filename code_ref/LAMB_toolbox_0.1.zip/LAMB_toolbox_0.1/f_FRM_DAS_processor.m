function [Ns,steering,Vs3_3,Vs3_4,S3_4,F3_4] = f_FRM_DAS_processor(c,N_r_ele,Nxc3,Nyc3,r3_type,R_3,P_field_3,Xc3,Yc3,Zc3,x_s3,Vs3_2,theta,ang_steer,Nt,N3,fs,f_multifocus_DAS,P_field_2,X_field_2,Y_field_2,z_field_2,f_null_delay,f_plot_delays,f_plot,f_handle,axis_font)
% This function post-process the final array signals, by performign a DAS (Delay And Sum) beamformer.
%
% 1. By now, this implies only delay the receiving signals for a given reception angle.
%    This assumes delay profiles along X-axis only (equal delays along Y-strip lines).
%
% Parameters:
%                      c = Speed of sound in air [m/s].
%                N_r_ele = Nxc3*Nyc3 -> Number of receiving elements on reception aperture.
%              Nxc3,Nyc3 = Number of reception elements of the aperture.
%                r3_type = Type of reception region (point, line, plane & shell).
%                    R_3 = Curvature radius of field reception region [m].
%              P_field_3 = Reception aperture field center point.
%            Xc3,Yc3,Zc3 = Receiving elements coordinate center's.
%                  Vs3_2 = Vs3_2(Nt,Nxc3,Nyc3,N3) Final (composed & converted) array data signals.
%                  theta = Incident angle vector [Deg].
%              steer_ang = Aperture steering angle vector [Deg].
%                     Nt = Number of incident angles.
%                     Ns = Number of steering angles of reception diagram.
%                     N3 = Number of points of signals.
%                     fs = Sampling frequency [Hz].
%                 f_plot = Flag for plotting figures: 1 -> Plot.   0 -> Do not.
%               f_handle = Main LAMB program figure number.
%              axis_font = Size of font title.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    18/12/2009    Simplified version of 'f_FRM_post_process' v3.3  (29/03/2009).
% ver 2.0    19/03/2010    Multifocal DAS beamforming added!



%--------------------------------------------------------------------------
% Begin DAS (Delay And Sum) beamformer.
%--------------------------------------------------------------------------
fprintf(' DAS post-processing in progress... \n');
% If use of plane grid...then assing fixed distance to normal vector at ele. center's.
if r3_type == 0,  R_3 = min(max(Zc3)); end;  

if N_r_ele > 1
    %----------------------------------------------------------------------
    %----------------------------------------------------------------------
    if Nyc3 > 2, disp('(o_o) Warning: 2D-array detected. Averaging signals along Y-axis...'); end
    if f_null_delay
        % Add array signals with no delay.
        fprintf(' Computing array output with no delays.\n');   
            Vs3_3 = f_FRM_add(Nxc3,Nyc3,Vs3_2,Nt,N3);
         steering = 0;   Ns = [];   
            Vs3_4 = 0; S3_4 = 0; F3_4 = 0;
    else
        %----------------------------------------------------------------------
        % DAS processing for 'Ns' steering angles!
        [steering,Ns] = f_create_steer_vector(ang_steer);
        if (Ns == 1)
            fprintf(' Computing array PWF-output @%.1f�\n',steering);
            Vs3_3 = zeros(N3,Nt);     % DAS output for 'Nt' incident and 1 steering angle.
        else
            Vs3_3 = zeros(Nt,Ns,N3);  % DAS output for 'Nt' incident and 'Ns' steering angle.
        end
        O_ele = [Xc3(:,1) Yc3(:,1) Zc3(:,1)];  % Coordinates of X-line central receiving elements.
        for k = 1:Nt
            % Process incident angle 'theta(k)'
            fprintf(' %.1f�',theta(k));
            for l = 1:Ns
%            [l steering(l)]
                if l == 1,                 f_color = 'b'; 
                elseif  steering(l) > 0,   f_color = 'g';   
                elseif  steering(l) == 0,  f_color = 'r';   
                else                       f_color = 'c';   
                end;
                if (Nt > 1) && (k > 1), f_plot = 0; end % Turn off plotting feature 4 rest of incident angles.
                %----------------------------------------------------------------------
                %----------------------------------------------------------------------
                % Begin DAS beamforming for:  theta(k),steering(l).
                ele_delay = f_cal_t_delay_FOPD(c,R_3,Nxc3,P_field_3,O_ele,1,Nxc3,steering(l),f_plot,f_handle,axis_font,f_color,1); 
                if f_plot_delays
                    figure(f_handle+9); hold on; grid on; plot(ele_delay,f_color);
                end
                  s_a = zeros(N3,1);
                for i = 1:Nxc3
                    %-------------------------------------------------------------
                    % Average array signals alogn Y-line [Xc3(i,:) Yc3(i,:) Zc3(i,:)].
                    % Then we set delays along X-axis only -> equal delays along Y-strip lines.
                    s = zeros(N3,1);
                    for j = 1:Nyc3
                        s_j(:,1) = Vs3_2(k,i,j,:);
                               s = s + s_j;
                    end
                      s = s/Nyc3;  % Y-axis average received array signal.
                    s_d = f_delay_signal(fs,N3,ele_delay(i),s(:),1); % Delayed signal.
                    %-------------------------------------------------------------
                    s_a = s_a + s_d; % Compute DAS beamformer output.
                    %------------------------------------------------------------------
                end
                %----------------------------------------------------------------------
                %----------------------------------------------------------------------
                % Save DAS array output @steering angle 'Ns'.
                if (Ns == 1) 
                    Vs3_3(:,1) = s_a;   % DAS output for 'Nt' incident and 1 steering angle.
                else
                    Vs3_3(k,l,:) = s_a; % DAS output for 'Nt' incident and 'Ns' steering angle.
                end
            end

            %----------------------------------------------------------------------
            % Vs3_2 = Vs3_2(Nt,Nxc3,Nyc3,N3) Final (composed & converted) array data signals.
            if f_multifocus_DAS(1) && Nyc3 == 1
                       mf_length = f_multifocus_DAS(2);
                         mf_step = f_multifocus_DAS(3);
                       Vs32(:,:) = Vs3_2(k,:,1,:);
                            Vs32 = Vs32';
               [Vs3_4,S3_4,F3_4] = f_multifocal_DAS(mf_length,mf_step,N3,fs,c,Vs32,P_field_2,X_field_2,Y_field_2,z_field_2,P_field_3,O_ele,Nxc3,f_handle); 
            else
                Vs3_4 = 0; S3_4 = 0; F3_4 = 0;
            end
        end
        %------------------------------------------------------------------    
    end   
    %----------------------------------------------------------------------
    %----------------------------------------------------------------------
else % From -> if N_r_ele > 1
    fprintf(':| No data to post-process:  N_r_ele = %i \n',N_r_ele);
    Vs3_3 = Vs3_2;
    Vs3_4 = 0;
 steering = 0;
       Ns = [];      
end
fprintf(' \n');


