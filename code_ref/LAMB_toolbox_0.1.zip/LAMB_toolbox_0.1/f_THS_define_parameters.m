function [alfa,beta,ro,Lambda,Mu,c,ro_air,lambda_air_max,Z0,N,t,Nf,f,f_s,Nt,theta,Ncph,c_ph,num_modes,mode_type,lambda_min,W,K,theta_s,plate_type] = f_THS_define_parameters(f_cph_mapping,s_type,T_amb,Hr,P,material,d,a,modes,t_min,t_max,fs,f0,f_min,f_max,c_ph_min,c_ph_max,c_ph_s,theta_min,theta_max,theta_s,x_s2,y_s2,f_font,f_title)
% Define main parameters for THS.
%
% Parameters:
%             f_font = Axis labels font size eg. 14.
%            f_title = Plot Title w/font size 14,etc.                0 -> Do not plot titles.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    29/12/2008
% ver 1.1    09/01/2009     Add of [min max] wavelenghts for 3D mapping.
% ver 1.2    15/01/2009     Return of air characteristic impedance added.
% ver 2.2    09/03/2009     Return of 'plate_type' added.
% ver 2.3    30/12/2009     Cooper material type added to existing Aluminuium.


fprintf('1.1. Main THS parameters: \n');
%--------------------------------------------------------------------------
% 1. Define principal parameters:
if theta_s == 0
    disp(' (o_o) Warning:  theta_s = 0... Assigning value = 1')
    theta_s = 1;
end

    t = (t_min:1/fs:t_max-(1/fs));      % Signal's temporal axis [s].
    N = max(size(t));                   % Number of points in temporal traces.
  f_s = fs/N;                           % Frequency spacing 'step' between mode's frequency points [Hz].
    f = (f_min:f_s:f_max)';             % Desired frequency operating bandwidth [Hz].    
theta = (theta_min:theta_s:theta_max)'; % Incidence angle vector [Deg].
   Nt = max(size(theta));               % Number of incidence angles to simulate.
 c_ph = (c_ph_min:c_ph_s:c_ph_max)';
 Ncph = max(size(c_ph));                % Number of phase velocities to simulate. 
if f_cph_mapping 
    disp('Mode types: A ,S ,B (both) ?');
    m_type = input(' ','s');
    if (m_type == 'A') || (m_type == 'a')
        mode_type = 1;
    elseif (m_type == 'S') || (m_type == 's')
        mode_type = 0;
    else
        mode_type = [0 1];
    end                
    Nt = Ncph;
end         
%--------------------------------------------------------------------------
[c,atte_air_dB,ro_air,Z0] = f_cal_air_properties(T_amb,Hr,P,f0); % Sound speed at 'T_amb' [m/s].
           lambda_air_max = c/f_min;
%--------------------------------------------------------------------------
% 2. Obtain material properties
[cph_Rayleigh,alfa,beta,ro,Lambda,Mu,r_poisson,plate_type] = f_mat_properties_2(1,material);

lambda_R_min = cph_Rayleigh/max(f);
lambda_R_max = cph_Rayleigh/min(f);

%-----------------------------------------       
fprintf('   alfa = %.1f m/s          beta = %.1f m/s \n',alfa,beta);
fprintf('     ro = %.1f kg/m3  v_Rayleigh = %.1f m/s \n',ro,cph_Rayleigh);
fprintf('               lambda_Rayleigh_min = %.1f mm \n',lambda_R_min*1000);
fprintf('               lambda_Rayleigh_max = %.1f mm \n',lambda_R_max*1000);
fprintf(' Lambda = %.1f GPa              Mu = %.1f GPa \n',Lambda/10^9,Mu/10^9);
fprintf('                     poisson ratio = %.3f \n',r_poisson);
%-----------------------------------------    
if ~f_cph_mapping 
    %-----------------------------------------    
    % Check frequency-BW & signal type consistency.
    if (length(f) > 1) && (s_type == 1)
        disp('(o_o) Warning: using CW excitation with more than 1 frequency...')
        fprintf('      Setting BW to single freq.  f0 = %.1f MHz \n\n',f0/10^6);
        f = f0;
    elseif (length(f) <= 1) && (s_type ~= 1)
        disp('(o_o) Warning: WB-signal selected, but only 1freq. present in BW...')
        var = f_input('      Choose default BW:  0.5-1.5 MHz (Y/N)?',0,1);
        if (var == 'y') || (var == 'Y')
            f_min = 0.5*10^6;     f_max = 1.5*10^6; % Use default frequency operating bandwidth [Hz].
        else
            f_min = f_input('      f_min [Hz] ?',1,0);
            f_max = f_input('      f_max [Hz] ?',1,0);
        end
        f = (f_min:f_s:f_max)';    % Set frequency bandwidth [Hz].
    end
    %-----------------------------------------    
    % Load & interpolate Lamb mode frequencies.
    switch material 
        case 5 % Aluminium
            [mode_type,F,K] = f_load_Al_Lamb_modes(d,modes);
        case 9 % Cooper.
            [mode_type,F,K] = f_load_Cu_Lamb_modes(d,modes);
        otherwise
            disp(':( Error: Material type not available yet. Only Al & Cu.')
            error(' ');
    end    
    [W,K,Cg,Nf,num_modes,mode_type,lambda] = f_THS_extract_BW(f_cph_mapping,modes,mode_type,f_s,f0,f,F,K,d,a,plate_type,f_font,f_title);
    lambda_min = min(min(lambda));           % Absolute minimum Lamb wavelenght [m].
    %-----------------------------------------    
    % Determinate excitation's ratio condition:     r_atio = Diameter/(half min(wave_longitude))
       r_atio = (2*a)/(0.5*lambda_min);     % It should be < 1 to avoid interference problems.
    % Determinate IRM-radiation r_ab condition:       r_ab = min(ele_dim)/(lambda_air_max/2)
          a_2 = min([x_s2 y_s2]);           % Minimum dimension (width,high) of THS-radiation element.
         r_ab = a_2/(0.5*lambda_air_max);   % It should be > 1 to avoid acoustic radiation problems.
    

    %-----------------------------------------    
    fprintf('\b\b(cols.) & wavelenghts min/f0/max (rows) in [m]\n');
    for m=1:num_modes fprintf(' %.4f ',lambda(1,m)); end; fprintf('\n'); % Print row with min. wavelengths.
    for m=1:num_modes fprintf(' %.4f ',lambda(2,m)); end; fprintf('\n'); % Print row with f0  wavelengths.
    for m=1:num_modes fprintf(' %.4f ',lambda(3,m)); end; fprintf('\n'); % Print row with min.  wavelengths.
    
    fprintf('      a = %.2f mm         lambda_min = %.1f mm \n',a*1000,lambda_min*1000);
    fprintf(' r_atio = %.2f ',r_atio); 
    if r_atio > 1
        fprintf(' :( \n'); 
        fprintf('--------------------------------------------------------------------------------\n');
           disp('(o_o) Warning:   r_atio = 2a/(lambda_min/2) > 1  May cause interference problems..')
        fprintf('      Sujested value: a <= %.2f mm \n',min(lambda_min*1000)/4);
        fprintf('--------------------------------------------------------------------------------\n\n');
    else
        fprintf(' :) \n'); 
    end
    fprintf(' e_dims = %.2f-%.2fmm lambda_air_max = %.2f mm \n',x_s2*1000,y_s2*1000,lambda_air_max*1000);
    fprintf('   r_ab = %.2f ',r_ab);
    if r_ab < 1
        fprintf(' :( \n'); 
        fprintf('------------------------------------------------------------------------------------------------\n');
           disp('(o_o) Warning: r_ab = min(e_dim)/(lambda_air_max/2) < 1 may cause acoustic radiation problems..')
        fprintf('      Sujested value:    min(e_dim) >= %.2f mm \n',(lambda_air_max/2)*1000);
        fprintf('------------------------------------------------------------------------------------------------\n\n');
    else
        fprintf(' :) \n');
    end
else
    %-----------------------------------------
    % Set dummy parameter in case of 3D mapping.
    num_modes = max(size(mode_type));
           Nf = max(size(f));     % Number of frequencies points to simulate. 
            W = (2*pi)*f; K = 0;  % K = 0  Because later we define it at constant frequency!
   lambda_min = min(c_ph)/max(f); % Minimum 3D-sweep wave-longitude [m].
   lambda_max = max(c_ph)/min(f); % Miximum 3D-sweep wave-longitude [m].
    % Definition of Ratio of excitation element = Diameter/(half min(wave_longitude))
    r_atio = (2*a)/(0.5*lambda_min);  % It should be < 1 to avoid interference problems.
    %-----------------------------------------
    fprintf('\n 3D-sweep limit wavelenghts in [m]: \n');
    fprintf(' %.2f mm  @[%.1f m/s  %.1f MHz] \n',lambda_min*1000,min(c_ph),max(f)/10^6); 
    fprintf(' %.1f mm  @[%.1f m/s  %.1f MHz] \n',lambda_max*1000,max(c_ph),min(f)/10^6); 
    
    fprintf('       a = %.2f mm   lambda_min = %.3f mm \n',a*1000,lambda_min*1000);
    fprintf('  r_atio = %.2f \n',r_atio);
    if r_atio > 1
        disp('(o_o) Warning: r_atio > 1 may cause interference problems...')
        fprintf('   --> Sujested value:   a = %.3f mm \n',min(lambda_min*1000)/4);
    end
end
%--------------------------------------------------------------------------
    
    
fprintf('      N = %i    f0 = %.2f MHz \n',N,f0/10^6);
fprintf('     Nf = ['); for i=1:length(Nf) fprintf('%i ',Nf(i)); end;
fprintf('\b]    fs = %.1f MHz    f_s = %.1f Hz\n',fs/10^6,f_s);
fprintf('     Nt = %i    f_min = %.1f MHz   f_max = %.1f MHz \n',Nt,f_min/10^6,f_max/10^6);  

if f_cph_mapping 
    fprintf('   Ncph = %i   Mapping On: \n ',Ncph);
    if (m_type == 'S') || (m_type == 's')
        fprintf('               Simmetric modes. \n');
    elseif (m_type == 'A') || (m_type == 'a')
        fprintf('               Anti-simetric modes. \n');        
    else        
        fprintf('               Simmetric & Anti-simmetric modes. \n');
    end    
else
    fprintf('  theta = ');  for i=1:Nt fprintf('%.1f ',theta(i)); end;  fprintf('� \n');
end;







