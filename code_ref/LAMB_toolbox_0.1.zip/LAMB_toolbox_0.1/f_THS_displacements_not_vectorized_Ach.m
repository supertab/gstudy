function [U] = f_THS_displacements_not_vectorized_Ach(N,Nf,d,mode_type,P,a,r,z,t,w0,k0,alfa,beta,Mu)
% Achenbach core model.
%
% This funtion computes the out-plane displacements from Achenbach theory for point-load force in a plate
% for Simmetric and Anti-simmetric Lamb waves; based on the work:
% "Use of elactodinamic reciprocity to analyze poit-load generated axisymmetric waves in a plate"�
% by:  Achenbach J.D & Y.Xu (Elsevier Wave Motion 30, 1999).
% Obs.:
%             N = Number of points in time signal.
%          Nf-1 = Number of frequency points to simulate in mode 'm'. 
%             t = Time domain vector for signal [s].
%            w0 = Mode frequency vetor [rad/s].
%             P = Acoustic pressure frequency spectrum matrix (modulus,phase);
%                 applied in circular region [Pa].                 
%             a = Radius of circular region [m]
%             r = Radial distance from origin to calculation point.
%             d = plate thickness [m].
%            k0 = wavenumber [Rad/m].
%          k_tl = Longitudinal wavenumber [Rad/m].
%          k_ts = Tranverse wavenumber [Rad/m].
%             U = 'N-Point' displacement matrix:  [u_r0  u_z0
%                                                  u_r1  u_z1
%                                                     ... 
%                                                  u_rN  u_zN]
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    24/09/2009

%--------------------------------------------------------------------------  
 k_pl = sqrt(((w0/alfa).^2) - (k0.^2));           % Longitudinal Lamb wavenumber vector [Rad/m].
 k_qs = sqrt(((w0/beta).^2) - (k0.^2));           % Transversal Lamb wavenumber vector [Rad/m].
 
%--------------------------------------------------------------------------
%                    besselj(nu,Z)
  F0 = (a.*P(:,1).*besselj(1,k0*a))./k0;          % 'Hankel trasform*k0' of 'Piston-like' radial axisymmetric normal traction distribution.
% F1 = (2.*P(:,1).*besselj(2,k0*a))./(k0.^2);     % 'Hankel trasform*k0' of 'Parabolic' radial axisymmetric normal traction distribution.  
%--------------------------------------------------------------------------
% H = besselh(nu,K,Z) 
H0_2 = besselh(0,2,k0*r);                         % Hankel funtion of order '0' with k = 2.
                 
 u_z = zeros(Nf,1);
   u = zeros(1,N);
   U = zeros(1,N);
switch mode_type
    case 0   
    %----------------------------------------------------------------------
    % "Symmetric" mode displacements
        [C_s_z] = f_THS_C_s_z_Ach(d/2,z,P(:,1),k0,k_pl,k_qs,Mu);
          
            u_z = abs( C_s_z.*H0_2 );
            
    case 1
    %----------------------------------------------------------------------
    % "Anti-simmetric" mode displacements
        [C_a_z] = f_THS_C_a_z_Ach(d/2,z,P(:,1),k0,k_pl,k_qs,Mu);
          
            u_z = abs( C_a_z.*H0_2 );

    otherwise
    disp('Mode type error! "0" and "1" only allowed...')
    error(' :(  ')
end % End switch.


%--------------------------------------------------------------------------
% Calc. of out-of-plane displacements using non vectorized 
% code to avoid out of memory problems.
for n = 1:Nf
    phase = k0(n)*r - w0(n).*t - P(n,2); % Calculate the phase part.
        u = u_z(n)*exp(i*phase);         % Comp. Out-of-plane displacement signal.
        U = U + u;                       % Add z_displacement signal for frequency point {w0(n);k0(n)}.
end
%--------------------------------------------------------------------------
% We use only (N/2) possitive frequencies in 'ifft'algorithm
% of 'N' possible freqs; from which only 'Nf' are not '0'.
U = real((1/(N/2))*U)';  % Return final vector w/out_of_plane displacement [m].





% %----------------------------------------------------------------------
% % Apply freq. response of circular transducer% 
% %------------------------------
% % %load matlab_data_transf_TT1-MHz
% % load matlab_data_transf_T104_2MHz25
% %      f0 = w0/(2*pi);
% %       S = interp1(F,S,f0,'cubic');
% %       S = S(:,1)/max(S(:,1));
% %     u_z = u_z.*S;
% %------------------------------
