function [ro_x,X,Y,Z,num_p,num_s,num_p_s] = f_cal_coord_plano_3(P_field,Rx,Ry,a,f_handle)
% Funcion que calcula las coord. de de los puntos p/region circular/eliptica
% de campo, constituida por peque�as sub-regiones circulares de radio 'a'.
% Parametros: 
% 
%           P_field = Punto central d/region circular en plano de campo [x,y,z].
%                Rx = Radio s/eje 'X' [mm].
%                Ry = Radio s/eje 'Y' [mm].
%                 a = Radio d/sub-reg. de llenado "puntos" [mm].
%
% Retorna:  
%             X;Y;Z = Vectores c/coordenadas [mm].
%            handle = Numero del grafico.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    06/02/2008
% ver 1.1    07/02/2008   Agreg. retorno variables:  'ro_x' y 'num_p'.
% ver 1.2    03/01/2009   External figure handle added.
% ver 1.3    29/11/2009   Switch plot capability: on/off if required added.


          d = 2*a;                 % Diametro d/region circular de llenado "puntos" [mm].
      ro_sx = a*sqrt(3);           % Distancia de separacion entre lineas-y 'strips' de circulos s/eje 'X' [mm].
      ro_sy = d;                   % Espaciado de "puntos" s/eje 'Y' [mm]
%--------------------------------------------------------------------------
% Crear vector p/eje X (ro_x).
        ro1 = (0:-ro_sx:-Rx)';     % Definir vector radial s/eje X [mm].    
      n_ro1 = max(size(ro1));
        ro2 = -ro1(n_ro1:-1:2);
       ro_x = [ro2;ro1];
     n_ro_x = max(size(ro_x));
%--------------------------------------------------------------------------
if Rx == Ry
theta_r = acos(ro_x/Rx);
    L_y = Rx*sin(theta_r);  % Longitud d/cuerda s/eje 'Y'.
else
    L_y = sqrt((Ry^2)*(1 - (ro_x/Rx).^2));
end
%--------------------------------------------------------------------------
% Crear cell array c/vectores perpediculares (s/eje Y) p/c valor de 'ro_x'.
  ro_y = cell(n_ro_x,1);
n_ro_y = zeros(n_ro_x,1);
for i = 1:n_ro_x
    if f_impar(i,2)
        ro1 = (0:-ro_sy:-L_y(i))';     
      n_ro1 = max(size(ro1));
        ro2 = -ro1(n_ro1:-1:2);
    else
        ro1 = (a:-ro_sy:-L_y(i))';     
      n_ro1 = max(size(ro1));
        ro2 = -ro1(n_ro1:-1:3);    
    end
    ro_y{i} = [ro2;ro1];
  n_ro_y(i) = max(size(ro_y{i}));
end

%--------------------------------------------------------------------------
% Plot frontera de region de campo.
if Rx == Ry
    [xb,yb] = f_cal_circle([P_field(1) P_field(2)],Rx,100);
          A = pi*(Rx^2);
else
    [xb,yb] = f_cal_ellipse([P_field(1) P_field(2)],Rx,Ry,1);
          A = pi*(Rx*Ry);
end
zb = P_field(3)*ones(max(size(xb)),1);

if f_handle > 0 
    figure(f_handle); hold on; grid on; %axis equal;
    plot3(xb,yb,zb,'r')
end
%--------------------------------------------------------------------------
% Armar vectores 'lista' c/coord. 'X,Y,Z' puntos plano campo.
    n = 1;
for i = 1:n_ro_x
    for j = 1:n_ro_y(i)
            X(n,1) = ro_x(i); 
            Y(n,1) = ro_y{i}(j);
           [xc,yc] = f_cal_circle([X(n) Y(n)],a,36);
           if f_handle > 0 
               plot3(xc,yc,P_field(3)*ones(max(size(xc)),1),'b')
           end
           n = n + 1;
    end
end
%--------------------------------------------------------------------------
     num_p_s = n_ro_y;         % Numero de puntos p/y-strip line en reg. de campo.
       num_p = n - 1;          % Numero total de puntos en region circular/eliptica de campo.
       num_s = num_p/num_p_s;  % Numero toral de 'Y-strip's' utilizados.   
   
           Z = P_field(3)*ones(num_p,1);
          A2 = pi*(a^2)*num_p;
A_fill_ratio = A2/A;           % Indice de llenado de area.

fprintf('a = %.1f mm   A_fill_ratio = %.2f \n',a*1000,A_fill_ratio);



