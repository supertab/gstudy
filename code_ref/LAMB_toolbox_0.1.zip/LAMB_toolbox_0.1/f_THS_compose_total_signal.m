function [u] = f_THS_compose_total_signal(num_modes,N,S_z,theta_index,x_index,y_index)
% This function compose the total displacement signal 'u(t)'
% by adding all the Lamb modes present during simulations.
% Obs.:
%      num_modes = Number of Lamb modes.
%            S_z = THS data cell array:  S_z = cell{Nt,num_modes}(Nx,Ny,N);
%    theta_index = Nt index inside 'S_z'.
%        x_index = X-coordinate index inside 'S_z'.
%        y_index = Y-coordinate index inside 'S_z'.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    02/12/2008
% ver 1.1    17/12/2008     Detection of "num_modes > 1".
% ver 2.0    08/01/2009     Change on reception field dimensions: [Nx Ny]=size(X_field) --> S_z = zeros(Nx,Ny,N)

u = zeros(1,N);
if num_modes > 1
        m = zeros(1,N);
    for j = 1:num_modes
        m(1,:) = S_z{theta_index,j}(x_index,y_index,:);
        u = u + m;    % Calculate total signal by superposition of all Lamb modes simulated!
    end        
else
   u(1,:) = S_z{theta_index,1}(x_index,y_index,:);
end

u = u'; % Return signals by columns.






