function [S] = f_THS_plot_2_2(f_view_spectra,f_feature_type,num_modes,t,N,Nt,fs,S_z,theta,a,p_max,Z0,Ps,f_title,axis_font,f_delete_figs,f_pause)
% Plot features for single reception point with multiple incidence angles (this implies multiple excitation 'points').
% Parameters:
% f_view_spectra = 1 -> Activate spectrum visualization (only 4 lines and surfaces in reception field).
%                  0 -> De-activate feature.
% f_feature_type = 0 -> Maximum.  
%                  1 -> Pick-to-pick value.
%                  2 -> Energy.                                
%              value -> Time instant 'photo' (index between 1:N).
%      num_modes = Number of Lamb waves modes simulated.
%              t = Signal's temporal axis [s].
%              N = Number of points in signal traces.
%             Nt = Number of incidence angles (theta vector).
%             fs = Sampling frequency [Hz].
%            S_z = THS data cell array:  S_z = cell{Nt,num_modes}(Nx,Ny,N);
%          theta = Plane wave incidence angle vector [Deg].
%              a = Radius of excitation 'points' [m].
%          p_max = Maximun excitation pressure [Pa].
%             Z0 = c*ro Is the air characteristic impedance in [N.s/m^3] or [Rayls].
%             Ps = Input excitation signal data matrix:  Ps = zeros(N,Nx);
%        f_title = 1 -> Activate title plot.          0 -> Do not.
%      axis_font = Title & axis font size.
%  f_delete_figs = 1 -> Deletes figures before quit.  0 -> Do not delete figures.
%        f_pause = 1 -> Activate program pause.       0 -> Do not.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    02/12/2008
% ver 1.1    11/12/2008     Delete figures flag added.
% ver 2.0    08/01/2009     Change on reception field dimensions: [Nx Ny]=size(X_field) --> S_z = zeros(Nx,Ny,N)
% ver 2.1    15/01/2009     Corr. of energy calculation by adding air characteristic impedance.
% ver 2.2    17/02/2009     Inter program 'f_pause' added.


fprintf('1.4.2.2. Single reception point for %d incidence angles! \n',Nt)

if f_view_spectra
    %----------------------------------------------------------------------
    % 2.2.1 Plot spectrum for several incidence angles.
    figure(22100); hold on; grid on; set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
    for n = 1:Nt
        [u] = f_THS_compose_total_signal(num_modes,N,S_z,n,1,1);
     [U2,F] = f_cal_spectra(fs,u);
     U(:,n) = U2(:,1);      % Build spemtrum matrix for 'Nt' incidence angles!
    end
     [M,ii] = max(max(U));  % Reference value for amplitude normalization.
    % Plot spectrum matrix.
    for n = 1:Nt
        plot(F,U(:,n)/M); [U_max jj] = max(U(:,n)/M);
        text(F(jj),U_max,[' �',num2str(theta(n))],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);  drawnow;
    end
    if f_title 
        title(['Displacement signal amplitude spectrum @p-max = ',num2str(p_max),'Pa;',' a = ',num2str(a*1000),' mm'],'FontSize',f_title); 
    end;    
    xlabel('f [Hz]','FontSize',axis_font);  ylabel('Normalized amplitude','FontSize',axis_font); 
    % Plot imput signal spectrum for maximum value.
    [M,ii2] = max(max(Ps));
      [S,F] = f_cal_spectra(fs,Ps(:,ii2));
    plot(F,S(:,1)/max(S(:,1)),'g');
    text(F(1),1,['Input signal spectrum @theta = ',num2str(theta(ii2))],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);  drawnow;
    S = 0;
else
    %----------------------------------------------------------------------
    % 2.2.2 Detect features in signals for several incident angles.
    figure(22200); hold on; grid on; set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
    if f_title     title(['Angular dependance of vertical displacement @p-max = ',num2str(p_max),'Pa;',' a = ',num2str(a*1000),' mm'],'FontSize',f_title); end;
    xlabel('Theta [�Deg.]','FontSize',axis_font);
    S = zeros(Nt,1);
    for n = 1:Nt
        [u] = f_THS_compose_total_signal(num_modes,N,S_z,n,1,1);  % S_z = cell{Nt,num_modes}(Nx,Ny,N);
        switch(f_feature_type)
            case 0 % Maximum.
                S(n) = max(u);    
                ylabel('Normalized maximum amplitude','FontSize',axis_font); 
            case 1 % Pick-2-pick.                
                disp('Ups! Pick-2pick feature ...not implemented yet!'); error(' :(');
            case 2 % Energy.
                   v = fs*diff(u);    
                   v = [v; 0];              % Velocity signal [m/s].
                S(n) = (norm(v)^2)*(Z0/N);  % Signal energy: E = rms(ps)*rms(v) [J]  ; v = ps/Z0 % Remember: RMS_x = norm(x)/sqrt(N).
                ylabel('Normalized energy','FontSize',axis_font);
            otherwise
                if (f_feature_type < 0) || (f_feature_type > N)
                    fprintf(' :( Error: Wrong value of feature_type = %d \n',feature_type);  error(' ');
                else
                    S(n) = u(f_feature_type);
                ylabel(['uz norm. amplitude @ t = ',num2str(t(f_feature_type)*10^6),'us'],'FontSize',axis_font);
                end
        end
    end        
    plot(theta,S/max(S),'b');
    text(theta(2),1,['Refence value = ',num2str(max(S))],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',12);
    fprintf('Reference value: %d',max(S))
end

%--------------------------------
if f_delete_figs && f_pause
    pause;  
    delete(figure(22100));  delete(figure(22200));
elseif f_delete_figs
    delete(figure(22100));  delete(figure(22200));
end






