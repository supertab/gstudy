function [s] = f_s_burst_sin(s_amp,f0,t,nro_b,w_type)
% Function for computing a sinusoidal burst of pressure signal.
% Where:
%     s_amp = Burst maximum amplitude; typically in [Pa].
%        f0 = Senoid frequency.
%         t = Time axis vector [s].
%     nro_b = Number of burst cycles.
%    w_type = window type:   
%             0 -> rectangular   
%             1 -> sinusoidal window. 
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    07/11/2004
% ver 2.0    05/01/2008    English version!

if nro_b <1
    error(':(  Wrong parameter value: see "n_burst"..')
end

[N,N2] = size(t);
if N <= N2   
    N = N2;   
    t = t';        % Convert row vector in column vector.
end  

%--------------------------------------------------------------------------
% Generate sinusoidal signal....and count corresp. samples for 'nro_b' cycles.
       s = zeros(N,1);    
       w = 2*pi*f0;
       i = 2;
      zc = 0;
zc_index = 0;
while (zc <= 2*nro_b) && (i <= N)
    
    s(i) = s_amp*sin(w*t(i));   
    if s(i) > 0                 
       if s(i-1) <= 0  
          zc = zc + 1;
          zc_index = i - 1;
       else    
          i = i + 1; 
          continue           
       end  
    else
       if s(i-1) >= 0  
          zc = zc + 1;  
          zc_index = i - 1;
       else    
          i = i + 1;  
          continue           
       end  
    end    
    i = i + 1;
end   
%--------------------------------------------------------------------------
for j = zc_index:N
    s(j) = 0;      % Put signal's tail to '0'!
end
if i > N
   disp('Warning: Burst Signal outside t_max; Using "Continous Wave"...') 
   figure (880); hold; grid; plot(b,'b'); plot(b,'r.'); pause
end    

%--------------------------------------------------------------------------
% Apply selected window!
switch(w_type)
    case 0
        fprintf(' Burst w/Rectangular window @%i cycles \n',nro_b)
    case 1
        fprintf(' Burst w/Sinusoidal window @%i cycles \n',nro_b)
        w = sin(w/(2*nro_b)*t);
        s = w.*s;
    otherwise
        disp(' :(  Ups! Windowing not implemented yet!! see: "f_s_burst_sin"...')
        pause
        error(' :( ')
end






