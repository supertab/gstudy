function [H_s_z] = f_THS_H_s_z_Mit(h,z,k0,k_alfa,k_beta,Mu)
% This function calculate's the 'Symmetric' coeficients 'H_s_z'  
% for the ifft sumation of Lamb modes based on the paper: "Laser-ultrasonic generation of Lamb waves in the reaction range" 
%                                                   from:  Yijun Shi, Shi-Chang Wooh & Mark Orwat from Mit.
%                                                     Ed:  Elsevier, Ultrasonics 41(2003) p.623-633.
%
% Obs.:   
%             h = d/2 plate thickness [m].
%             z = Z coordinate on the plate.
%            k0 = wavenumber [Rad/m].
%        k_alfa = Longitudinal wavenumber [Rad/m].
%        k_beta = Tranverse wavenumber [Rad/m].
%            Mu = Lame constant [Pa].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0  23/08/2008
% ver 2.0  23/09/2009


% --------------------------------------------------------------------
% S Y M M E T R I C coeficients.
% --------------------------------------------------------------------
  H_s_z =  (i*k_alfa/Mu).*((k0.^2)-(k_beta.^2)).*sinh(k_alfa*h).*sinh(k_beta*h);

   
   
   
   
   
   
   
   