function [gamma_a_zn] = f_cal_Gamma_a_functions(k0,k_tl,k_ts,h,z)
% This funtion calculates the coefficient function for straiht crested
% simmetric Lamb waves in a free layer.
% It is based on the work : "The influence of Finite-Sice Sources in Acousto-Ultrasonics"�
%                    from:  B.N.Pavlakovic & Joseph L. Rose (NASA report. 1994)
% 
% Obs.: 
%            k0 = wavenumber [Rad/m].
%          k_tl = Longitudinal wavenumber [Rad/m].
%          k_ts = Tranverse wavenumber [Rad/m].
%             h = Half plate thickness [m].
%             z = vertical coodinate within the plate [m].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    04/09/2007   
% ver 1.1    04/01/2008     'd' parameter eliminated.
% ver 1.2    15/01/2008     Simplified version without radial displacements.
% ver 2.0    09/07/2008     Changes in eqs. 
% ver 2.1    30/11/2008     Elimination of 'v_l' and 'v_s' parameters.
%--------------------------------------------------------------------------

% gamma_a_rn = k0.*( (-2.*k_tl.*k_ts.*cos(k_tl.*h).*sin(k_ts.*z)) + (((k_ts.^2) - (k0.^2)).*cos(k_ts.*h).*sin(k_tl*z)) );  
% gamma_a_zn = gamma_a_rn;

gamma_a_zn = -k_tl.*( (2.*(k0.^2).*cos(k_tl.*h).*cos(k_ts.*z)) - (((k_ts.^2) + (k0.^2)).*cos(k_ts.*h).*cos(k_tl.*z)) );  
%                                                                ^             ^
%                                                                |             |   Sings changed.
%                                                                See Ditri paper 1993a and page 53 eq. 4.2 of NASA Report. 

   
   
   
   
   
   
   
