function [S_feature,S_delay] = f_FRM_plot_3(Vs_feature_type,Vs_delay_type,Xc3,Yc3,Zc3,Vs3_2,theta,a,p_max,num_p,t3,fs,f_delete_figs,f_pause,f_norm_plots,f_dB_plots,f_title,f_font,f_handle)
% Extract feature-profiles of array's received signals.
%
% Parameters:
%             Vs3_2 = zeros(Nt,Nxc3,Nyc3,N3)  Final array element output signals.
%                     Where [Xc3 Yc3 Zc3] are the reception element coordinate center's.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    14/12/2009

[Nt Nxc3 Nyc3 N3] = size(Vs3_2);

%---------------------------------------------------------------------------------------------------------------    
% 4.2 Plot features for aperture reception digram.
f_plot = 1;
h1 = figure(f_handle+1); 
h2 = figure(f_handle+2); 
if f_title  
    figure(h1); title(['Array signal�s reception profile @p-max = ',num2str(p_max),'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p)],'FontSize',f_title); 
    figure(h2); title(['Array signal�s reception signal delays @p-max = ',num2str(p_max),'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p)],'FontSize',f_title); 
end

%-----------------------------------
% Assign correct magnitudes to axis.
%   Vs3_2 = zeros(Nt,Nxc3,Nyc3,N3)
   f_label = cell(1,1);
f_label{1} = 'Reception element';
   E_const = 1;  % Cal. energy of signals using 'e_const' value.
 S_feature = zeros(Nt,Nxc3,Nyc3);
   S_delay = zeros(Nt,Nxc3,Nyc3);
    Signal = zeros(Nxc3,Nyc3,N3);
for k = 1:Nt
                    Signal(:,:,:) = Vs3_2(k,:,:,:);
    [S_feature(k,:),S_delay(k,:)] = f_s_feature(Vs_feature_type,Vs_delay_type,theta(k),E_const,N3,fs,t3,Signal,[1:Nxc3],[1:Nyc3],f_plot,f_norm_plots,f_dB_plots,f_font,f_label,h1,h2);
end


%-----------------------------------
if f_delete_figs && f_pause
    disp('Program paused. Press any key to continue...');
    pause;  
    delete(figure(h1));  delete(figure(h2));
elseif f_delete_figs
    delete(figure(h1));  delete(figure(h2));
end
