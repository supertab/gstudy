function [Xc3,Yc3,Zc3,Nxc3,Nyc3,X3,Y3,Z3,Nx3,Ny3,a_3,b_3,Alfa3,Beta3,Gamma3] = f_IRM_reception_coords(r3_type,ele_order_3,P_field_2,P_field_3,x_w3,y_w3,x_s3,y_s3,n_a3,n_b3,ang_alfa,ang_beta,ang_gamma,R_3,phi_3,psi_3,f_handle,f_recp_eles,f_normals)
% This function returns the coordinates of reception field points for the
% IRM routines.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    01/01/2009
% ver 2.0    24/01/2009      Return element's space orientation angles: [Ang_alfa Ang_beta Ang_gamma].
% ver 2.1    27/01/2009      Return of element (or sub-element) dimensions corresponding to [n_a3 n_b3] parameters.
% ver 2.2    01/03/2009      Plot of radial lines foe ele. center's only; instaid of all aperture eles.


if (n_a3 > 1) || (n_b3 > 1)
    if r3_type == 1
        fprintf('\n\n :( Ups!: Square/Rectangular circle filled region. \n');
        fprintf('        Case not available yet for IRM... \n');
        error(' ');
    end
    %--------------------------------------------------------------------------------------------------------------
    % 1. Adjust width & steps between points for reception field with multiple reception signals by reception element!
    %----------------------------------    
    % 1.1 Adjust & plot center of elements.
    if x_w3/2 < x_s3   
        x_wc3 = 0;  % Case for single reception element.
    else               
        x_wc3 = x_w3 - x_s3/2; 
    end;
    if y_w3/2 < y_s3   
        y_wc3 = 0;  % Case for single reception element.
    else               
        y_wc3 = y_w3 - y_s3/2; 
    end;
    [L_arc,Xc3,Yc3,Zc3,Nxc3,Nyc3,num_p,num_s,num_p_s,boundary] = f_cal_plano_campo (r3_type,1,P_field_2,ele_order_3,0,P_field_3,x_wc3,y_wc3,x_s3,y_s3,ang_alfa,ang_beta,ang_gamma,R_3,phi_3,psi_3,f_handle);
    %----------------------------------
    % 1.2 Adjust sub-element inter-space for plane grids...
    x__s3 = x_s3/(n_a3);        % Set sub-element inter-space X-distance [m].
    if x_w3/2 < x_s3   
        x_w3 = x_s3 - x__s3/2;  % Case for single reception element.
    else               
        x_w3 = x_w3 - x__s3/2; 
    end;
    y__s3 = y_s3/(n_b3);        % Set sub-element inter-space Y-distance [m].
    if y_w3/2 < y_s3   
        y_w3 = y_s3 - y__s3/2;  % Case for single reception element.
    else               
        y_w3 = y_w3 - y__s3/2; 
    end;
    %----------------------------------    
    % In case of shell grids... re-adjust angles....
    if (phi_3 > 0) && (psi_3 == 0) && (r3_type == 3)
        % 1.3 Adjust for cylindrical shell type along Y-axis.
        phi_3 = (180/pi)*(L_arc)/R_3;
    elseif (phi_3 == 0) && (psi_3 > 0) && (r3_type == 3)
        % 1.4 Adjust for cylindrical shell type along X-axis.
        psi_3 = (180/pi)*(L_arc)/R_3;
    elseif (phi_3 > 0) && (psi_3 > 0) && (r3_type == 3)
        % 1.5 Adjust for espherical shell grid!.
        phi_3 = (180/pi)*(L_arc(1))/R_3;         
        psi_3 = (180/pi)*(L_arc(2))/R_3;
    end
    %----------------------------------
    % 1.6 Cal. main IRM grid field points.
    [x3,X3,Y3,Z3,Nx3,Ny3,num_p,num_s,num_p_s,boundary] = f_cal_plano_campo (r3_type,1,P_field_2,ele_order_3,0,P_field_3,x_w3,y_w3,x__s3,y__s3,ang_alfa,ang_beta,ang_gamma,R_3,phi_3,psi_3,f_handle);
    color_type = ['g' 'r'];
    %--------------------------------------------------------------------------------------------------------------
else
    %--------------------------------------------------------------------------------------------------------------
    % 2. Calculate coordinates of reception field for single point elements (1-signal by reception element).
    [xc3,Xc3,Yc3,Zc3,Nxc3,Nyc3,num_p,num_s,num_p_s,boundary] = f_cal_plano_campo (r3_type,1,P_field_2,ele_order_3,0,P_field_3,x_w3,y_w3,x_s3,y_s3,ang_alfa,ang_beta,ang_gamma,R_3,phi_3,psi_3,f_handle);
       X3 = Xc3;      Y3 = Yc3;   Z3 = Zc3;
      Nx3 = Nxc3;    Ny3 = Nyc3;
    x__s3 = x_s3;  y__s3 = y_s3;
    color_type = ['g' 'y'];
    %--------------------------------------------------------------------------------------------------------------
end

%----------------------------------------------
% Detect reception element's space orientation angles.
 Alfa3 = zeros(Nx3,Ny3);
 Beta3 = zeros(Nx3,Ny3);
Gamma3 = zeros(Nx3,Ny3);
for i3 = 1:Nx3
    for j3 = 1:Ny3
        P3 = [X3(i3,j3) Y3(i3,j3) Z3(i3,j3)];
        [Alfa3(i3,j3),Beta3(i3,j3),Gamma3(i3,j3)] = f_IRM_detect_ele_orientation(P_field_2,P3,r3_type,phi_3,psi_3,ang_alfa,ang_beta,ang_gamma);
%         if f_normals
%             % Plot reception element radial orientation lines.
%             [x2,y2,z2] = f_rotate_matrix(0,0,-R_3,Alfa3(i3,j3),Beta3(i3,j3),Gamma3(i3,j3)); 
%                   P3_2 = P3 + [x2 y2 z2];
%             plot3([P3(1) P3_2(1)],[P3(2) P3_2(2)],[P3(3) P3_2(3)],'k');  
%         end
    end
end
%----------------------------------------------
% Define reception element (or sub-element) 
% half-dimensions in corresp. to [n_a3 n_b3]).
a_3 = x__s3/2;  % Element (or sub-element) half width [m].
b_3 = y__s3/2;  % Element (or sub-element) half high [m].
    
%----------------------------------------------
% Plot element boundaries.
c = 1;
for i3 = 1:Nxc3
    for j3 = 1:Nyc3
        c_point = [Xc3(i3,j3) Yc3(i3,j3) Zc3(i3,j3)]; % Central point of aperture reception element.
        [alfa,beta,gamma] = f_IRM_detect_ele_orientation(P_field_2,c_point,r3_type,phi_3,psi_3,ang_alfa,ang_beta,ang_gamma);
        if f_recp_eles
            % Plot reception element boudaries.
            if f_impar(c,2); b_color = color_type(1);
            else             b_color = color_type(2); end;
            f_draw_boundary(c_point,x_s3,y_s3,alfa,beta,gamma,b_color,f_handle);
        end
        if f_normals
            % Plot element radial lines.
            [x2,y2,z2] = f_rotate_matrix(0,0,-R_3,alfa,beta,gamma); 
              c_point2 = c_point + [x2 y2 z2];
            plot3([c_point(1) c_point2(1)],[c_point(2) c_point2(2)],[c_point(3) c_point2(3)],'k');  
        end
 %%%%%%%plot3(c_point(1),c_point(2),c_point(3),'g+');
        c = c + 1;
    end
end
%----------------------------------------------
% Plot central and 1st. point of reception field.
figure(f_handle); axis equal;
plot3(P_field_3(1),P_field_3(2),P_field_3(3),'rs');  plot3(P_field_3(1),P_field_3(2),P_field_3(3),'k+');  
plot3(X3(1,1),Y3(1,1),Z3(1,1),'ro'); 

view(0,90);

%axis([0.044 0.056 -0.005 0.005])
