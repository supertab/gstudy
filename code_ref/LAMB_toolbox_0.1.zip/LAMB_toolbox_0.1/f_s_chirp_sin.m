function [s] = f_s_chirp_sin(s_amp,t_end,N,f_ini,f_end,fs)
% This function generates a linearly sweep chirp signal of pressure.
% Where:
%          s_amp = Signal's amplitude; typicaly in [Pa].
%              t = Time axis [s].
%          t_end = Chirp time ending [s].
%          f_ini = Initial sweep frequency [Hz].
%          f_end = Final sweep freq. [Hz].
%
%Obs. 'good' values for BW are:
%          f_ini = 0.7*10^6   
%          f_end = 1.3*10^6   
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   03/04/2006
% ver 2.0   05/01/2008    English version!


% -----------------------------------------------------
% Generate linear sinusoidal chirp
       t2 = (0:1/fs:t_end)';
       N2 = max(size(t2));
       ch = s_amp*chirp(t2,f_ini,t_end,f_end,'linear',-90);   
       
        s = zeros(N,1);
s(1:N2,1) = ch(:,1);



% % Obs. empleamos:
%    C = 1;      % Amplitud de la se�al de velocidad [m/s].
% beta = 3.25   % 3.833  -> Cte's de control exp. ver paper J.L.Emeterio y...
%    k = 2    %1.437   % 1.437
% % -----------------------------------------------------
% % Cal. envolvente de modelo de  J.L.Emeterio & L.Ullate   
%    f0 = 0.83*10^6
%     e = zeros(N,1);
% for i = 1:N
%     e(i) = C * (t(i)^beta) * exp(-k*f0*t(i));      
% end
%     e = (1/max(e))*e;    % normalizacion de la envolvente



