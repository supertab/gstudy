function [cph_Rayleigh,Alfa,Beta,ro,lambda,mu,sigma,plate_type] = f_mat_properties_2(Nl,material)
% This function return the longitudinal (Alfa) and shear (Beta)
% bulk wave velocities for the selected materials, with its densities.
% Obs. for the moment only few materials are at disposal.
%
% Units:    
%     Long.& shear bulk-wave velocities 'Alfa'/'Beta' =  [m/s]
%                                        Density 'ro' = [Kgr/m^3]
%                       Lame-consts. 'lambda' & 'mu'  = [Pa] 
%
% Author:     Jose Luis Prego Borges 
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%
% ver 1.0     15/06/2007
% ver 2.0     01/09/2007    Attenuation effect added for some materials...
% ver 2.1     29/12/2008    Return of poisson ratio parameter.
% ver 2.2     10/03/2009    Return of 'plate_type' added + copper mat. added.


  Alfa = zeros(Nl,1);
  Beta = zeros(Nl,1);
    ro = zeros(Nl,1);
lambda = zeros(Nl,1);
    mu = zeros(Nl,1);

if Nl <= 0
    disp('Number of layers null or negative...')
    error(':(');    
else    
for n = 1:Nl
    switch material(n)
        case 0 % Vacuum ---------------------------------------
            disp('Ops, material not allowed, change type please...')            
            error(' ');
            ro(n) = 1*10^-12;     % Density in [Kgr/m^3]
        lambda(n) = 2*10^-12;     % Lame constant in [Pa]
            mu(n) = 1*10^-12;     % Lame constant in [Pa
        
        case 1 % Air -----------------------------------------
            disp('Ops, material not allowed, change type please...')
            pause
            ro(n) = 1.194764;     % [Kgr/m^3] at: 21�;50%;1013.25 hPa
             alfa = 343.809;      % [m/s]     at: 21�;50%;1013.25 hPa
             beta = 1*10^-12;     % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]

        case 2 % Water ---------------------------------------
            disp('Ops, material not allowed, change type please...')
            pause
            ro(n) = 1000;         % [Kgr/m^3]
             alfa = 1483;         % [m/s]
             beta = 0.01;         % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]
        
       case 3 % Titanium -------------------------------------
            disp(' Material: Titanium')
            ro(n) = 4460;         % [Kgr/m^3]
             alfa = 6060;         % [m/s]
             beta = 3230;         % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]
       plate_type = 'Titanium';

       case 4 % Steel ----------------------------------------
            disp(' Material: Steel')
            ro(n) = 7930;         % [Kgr/m^3]
             alfa = 5960;         % [m/s]
             beta = 3230;         % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]
       plate_type = 'Steel';

       case 5 % Aluminium ------------------------------------
            disp(' Material: Aluminium.')
            ro(n) = 2620.4;   % 2700;     % [Kgr/m^3]
             alfa = 6370; %+ i*0.0638;    % [m/s]
             beta = 3170; %+ i*0.031;     % [m/s]
             mu_r = ro(n)*((real(beta)^2)-(imag(beta)^2));   
             mu_i = -2*ro(n)*real(beta)*imag(beta);
            mu(n) = mu_r + i*mu_i;      % [Pa]
         lambda_r = ro(n)*((real(alfa)^2) - (imag(alfa)^2) - 2*(real(beta)^2) - 2*(imag(beta)^2));  % [Pa]
         lambda_i = -2*ro(n)*((real(alfa)*imag(alfa)) - (real(beta)*imag(beta)));
        lambda(n) = lambda_r + i*lambda_i;
       plate_type = 'AL';
        
       case 6 % Epoxy ---------------------------------------
            disp(' Material: Epoxy')
            ro(n) = 1170;         % [Kgr/m^3]
             alfa = 2610;         % [m/s]
             beta = 1100;         % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]
       plate_type = 'Epoxi';

       case 7 % Gold ----------------------------------------
            disp(' Material: Gold')
            ro(n) = 19488;        % [Kgr/m^3]
             alfa = 3217;         % [m/s]
             beta = 1195;         % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]
       plate_type = 'Gold';
     
       case 8 % Fused quartz --------------------------------
            disp(' Material: Quartz')
            ro(n) = 2197;         % [Kgr/m^3]
             alfa = 5968;         % [m/s]
             beta = 3764;         % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]
       plate_type = 'Fused quartz';

       case 9 % Copper -------------------------------------
              % Copper data: density = 8930 kg/m^3;    Vl = 5010 m/s;    Vsh = 2200 m/s 
            disp(' Material: Copper')
            ro(n) = 8930;         % [Kgr/m^3]
             alfa = 5010;         % [m/s]
             beta = 2270;         % [m/s]
            mu(n) = ro(n)*(beta^2);                 % [Pa]
        lambda(n) = (ro(n)*(alfa^2)) - 2*mu(n);     % [Pa]          
       plate_type = 'Cooper';
       
       otherwise
            disp('Type of material not defined...')
            error(':(');
       end
       
   [Alfa(n),Beta(n)] = f_bulk_v(ro(n),lambda(n),mu(n));
end

%-----------------------------------------------------
% Test code 4 different: alfa, beta & density.
% Valores actuales:
       sigma = lambda/(2*(lambda + mu));
cph_Rayleigh = Beta*(0.87 + 1.12*sigma)/(1+sigma); % Aprox. Rayleigh wave velocity [m/s]
       sigma = sigma;
           E = (beta^2)*2*ro*(1+sigma);

%-----------------------------------------------------
% De hojas de datos:
    E_2 = 69000*10^6;   % De la hoja de datos de Servicio estacio.
sigma_2 = 0.355;        % Del Kino.
   ro_2 = 2700;         % Del Kino & Servicio estacio.
 alfa_2 = sqrt((E*(1-sigma_2))/(ro_2*(1+sigma_2)*(1-2*sigma_2)));
 beta_2 = sqrt(E_2/(2*ro_2*(1+sigma_2)));
   mu_2 = ro_2*(beta_2^2); 
%  Alfa
%  Alfa = alfa_2
%  Beta
%  Beta = beta_2
%    ro 
%    ro = r_o
%    mu = ro*(beta_2^2) 
end

