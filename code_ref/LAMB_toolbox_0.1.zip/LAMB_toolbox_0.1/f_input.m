function [var] = f_input(message,f_not_null,f_char)
% Input a parater from user entry...
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
%
% ver 1.0    17/12/2008    
% ver 2.0    31/12/2008    Entry of 'char' data type added.


not_ready = 1;
if f_char
    % Detect char entries.
    while not_ready
        var = input(message,'s');
        if (~isempty(var))
            not_ready = 0; 
        else
            fprintf(' Bad value... Please try again :) \n')
        end
    end
elseif f_not_null
    % Detect null user entries..
    while not_ready
        var = input(message);
        if (~isempty(var)) && (var ~= 0) && (~ischar(var))
            not_ready = 0; 
        else
            fprintf(' Bad value... Please try again :) \n')
        end
    end
else
    while not_ready
        var = input(message);
        if ~isempty(var)
            not_ready = 0; 
        else
            fprintf(' Empty value!!... Please try again :) \n')
        end
    end
end


