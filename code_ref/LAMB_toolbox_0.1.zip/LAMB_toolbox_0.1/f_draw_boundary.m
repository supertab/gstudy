function f_draw_boundary(P_field,a2,b2,ang_alfa,ang_beta,ang_gamma,b_color,f_handle)
% Draw boundary lines for a rectangular region with center 'P_field'
% and dimessions: width = a2  and  high = b2.
%            
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
%
% ver 1.0    31/12/2008

a = a2/2;  % Half width.
b = b2/2;  % Half high.

x2_min = P_field(1) - a;   y2_min = P_field(2) - b;
x2_max = P_field(1) + a;   y2_max = P_field(2) + b;
X = [x2_min x2_min x2_max x2_max x2_min]';
Y = [y2_min y2_max y2_max y2_min y2_min;]';
Z = P_field(3)*ones(5,1);



U = X - P_field(1); % translacion de coord. al baricentro del plano de campo (centro de simetria)
V = Y - P_field(2); % Obs. esto es un cambio de coord. x trans de O(0;0;0) --> O'(0';0';0')
W = Z - P_field(3); % Obs.2: O'(0';0',;0') esta situado justo en P_field.

[X,Y,Z] = f_rotate_matrix(U,V,W,ang_alfa,ang_beta,ang_gamma);  % rotar las matrices  U,V y W  del 'plano' en torno a un eje que atraviesa su 'baricentro'.

X = X + P_field(1);   % translacion de coord. del baricentro de la matriz (0';0';0') a .--> del plano de campo (P_field)
Y = Y + P_field(2);   % Obs. esto es un cambio de coord. x trans de O'(0';0';0') --> O(0;0;0).
Z = Z + P_field(3);   % Obs.2: O'(0';0';0') esta situado justo en P_field.




figure(f_handle);  
plot3(X,Y,Z,b_color);




