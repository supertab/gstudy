function [d_delta_a] = f_cal_delta_a_numeric_3(w0,k0,h,alfa,beta)
% This funtion calculates the derivatives of the dispersion functions 
% for straight crested anti-symmetric Lamb wave modes in a free layer.
% Calculation are based on the work : 
%                          "The influence of Finite-Sice Sources in Acousto-Ultrasonics"�
%                    from:  B.N.Pavlakovic & Joseph L. Rose (NASA report. 1994)
% 
% Obs.:      w0 = Vibration angular frequency vector [rad/s].
%            k0 = Wavenumber vector [Rad/m].
%             h = Half plate thickness [m].
%          alfa = Longitudinal bulk wave velocity [m/s].
%          beta = Transversal bulk wave velocity [m/s].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    29/11/2008  Perform numeric derivation from Dimitry Zakharov suggestions.

%--------------------------------------------------------------------------
% Method 3: Very good aproximation to derivative function!!!

        ki = k0;         
   delta_k = k0./10000;
   
      k_tl = sqrt(((w0./alfa).^2) - (k0.^2));      % Longitudinal Lamb wavenumber vector [Rad/m].
      k_ts = sqrt(((w0./beta).^2) - (k0.^2));      % Transversal Lamb wavenumber vector [Rad/m].
 delta_a_i = ((((k_ts.^2) - (k0.^2)).^2).*sin(k_tl.*h).*cos(k_ts.*h)) + ((4.*(k0.^2).*k_tl.*k_ts).*cos(k_tl.*h).*sin(k_ts.*h));
   
        k0 = ki + delta_k;
      k_tl = sqrt(((w0./alfa).^2) - (k0.^2));      % Longitudinal Lamb wavenumber vector [Rad/m].
      k_ts = sqrt(((w0./beta).^2) - (k0.^2));      % Transversal Lamb wavenumber vector [Rad/m].
delta_a_i1 = ((((k_ts.^2) - (k0.^2)).^2).*sin(k_tl.*h).*cos(k_ts.*h)) + ((4.*(k0.^2).*k_tl.*k_ts).*cos(k_tl.*h).*sin(k_ts.*h));

        k0 = ki - delta_k;
      k_tl = sqrt(((w0./alfa).^2) - (k0.^2));      % Longitudinal Lamb wavenumber vector [Rad/m].
      k_ts = sqrt(((w0./beta).^2) - (k0.^2));      % Transversal Lamb wavenumber vector [Rad/m].
delta_a_ii1 = ((((k_ts.^2) - (k0.^2)).^2).*sin(k_tl.*h).*cos(k_ts.*h)) + ((4.*(k0.^2).*k_tl.*k_ts).*cos(k_tl.*h).*sin(k_ts.*h));
   
        k0 = ki - 2*delta_k;
      k_tl = sqrt(((w0./alfa).^2) - (k0.^2));      % Longitudinal Lamb wavenumber vector [Rad/m].
      k_ts = sqrt(((w0./beta).^2) - (k0.^2));      % Transversal Lamb wavenumber vector [Rad/m].
delta_a_ii2 = ((((k_ts.^2) - (k0.^2)).^2).*sin(k_tl.*h).*cos(k_ts.*h)) + ((4.*(k0.^2).*k_tl.*k_ts).*cos(k_tl.*h).*sin(k_ts.*h));

        k0 = ki - 3*delta_k;
      k_tl = sqrt(((w0./alfa).^2) - (k0.^2));      % Longitudinal Lamb wavenumber vector [Rad/m].
      k_ts = sqrt(((w0./beta).^2) - (k0.^2));      % Transversal Lamb wavenumber vector [Rad/m].
delta_a_ii3 = ((((k_ts.^2) - (k0.^2)).^2).*sin(k_tl.*h).*cos(k_ts.*h)) + ((4.*(k0.^2).*k_tl.*k_ts).*cos(k_tl.*h).*sin(k_ts.*h));

%--------------------------------------------------------------------------
% Using a numeric aproximation formula. 
% See ref. book of: "Mathematical Handbook for Scientists and Engineers"
%                    Granino A. Korn & Theresa M. Korn 
%                    Mc Graw Hill; 2nd. Ed. (1968). 
%                    Equation 20.7-9  (page 696).   
 d_delta_a = ( 3.*delta_a_i1 + 10.*delta_a_i - 18.*delta_a_ii1 + 6.*delta_a_ii2 - delta_a_ii3)./(12.*delta_k);
%--------------------------------------------------------------------------

 

                                     
                                     
                                     
        








