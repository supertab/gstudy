function [Nx,Ny,X,Y,z,far_point,ii_far,ii_near] = f_THS_reception_coords(f_cph_mapping,num_p,O,P_field,x_w,y_w,x_s,y_s,f_handle)
% This function returns the coordinates of reception field points where the 
% Lamb wave signals are going to be calculated.
%
%            O = Coordinates of central point on excitation field [m].
%      P_field = Coordinates of central point on reception field [m].
%          x_w = With of reception region in 'X' direction.
%          y_w = In 'Y' direction.
%          x_s = Step distance between points in X axis [m].
%          y_s = In Y axis [m].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    14/01/2008
% ver 2.0    11/12/2008    Use of simplified version of routine: "f_cal_coord_plano_2" (v4.0 ; 11/12/2008).
% ver 2.1    29/12/2008    Added return of field dimension parameters.
% ver 2.2    03/01/2009    Change in name: 'f_cal_reception_coords' -> 'f_THS_excitation_coords' & ext fig. handle.
% ver 2.3    08/01/2009    Elimination of: X = X'; Y = Y'. 1st. X axis points...then 2nd. Y axis points at line 63.
% ver 2.4    15/01/2009    Check of null inter-space parameters (x_s ; y_s) added.
% ver 2.5    18/02/2009    Check for for F-Cph_mapping added.


%------------------------------------------                           
% Determine coordinates of plate vibration field.
if x_s == 0  disp('(o_o) Warning: X-step... x_s = 0 '); disp('      Setting x_s = 1mm');  x_s = 0.001;  end;
if y_s == 0  disp('(o_o) Warning: Y-step... y_s = 0 '); disp('      Setting y_s = 1mm');  y_s = 0.001;  end;
[x,X,Y,Z] = f_cal_coord_plano_2 (P_field,x_w,y_w,x_s,y_s);
%------------------------------------------               
% Check occurance of more than 1 point in reception field for F-Cph_mapping.
if f_cph_mapping
    fprintf(' \n');
    if (max(size(X)) > 1)
        fprintf(' :(  Reception field should not have > 1 point for 3D mapping... \n');  
        error('   Num_points = %i',max(size(X)));
    elseif num_p > 1
        fprintf(' :(  Number of excitation points > 1 in 3D map... \n');  
        error(' ');
    end    
end

%------------------------------------------               
% Plot reception field.
if (min(size(X)) <= 1) || (min(size(Y)) <= 1) ||(min(size(Z)) <= 1)
    if f_handle == 0
        figure(f_handle); set(gcf,'Renderer','zbuffer'); hold on; grid on;
        plot3(X,Y,Z,'b.');
    else
        figure(f_handle); set(gcf,'Renderer','zbuffer');
        plot3(X,Y,Z,'c.'); 
        plot3(X(1),Y(1),Z(1),'b+');
    end
else
    figure(f_handle);                % Dibuja plano obtenido (grafico). Observese como coinciden las coord. de P_field con los ejes de matlab.
    hslice = surf(X,Y,Z);            % Obs. en la 'API' (pantalla del prog.) se debe incluir un grafico que muestre la ubicacio de la apertura y del plano de campo (Ps)
    plot3(X(1,1),Y(1,1),Z(1,1),'ro');
    set(gcf,'Renderer','zbuffer');   
end
%delete(hslice);
%--------------------------------------------------------------------------
% Obtain coordinates of near & farthest points in field "far_point".
     M2 = 0;
     M3 = inf;
[un vn] = size(X);
for i = 1:un
  for j = 1:vn
      M = (X(i,j) - O(1,1))^2  +  (Y(i,j)^2 - O(1,2))  +  (Z(i,j) - O(1,3))^2;  % Cal. la dist. de todos los puntos al Origen del 'Array' (OA)
      if M >= M2
         M2 =  M;  i2 = i;  j2 = j;
      end   
      if M < M3
         M3 =  M;  i3 = i;  j3 = j;
      end   
  end    
end    
 far_point = [X(i2,j2) Y(i2,j2) Z(i2,j2)];
    ii_far = [i2 j2]; % Matrix index for location of far & near points.
   ii_near = [i3 j3];
%near_point = [X(i3,j3) Y(i3,j3) Z(i3,j3)]
                           
%------------------------------------------
z = Z(1)';         % We intentionally omit the matrix and use a single scalar, becouse all 'Z' coord.
                   % are the same belonging to the surface of the plate.
[Nx Ny] = size(X); % Number of points for reception field.
fprintf('     Nx = %i      Ny = %i \n',Nx,Ny);
%------------------------------------------
% Plot central point of reception field.
figure(f_handle); axis equal;
plot3(P_field(1),P_field(2),P_field(3),'r+');
plot3(P_field(1),P_field(2),P_field(3),'bo');




