function [Vs3_4] = f_FRM_add(Nxc3,Nyc3,Vs3_3,Nt,N3)
% This function computes 'the total signal' of the receiving aperture by addition of all element signals.
% Parameters:
%              Nxc3,Nyc3 = Number of receiver elements (X,Y) on reception aperture (array).
%                  Vs3_3 = Vs3_3(Nt,Nxc3,Nyc3,N3) Composed data matrix for 'Nt' angles.
%                     Nt = Number of incident angles.
%                     N3 = Number of points of signals.
%
%
% Output:
%                  Vs3_4 = Vs3_4(N3,Nt) Final array output with NO delays (focalized beam).
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    07/01/2009    Using data from engine: 'f_IRM_main_2D_2v3' v1 (11/12/2008).
% ver 2.0    09/01/2009    Add of incident angle vector 'theta'.
% ver 2.1    29/01/2009    Change of name: 'f_FRM_add_signals' --> 'f_FRM_add'.
% ver 3.0    05/02/2009    Cal. for steering angle vector added.
% ver 4.0    18/12/2009    Simplified version for 'f_FRM_DAS_processor' v1.0

%--------------------------------------------------------------------------
% 3.4 Cal. final array output by adding all element signals!
%disp(' Computing array output by adding signals w/null delay...')

    a = zeros(N3,1);
Vs3_4 = zeros(N3,Nt);  % Final array output matrix for 'Nt' incident & 'Ns' steering angles.
for k = 1:Nt
    for i = 1:Nxc3
        for j = 1:Nyc3
            s(:,1) = Vs3_3(k,i,j,:); % Extract signal from ele(i,j) for steer_ang(l).
                 a = a + s;          % Compute array output by adding all signals for steer_ang(l).
        end
    end
    Vs3_4(:,k) = a;    % Compute array output by adding signals for steer_ang(l).
    a = zeros(N3,1);   % Clear accumulator!
end





