function [i_T0,i_TD] = f_IRMc_time_indexes (N,t,T0,TD)
% Funcion de calculo de los indices min. y max en la trama de tiempo
% 't', dentro de la cual se calcularan las 'alfa_s' y 'h'
%
% ver 1.0    30/07/2004
% ver 2.0    12/11/2004   Optimizacion del codigo, inclusion de: 'if (max(indexs) <= 0)'
% ver 3.0    26/11/2004   Agreg. margen prev. y post. a lo indices hallados,(p/cal. bien los alfa's x las dudas...)
% ver 4.0    28/09/2005   Agreg. de '-1' en linea '22' (i_TD = ...)
% ver 5.0    22/12/2008   Deteccion de [] en linea 21:  "min(find(indexs))".
% ver 5.1    12/01/2009   Change in name: 'f_cal_time_indexes' --> 'f_IRM_time_indexes'.


indexs = zeros(N,1);
margen = 1;  % nro de muestras extras, p/cal. alfa's fuera de los limites 'i_T0' e 'i_TD'

for i=1:N
      if (T0 <= t(i)) && (t(i) <= TD)
         indexs(i) = i;   % indices corresp. ala ventana de calculo de los 'alfas'
      end    
end

if isempty(min(find(indexs)))
    i_T0 = margen;   % indice de 't' corresp. a T0
else
    i_T0 = min(find(indexs));    % indice de 't' corresp. a T0
end    
i_TD = max(indexs) + margen - 1; % indice de 't' corresp. a TD


% Obs. si luego hubiera algun error, no olvidar que es xque 'i_T0' o
% 'i_TD', se salen de los limites de los indices del vector de muestras: '1' y 'N'
%
% if (i_T0) <= 0)
%     i_T0 = 1;      % prevencion de ventana de calculo de los alfa's no nula  
% end    





