function [h] = f_IRMc_h_IV_opt (i_T0,i_TD,N,t,TA,TB,TC,TD,Tmin, alfa_1,alfa_2,alfa_3,alfa_4, alfa_r_1,alfa_r_2,alfa_r_3,alfa_r_4)
% Funcion de computo de 'h(x,y,z,t)' en la zona 'IV'
% 
% ver  6.0-8.0
% ver  9.0    30/07/2004   Funcion optimizada. Calculo de 'h' dentro de la ventana T0-TD)
% ver 10.0    15/10/2004   Uso de la funcion original del paper p/h(i) caso I
% ver 10.1    28/01/2008   Uso de vectores columna p/'h'.
% ver 10.2    12/01/2009   Change in name: 'f_cal_h_IV_opt' --> 'f_IRMc_h_IV_opt'.


Tm = min(TB,TC);
TM = max(TB,TC);
 h = zeros(N,1);

for i = i_T0:i_TD
    if (Tmin < t(i)) && (t(i) < TA)      % caso I, zona IV
       % Se ha tomado los val. abs. de alfa_r_1 y alfa_r_2 y cambiado de signo sus terminos.
       %h(i) = -2*pi + 2*abs(alfa_r_1(i)) + 2*abs(alfa_r_2(i)) + 2*alfa_r_3(i) + 2*alfa_r_4(i);  % F. corregida x Mi...?
       h(i) = -2*pi - 2*alfa_r_1(i) - 2*alfa_r_2(i) + 2*alfa_r_3(i) + 2*alfa_r_4(i);  % F. Original
         
    elseif (TA <= t(i)) && (t(i) <= Tm)
       h(i) = -3*pi/2 - alfa_1(i) - alfa_2(i) + 2*alfa_r_3(i) + 2*alfa_r_4(i);
          
    elseif (Tm < t(i)) && (t(i) <= TM) && (TB <= TC)
       h(i) = -pi - alfa_1(i) + alfa_3(i) + 2*alfa_r_4(i);

    elseif (Tm < t(i)) && (t(i) <= TM) && (TC < TB)
       h(i) = -pi - alfa_2(i) + 2*alfa_r_3(i) + alfa_4(i);
          
    elseif (TM < t(i)) && (t(i) <= TD)
       h(i) = -pi/2 + alfa_3(i) + alfa_4(i);
    end
end      

if 2*pi < max(h)
%   f_pichichitus(8192);
   disp('Cuidado!  "h" alcanza  "2*pi"  en: "f_IRM_h_IV_opt"... ');
   pause
end

