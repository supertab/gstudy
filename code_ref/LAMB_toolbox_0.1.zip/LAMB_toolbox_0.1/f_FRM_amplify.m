function [Vs3_2] = f_FRM_amplify(Nxc3,Nyc3,Vs3_2,Nt,N3,Amp_gain,n_level,n_type,f_FRM_taper)
% This function adds white-Gaussian noise to signals received by the aperture elements.
% Parameters:
%              Nxc3,Nyc3 = Number of receiver elements (X,Y) on reception aperture (array).
%            Xc3,Yc3,Zc3 = Receiving elements center's coordinates.
%                  Vs3_2 = Vs3_2(Nt,Nxc3,Nyc3,N3) Final (composed & converted) array signals.
%                     N3 = Number of points of signals.
%               Amp_gain = FRM gain-amplifier factor [dB].
%                n_level = If > 0 Add fixed white Gaussian 'noise_level' to FRM signals in [W] @R_load = 1ohm.
%                          [] -> Do not.
%                 n_type = 'fix' -> Add fix amount of power.
%                          'ref' -> Use maximun signal to measure power.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    24/02/2009
% ver 2.0    28/02/2009     'Amp_gain' parameter added.
% ver 2.1    28/12/2009     Change in noise model additon.
% ver 2.2    07/01/2010     Code simplyfied + add new noise model.

%--------------------------------------------------------------------------
% 3.2.3 Add noise & amplify composed signals.
s = zeros(1,N3);
n = zeros(1,N3);
A = 10^(Amp_gain(1)/20);   % Cal. amplification factor.

if A > 1
    fprintf(' :)  Amp_gain = %.2f \n',A);
elseif A == 1
    fprintf(' :|  Amp_gain = %i  No amplification selected\n',A);
elseif A < 1
    disp(' (o_o) Warning: "Amp_gain" parameter is acting as an attenuator... ');
    fprintf(' :(  Amp_gain = %.2f \n',A);
else
    fprintf(' :( Error: wrong value of A_factor = %f',A);
    error(' ');
end
%----------------------------------------------------------------------
% Detect negative polarity for amplifier.
if ~isempty(Amp_gain(2)) 
    if Amp_gain(2) < 0     
        disp('3.2.3.a Inversion detected... Multipliying signals by -1')
        A = -A;
    end
end

%----------------------------------------------------------------------
if ~isempty(n_level)
    %-----------------------------------------------
    fprintf('3.2.3 Amplifying + WG-noise ')    
    for k = 1:Nt
        fprintf('@fix level = %.1f pW\n',n_level*10^12);
        if strcmp(n_type,'fix')
       n_level_dB = 10*log10(n_level); % Here 'n_level' is expressed in [W].
            for i = 1:Nxc3
                for j = 1:Nyc3
                    s(1,:) = Vs3_2(k,i,j,:);
                    % Elementary noise model of an OPA:  
                    % (signal + noise-sources)*G_ideal
                    s = s + wgn(1,N3,n_level_dB);  % ->  s = s + n;
                    Vs3_2(k,i,j,:) = s*A;
                end
            end
        else
            %-------------------------------------------
            % Detect maximum signal power.
                V32(:,:) = Vs3_2(k,:,round(Nyc3/2),:);
                 [mm,ii] = max(max(V32'));
                   s_ref =  Vs3_2(k,ii,round(Nyc3/2),:);  % Array's maximum signal.
               ref_power = sum(abs(s_ref(:)).^2)/length(s_ref(:));
                     SNR = 10^(n_level/10); % It is assumed that 'n_level' is expressed in [dB].
            fprintf('@ref level = %.1f pW\n',ref_power*10^12);
            %-------------------------------------------
            for i = 1:Nxc3
                for j = 1:Nyc3
                    s(1,:) = Vs3_2(k,i,j,:);
                    s = awgn(s,SNR,ref_power,'linear');   % ->  s = s + n;
                    % sigPower = sum(abs(sig(:)).^2)/length(sig(:));
                    Vs3_2(k,i,j,:) = A*s;
                end
            end
        end
    end
    %-----------------------------------------------
else
    %-----------------------------------------------
    if abs(A) > 1
        disp('3.2.3.b  Amplifying composed signals...')
        for k = 1:Nt
            for i = 1:Nxc3
                for j = 1:Nyc3
                    s(1,:) = Vs3_2(k,i,j,:);
            Vs3_2(k,i,j,:) = A*s;
                end
            end
        end
    end
    %-----------------------------------------------
end

%----------------------------------
% Use tapered beamformer?
if f_FRM_taper % Yes
    disp('3.2.3.c Using Hamming tapered beamforming...')
     h = hamming(Nxc3);
    % disp('3.2.3.c Using tapered beamforming: Chebyshev -40dB')
    %h = chebwin(Nxc3,40);
    for k = 1:Nt
        n = 1;
        for i = 1:Nxc3
            for j = 1:Nyc3
                Vs3_2(k,i,j,:) = h(n)*Vs3_2(k,i,j,:);                
            end
            n = n + 1;
        end
    end
else % No, use match filter. 
    disp('3.2.3.c Using common match filter -> no tappering...')
%    h = (1/sqrt(Nxc3))*ones(Nxc3,1);  % Normalization factor =    1/sqrt(num_elements).
end

