function [Ps_energy] = f_cal_Ps_energy(Z0,theta,Ps,x,y,axis_font)
% Extract energy feature from a given acoustic field data set 'Ps'.
% Obs.:
%            Z0 = c*ro Is the air characteristic impedance in [N.s/m^3] or [Rayls].
%         theta = Correspondance incidence angle [Deg].
%            Ps = IRM data cell array:  Ps = zeros(Nx3,Ny3,N3);
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    21/12/2008
% ver 2.1    15/01/2009    Corr. of energy calculation by adding air characteristic impedance.


disp('2. Calculating signal,s energy...');

[xs ys N] = size(Ps);
if N > 1
    %----------------------------------------------------------------------
    % Detection in 3D matrix.
    Ps_energy = zeros(xs,ys);
    s = zeros(N,1);
    for i = 1:xs
        for j = 1:ys
            % Remember, the root-mean-square value (RMS) is: RMS = norm(x)/sqrt(n).
            s(:,:) = Ps(i,j,:);
            Ps_energy(i,j) = (norm(abs(s))^2)/(Z0*N); % Then the energy is: E = ps*v [J]   ; v = ps/Z0
        end
    end
    if (x(1) ~= 0) && (y(1) ~= 0)
        text(x,y,max(max(Ps_energy)),['Power [W] @',num2str(theta),'�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',axis_font);
    end
else
    %----------------------------------------------------------------------
    % Detection in 2D matrix.
    [nro_s,N] = size(Ps);
    Ps_energy = zeros(nro_s,1);
    for i = 1:nro_s
        Ps_energy(i,1) = (norm(abs(Ps(i,:)))^2)/(Z0*N); % Then the energy is: E = ps*v [J]   ; v = ps/Z0
    end
    if (x(1) ~= 0)
        [y,ii] = max(Ps_energy);
        text(x(ii),y,['Power [W] @',num2str(theta),'�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',axis_font);
    end
end




