function [h] = f_IRMc_h_II_opt (i_T0,i_TD,N,t,TA,TB,TC,TD,Tmin, alfa_1,alfa_2,alfa_3, alfa_4,alfa_r_4)
% Funcion de computo de 'h(x,y,z,t)' en la zona 'II'
% 
% ver  6.0-8.0
% ver  9.0    30/07/2004   Funcion optimizada. Calculo de 'h' dentro de la ventana T0-TD)
% ver  9.1    28/01/2008   Uso de vectores columna p/'h'.
% ver 10.0    29/01/2008   Resuelto caso:  'TC < TB'
% ver 10.1    12/01/2009   Change in name: 'f_cal_h_II_opt' --> 'f_IRMc_h_II_opt'.


Tm = min(TB,TC);
TM = max(TB,TC);
 h = zeros(N,1);

for i= i_T0:i_TD
      if (Tmin < t(i)) && (t(i) < TA)
          h(i) = pi - 2*alfa_2(i);
          
      elseif (TA <= t(i)) && (t(i) <= Tm)
          h(i) = pi/2 - alfa_1(i) - alfa_2(i);

      elseif (Tm < t(i)) && (t(i) <= TM) && (TB <= TC)
          h(i) = -pi - alfa_1(i) + alfa_3(i) + 2*alfa_r_4(i);
          
      elseif (Tm < t(i)) && (t(i) <= TM) && (TC < TB)
          h(i) = alfa_4(i) - alfa_2(i);
          
      elseif (TM < t(i)) && (t(i) <= TD)
          h(i) = -pi/2 + alfa_3(i) + alfa_4(i);
      end
end      

