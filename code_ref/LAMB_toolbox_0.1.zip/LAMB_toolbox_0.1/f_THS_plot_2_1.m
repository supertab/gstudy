function [u,v,U,V] = f_THS_plot_2_1(num_modes,N,fs,t,S_z,theta_index,a,p_max,f_title,axis_font,f_delete_figs,f_pause)
% Plot features for:  2.1) Single reception point at 1 incidence angle :)
% Parameters:
%      num_modes = Number of Lamb waves modes simulated.
%              N = Number of points in signal traces.
%             fs = Sampling frequency [Hz].
%              t = Signal's temporal axis [s].
%            S_z = THS data cell array:  S_z = cell{Nt,num_modes}(Nx,Ny,N);
%    theta_index = 1 -> Plot data for only 1signal @ 1 theta angle.
%              a = Radius of excitation 'points' [m].
%          p_max = Maximun excitation pressure [Pa].
%        f_title = 1 -> Activate title plot.          0 -> Do not.
%      axis_font = Title & axis font size.
%  f_delete_figs = 1 -> Deletes figures before quit.  0 -> Do not delete figures.
%        f_pause = 1 -> Activate program pause.       0 -> Do not.
%          theta = Plane wave incidence angle vector [Deg].
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    02/12/2008
% ver 1.1    11/12/2008     Delete figures flag added.
% ver 1.2    17/02/2009     Inter program 'f_pause' added.


disp('1.4.2.1. Single reception point with 1 incidence angle :)')
[u] = f_THS_compose_total_signal(num_modes,N,S_z,theta_index,1,1);
% color = [0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0];
% line = ['-';'-';'-';'-';'-';'-';':';':';':';':';':';];
% plot(t,m); drawnow;
% h2 = findobj(h);  set(h2(3),'Color',color(j,:),'LineStyle',line(j,:));

%---------------------------------
% Calculate velocity signal w/spectrum.
[U,F] = f_cal_spectra(fs,u);
    v = fs*diff(u);
    v = [v; 0];
[V,F] = f_cal_spectra(fs,v);
%---------------------------------        
% Plotting:
% 2.1.1. Displacement signal.
figure(21000); hold on; grid on; set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
if f_title     title(['Vertical displacement signal @p-max = ',num2str(p_max),'Pa;',' a = ',num2str(a*1000),' mm'],'FontSize',f_title); end;
xlabel('t [s]','FontSize',axis_font);   ylabel('u_z [m]','FontSize',axis_font); 
plot(t,u,'r'); 


figure(21002); hold on; grid on; set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
if f_title     title(['Displacement signal amplitude spectrum @p-max = ',num2str(p_max),'Pa;',' a = ',num2str(a*1000),' mm'],'FontSize',f_title); end;
xlabel('f [Hz]','FontSize',axis_font);  ylabel('Normalized amplitude','FontSize',axis_font); 
plot(F,U(:,1)/max(U(:,1)),'r');  plot(F,U(:,1)/max(U(:,1)),'r.');

% 2.1.2. Velocity signal.
figure(21003); hold on; grid on; set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
if f_title     title(['Velocity signal @p-max = ',num2str(p_max),'Pa;',' a = ',num2str(a*1000),' mm'],'FontSize',f_title); end;
xlabel('t [s]','FontSize',axis_font);   ylabel('v_z [m/s]','FontSize',axis_font);
plot(t,v,'b'); 

figure(21004); hold on; grid on; set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
if f_title     title(['Velocity signal amplitude spectrum @p-max = ',num2str(p_max),'Pa;',' a = ',num2str(a*1000),' mm'],'FontSize',f_title); end;
xlabel('f [Hz]','FontSize',axis_font);  ylabel('Normalized amplitude','FontSize',axis_font); 
plot(F,V(:,1)/max(V(:,1)),'b');


%--------------------------------
if f_delete_figs && f_pause
    pause;  
    delete(figure(21000));  delete(figure(21002));  delete(figure(21003));  delete(figure(21004));
elseif f_delete_figs
    delete(figure(21000));  delete(figure(21002));  delete(figure(21003));  delete(figure(21004));
end


