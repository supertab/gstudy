function [S] = f_extract_spectrum_2(num_modes,F,K,nro_s,Ps_signals,fs_data,fs_data,f_min,f_max,f_s)
% This funtion calculates the spectrum (amplitude & phase),
% for the 'nro_s' points in the excitation zone. 
% It asumes that points are linearly arranged and approximatly centered 
% with the maximum of the excitation profile.
% 
% Obs.:   
%       num_modes = Number of Lamb modes being excited.
%           nro_s = Number of excitation points (signals).
%               F = Frequency cell array for Lamb modes.
%               K = Wavenumber cell array for Lamb modes.
%      Ps_signals = Acoustic pressure signal's matrix for the excitation profile.
%         fs_data = Data sampling frequency [Hz].
%
%               S = Specturm cell array; composed of 'm' sub-matrixes: [amplitude phase];
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    29/11/2007


   Ns = min(size(Ps_signals))    % Number of points in excitation pattern.
    S = cell(nro_s);             % Final excitation spectrum cell array.
 flag = 1; 
for n = 1:n_p
    if flag
        if f_is_odd(Ns,2)
            i = ((Ns-1)/2) - round(n_p/2) + round(n/2) + 1;    % Starting point in input pattern.
        else
            i = (Ns/2) - round(n_p/2) + round(n/2) + 1;
        end
        flag = 0;
    end
    Ps_points(n,1) = i;    
   [S2,f2] = f_cal_spectra(fs,Ps_signals(:,i));   % Extract const. pressure spectrum for point 'n'.
%------------------------  
 s = Ps_signals(:,21);
 N = max(size(s))
 E = (1/N)*sum((abs(s)).^2)

E3 = (1/N)*sum((abs(S2(:,1))).^2)
 r = E3/E  
%------------------------  
    for m = 1:num_modes 
           P = zeros(N0(m),2);
          F0 = W0{m}/(2*pi); 
                    
      P(:,1) = interp1(f2,S2(:,1),F0,'spline');  % Interpolate Amplitude spectrum.
      P(:,2) = interp1(f2,S2(:,2),F0,'spline');  % Interpolate Phase spectrum.
      S{m,n} = P;   % Save spectrum for mode 'm' at point 'n'.
    end    
    i =  i + 1;     % Increase pointer to next pressure point.
end

Ps_points







