function [d_x] = f_diff_mp(N,x)
% Manual differentiation of a vector of 'mp' type class.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    18/07/2008   

mp_dontmakeall = {'N','n'};
mp_makeall

  d_x = mp(zeros(N-1,1));
for n = 3:N
    d_x(n-1) = x(n) - x(n-2);
end



