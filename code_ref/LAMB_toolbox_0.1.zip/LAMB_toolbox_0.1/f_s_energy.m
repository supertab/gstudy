function [Signal_energy] = f_s_energy(E_const,theta,Signal,x,y,f_handle,axis_font)
% Extract energy feature from a given "column" matrix of signals:  'Signal'.
% Obs.:
%             h ~ 0 -> Plot feature labels.
%             h = 0 -> Do not plot.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    05/02/2009


%disp('x.2 Calculating signal,s energy...');

[xs ys N] = size(Signal);
if N > 1
    %----------------------------------------------------------------------
    % Detection in 3D matrix.
    Signal_energy = zeros(xs,ys);
        s = zeros(N,1);
    for i = 1:xs
        for j = 1:ys
            % Remember, the root-mean-square value (RMS) is: RMS = norm(x)/sqrt(n).
                        s(:,:) = Signal(i,j,:);
            Signal_energy(i,j) = (norm(s)^2)/(E_const*N); % Cal. energy of signal.
        end
    end
    if f_handle
        text(x,y,max(max(Signal_energy)),['Energy [J] @',num2str(theta),'�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',axis_font);
    end
else
    %----------------------------------------------------------------------
    % Detection in 2D matrix.
        [N,nro_s] = size(Signal);
    Signal_energy = zeros(nro_s,1);
    for j = 1:nro_s
        Signal_energy(j,1) = (norm(Signal(:,j))^2)/(E_const*N); % Cal. energy of signal.
    end
    if f_handle
        [y,ii] = max(Signal_energy);
        text(x,y,[num2str(theta),'�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',axis_font);
    end
end




