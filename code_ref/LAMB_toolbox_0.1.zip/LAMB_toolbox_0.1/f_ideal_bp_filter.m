function [s_fil] = f_ideal_bp_filter(s,f_min,f_max,fs,f_quiet)
% This function applies an ideal Band-pass filtering to
% a given signal 's' sampled at 'fs' Hz.
% The low and high frequencies of the filter are: 'f_min' y 'f_max' respectively.
% Obs.: Signals in 's' are assumed to be by columns.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   10/02/2005
% ver 2.0   31/11/2007    Change fft of 'N' points to -> fft of '2N' points 
%                         to avoid circular convolutions!!
% ver 3.0   03/12/2007    Frequency vector and filtered spectrum corrected!!!
% ver 3.1   06/04/2008    Detection of empty frequency vector indexs.
% ver 3.2   17/08/2008    Correction in location indexs f3 & f4 by 1 sample to -> fs.
% ver 3.3   29/12/2008    Quiet flad added.
% ver 3.4   15/01/2009    Non filtering condition detection (f_max <= f_min) added.


if (f_min < f_max)
    %--------------------------------------------------------------------------
     [N1,nro_s] = size(s);
              N = 2*N1;                  % Increase signal longitude to avoid circular convolutions 
                                         % (zero padding).
              y = zeros(N,nro_s);        % Output matrix of filtered signals.
     %------------------------------------------ 
     % 1. Create ideal band-pass filter response.
             H = zeros(N,nro_s);
             f = (0:N-1)'*(fs/N);        % Define frequency vector
      index_f1 = find(f >= f_min);       % Find index in vector 'f' correspondig to 'f_min'.
      index_f2 = find(f > f_max);        % The same for 'f_max'.
      index_f3 = find(f > fs - f_min);   % The same for 'f_min' image.
      index_f4 = find(f >= fs - f_max);  % The same for 'f_max' image.
      
      if isempty(index_f1) || isempty(index_f2) || isempty(index_f3) || isempty(index_f4)
          disp(' :(  Error: filter window not properly set up.'); disp(' Try to:');
          disp(' 1) Increase "fs" ');
          disp(' 2) Increase the number of points of signal "N"');
          disp(' 3) Reduce filtering BW.'); disp(' ');  error(' ');
      end 
      H(index_f1(1):index_f2(1)-1,:) = 1; % Create ideal response between frequencies.
      H(index_f4(1):index_f3(1)-1,:) = 1;  
      
     %------------------------------------------ 
     % 2. Compute filtered signals matrix 'y'.
          S = fft(s,N,1);               % Compute matrix signal's 'fft' @Npoints by columns.
          Y = H.*S;                     % Filter signal's spectrum.
      s_fil = real(ifft(Y,N,1));        % Compute time domain filtered signal.
      s_fil = s_fil(1:N1,:);            % Discard added points.        
     %------------------------------------------ 
     % 3. Parseval theorem check.
      E_fil = sum((abs(s_fil)).^2,1);   % Energy of output signals.
          E = sum((abs(s)).^2,1);       % Energy of input signals.
      if E == 0 
          E = 1;      
      end
      
E_fil_ratio = (E_fil./E)';
      if ~f_quiet
          fprintf(' E_fil_ratio = %.2f \n',E_fil_ratio);
      end
     %--------------------------------------------------------------------------
else
    disp('(o_o) Warning Filter not applied... ');
    fprintf('      f_min = %.1f HMz  &  f_max = %.1f HMz \n',f_min/10^6,f_max/10^6);
    s_fil = s;
end

