function [x,y] = f_cal_ellipse(O,a,b,delta_theta)
%  This function computes the coordinates points of an ellipse of major semi-axis 'a';
% and minor semi-axis 'b' for a given angle 'theta'.
%
%       O[x y] = Coordinates of center [m].
%            a = major semi axis [m]. 
%            b = minos semi axis [m].
%  delta_theta = polar angle increment [Deg.].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    08/01/2008
% ver 2.0    Simplified version.

if (a > 0) && (b > 0) && (delta_theta > 0)
    theta = (0:delta_theta:360)';
  theta_r = (pi/180)*theta;
        x = O(1) + a*cos(theta_r);
        y = O(2) + b*sin(theta_r);
else
    error('Error: Ellipse negative parameter  "f_cal_ellipse"...')
end
