function [x,X,Y,Z,Nx,Ny,num_p,num_s,num_p_s,boundary] = f_cal_plano_campo (r_type,a,O_TC,ele_order,D,P_field,uw,vw,us,vs,ang_alfa,ang_beta,ang_gama,R,phi,psi,f_handle)
% Funcion que calcula las coordenas transformadas de los puntos pertenecientes a una region 
% de campo: 'plano', 'linea', 'punto', 'reg. cicular'.
% Parte de la region generada: [X,Y,Z]; para luego rotarla de acuerdo a los angulos: 
% alfa, beta y gama correspondientes a giros en torno a los ejes X,Y y Z respectivamente.
% Parametros:
%                      r_type = Region type
%                               0. Conventional "rectangular" regions; this include: single point; line and plane.
%                               1. Square/Rectangular circle filled.
%                               2. Circular/Ellipse circle filled.
%
%                          a = Radio d/sub-reg. de llenado "puntos" [mm].
%                       O_TC = Centro del Tranductor Circular (TC) [x,y,z].
%                          D = Diametro del TC [mm].
%                   P_field  = Punto central de la regio de campo [x y z].
%                  ang_alfa  = Angulo de rotacion respecto al eje 'X' [�Deg.]
%                  ang_beta  = Angulo de rotacion respecto al eje 'Y' [�Deg.]
%                  ang_gama  = Angulo de rotacion respecto al eje 'Z' [�Deg.]
%
% Obs. Solo p/region rectangular:
%                        uw  = Ancho del plano [mm].
%                        vw  = Alto  del plano [mm].
%                        us  = Paso entre puntos d/grilla s/'Ancho' [mm].
%                        vs  = Idem 'Alto' [mm].
%            
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
% 
% ver 1.0    01/02/2008
% ver 2.0    13/12/2008   Shell type regions added (cylindrical & spheric).
% ver 2.1    26/12/2008   Elimination of returning P_near,P_far.
% ver 2.2    03/01/2009   Not plotting coords added if handle = 0.
% ver 2.3    29/11/2009   Switch plot capability: on/off if required added.
% ver 3.0    27/11/2009   Adaptation for LAMB program ver 0.1 'ele_order' parameter added.


 R_field = 0;
boundary = 0;
if ((r_type ~= 0) && (a == 0))
        a
    r_type
    fprintf('Error: Incompatible "a" value with "r_type" zone...')
    error(':( ');
end
%--------------------------------------------------------------------------
switch(r_type)
    case 0 
        %------------------------------------------------------------------
        % 0. Region de rectangular convencional (rellenado p/rectangulos).
        [x,U,V,W] = f_cal_coord_plano_2(P_field,uw,vw,us,vs);
        [num_s num_p_s] = size(V);
                  num_p = num_s*num_p_s;
    case 1
        %------------------------------------------------------------------
        % 1. Region rectangular, rellenado p/circulos de radio 'a'.
        [x,U,V,W,num_p,num_s,num_p_s] = f_gen_rect_grid(P_field,uw,vw,a,f_handle); 
        % Plot boundary
        boundary = [uw/2 vw/2 P_field(3); -uw/2 vw/2 P_field(3); -uw/2 -vw/2 P_field(3); uw/2 -vw/2 P_field(3); uw/2 vw/2 P_field(3)];
        if f_handle > 0
            figure(f_handle);
            plot3(boundary(:,1),boundary(:,2),boundary(:,3),'r')
        end
    case 2
        %------------------------------------------------------------------
        % 2. Region circular/eliptica, rellenado p/circulos de radio 'a'.
                    Rx = uw/2;
                    Ry = vw/2;
        [x,U,V,W,num_p,num_s,num_p_s] = f_cal_coord_plano_3(P_field,Rx,Ry,a,f_handle);
    case 3
        %------------------------------------------------------------------
        % 3. Shell type region!
        [x,U,V,W,num_u,num_v] = f_cal_coord_shell(ele_order,P_field,R,phi,psi,uw,vw,us,vs);        
                        num_s = num_u;
                      num_p_s = num_v;
                        num_p = num_s*num_p_s;
    otherwise
        disp('Error: "r_type" value unrecognized in "f_cal_plano"');
        error(':( ');
end
[un vn] = size(U);

%--------------------------------------------------------------------------------
%--------------------------------------------------------------------------------
if (min(size(U)) <= 1) || (min(size(V)) <= 1) || (min(size(W)) <= 1)
    surf_flag = 0;
    if f_handle > 0
        figure(f_handle); hold on; grid on;
        plot3(U,V,W,'b.')
    end
else
    surf_flag = 1;                              % Se esta usando una superficie...activar flag!
    if f_handle > 0
        figure(f_handle); hold on; grid on;
           hslice = surf(U,V,W,'tag','S1');     % Obs. en la 'API' (pantalla del prog.) se debe incluir un grafico que muestre la ubicacion de la apertura y del plano de campo.
    end                                         % Ademas asigna el nombre 'S1' a la 1er. superficie ploteada.
end
%--------------------------------------------------------------------------------
% Plot TC if any...
if D > 0 
          R = D/2;        % Radio del TC. 
    [xc,yc] = f_cal_circle([O_TC(1) O_TC(2)],R,100);
         zc = zeros(max(size(xc)),1);
    if f_handle > 0
        figure(f_handle); set(gcf,'Renderer','zbuffer');
        plot3(xc,yc,zc,'k');
        plot3(O_TC(1),O_TC(2),O_TC(3),'r+');
        plot3(O_TC(1),O_TC(2),O_TC(3),'bo');
    end
end
%delete(hslice);
%--------------------------------------------------------------------------------
% Rotacion del plano s/angulos 'alfa', 'beta' y 'gama' corresp. a los ejes 'X', 'Y' y 'Z'
U = U - P_field(1,1); % translacion de coord. al baricentro del plano de campo (centro de simetria)
V = V - P_field(1,2); % Obs. esto es un cambio de coord. x trans de O(0;0;0) --> O'(0';0';0')
W = W - P_field(1,3); % Obs.2: O'(0';0',;0') esta situado justo en P_field.

[X,Y,Z] = f_rotate_matrix(U,V,W,ang_alfa,ang_beta,ang_gama);   % rotar las matrices  U,V y W  del 'plano' en torno a un eje que atraviesa su 'baricentro'.

X = X + P_field(1);   % translacion de coord. del baricentro de la matriz (0';0';0') a .--> del plano de campo (P_field)
Y = Y + P_field(2);   % Obs. esto es un cambio de coord. x trans de O'(0';0';0') --> O(0;0;0).
Z = Z + P_field(3);   % Obs.2: O'(0';0';0') esta situado justo en P_field.

if surf_flag == 0
    if f_handle > 0
        plot3(X,Y,Z,'g.')
        if R_field 
            [xc,yc] = f_cal_circle([0 0],R_field,100);
                 zc = zeros(max(size(xc)),1);
         [xc,yc,zc] = f_rotate_matrix(xc,yc,zc,ang_alfa,ang_beta,ang_gama);   % rotar 
                 xc = xc + P_field(1);       % Translacion de coord. del baricentro de la matriz (0';0';0') a .--> del plano de campo (P_field)
                 yc = yc + P_field(2);  
                 zc = zc + P_field(3);  
                 plot3(xc,yc,zc,'g')
        end
    end
else
    if f_handle > 0
        figure(f_handle);                % Dibuja plano de campo obtenido. Observese como coinciden las coord. de P_field con los ejes de matlab.
        hslice = surf(X,Y,Z,'tag','S2'); % Obs. en la 'API' (pantalla del prog.) se debe incluir un grafico que muestre la ubicacion de la apertura y del plano de campo.
    end                                  % Ademas asigna el nombre 'S2' a la 2da. superficie ploteada.
end

%----------------------------------
[Nx Ny] = size(X); % Number of points for reception field.

%pause
if f_handle > 0
    delete(findobj(f_handle,'Tag','S1')); % Delete 1st. non rotated surface :)
end
% delete(hslice);       % borrar grafico
