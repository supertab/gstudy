function [s_d] = f_delay_signal(fs,N,delay,s,f_quiet)
% This fucntion delays a given signal 's' in 'delay' seconds.
% Obs: 
%  The minimum delay step is  Td = 1/fs
%                             fs = Signals sampling frequency [Hz].
%                              N = Number of points in signal 's'.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   29/06/2005
% ver 2.0   11/12/2005    Negative delay added.
% ver 3.0   03/12/2007    English version!
% ver 3.1   26/02/2008    Change in maximum delay limit.
% ver 3.2   29/12/2008    Quiet flad added.
% ver 3.2.1 14/01/2010    Change  N-i_max -> N-N/2+1

%--------------------------------------------------------------------------
% Change signal format to rows if not.
[N1,N2] = size(s);
if N1 <= N2
    N1 = N2; 
     s = s';  
end
%--------------------------------------------------------------------------
[s_max i_max] = max(s);
if delay ~= 0
        s_d = zeros(N,1);
    n_delay = round(fs*delay);  % nro. de muestra que mas se aproxima al delay deseado
    if delay > 0   
        %------------------------------------------------------------------
        % Positive delay --> 'delay signal'
        if n_delay < N-N/2+1   % N - i_max
            s_d(n_delay+1:N) = s(1:N-n_delay);
            if (imag(N) > 0) || (imag(n_delay) > 0)
                imag(N)
                imag(n_delay)
            end
        else
            N
            n_delay
            i_max
            figure(4444); hold on; grid on; plot(s);
            disp(':(   The delay time has ritched maximum limit: "N - i_max"');
            error(' ');
        end
        if ~f_quiet, fprintf('Delaying signal: t_d = %.2f us',n_delay*10^6/fs); end;
     else    
        %------------------------------------------------------------------
        % Negative delay --> 'advance signal'
        n_delay = abs(n_delay);
        if n_delay == 0
            s_d = s;
        elseif  n_delay < N-N/2+1
            s_d(1:N-n_delay+1) = s(n_delay:N);
        else
            n_delay
            disp('Error: The delay time has ritched the maximum allowed limit: "N - N/2 + 1"');  
            error(' ');
        end
        if ~f_quiet, fprintf('Advancing signal: t_d = %.2f us',-n_delay*10^6/fs); end;
    end
else
    s_d = s; %  disp('Signal not delayed...')
    if ~f_quiet
        disp('Warning: signal delay = 0. Nothing to do!')
    end
end


%   figure(2)
%   plot(s)
%   hold
%   grid
%   plot(s,'g.')
%   plot(s_d,'r')
%   plot(s_d,'k.')
% N

