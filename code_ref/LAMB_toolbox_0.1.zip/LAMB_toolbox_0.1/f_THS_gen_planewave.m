function [Ps] = f_THS_gen_planewave(c,theta,N,f0,f_min,f_max,fs,t,p_max,x,s_type,s_delay,n_burst,q_flag)
% This function constructs an ideal 1D-profile plane wave limited beam (PWLB) 
% of acoustic field. It uses signal 's' as the generating pattern for their delayed 
% replicas according to the inclination angle 'theta'.
% The limited linear profile is spatially located through axis 'x'.
% Obs.:
%            c  =  Velocity of acoustic signal eg. air @21�C: 343.81 [m/s].
%        theta  =  PW deflection angle [Deg�].
%            N  =  Number of points in signal traces.
%        f_min  =  Inferior BW-frequeny limit for integration [Hz].
%        f_max  =  Superior BW-freq. limit [Hz].         
%           f0  =  Signal's main frequency [Hz].
%           fs  =  Sampling frequency [Hz].
%            t  =  Signal's temporal axis [s].
%        p_max  =  Maximun excitation pressure [Pa].
%            x  =  Coordinates of beam location [m].
%       s_type  =  Signal excitation type.
%       s_delay =  Initial commonn delay time for excitation signals [s].
%      n_burst  =  Number of cicles in burst-type signal (only used w/burst signals).
%       q_flag  =  No-delay warning flag.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    03/12/2007
% ver 1.1    11/01/2008     Zero phase (x_ref) parameter added.
% ver 2.0    04/02/2008     Re-structuration for loading excitation field (s_type = 0).
% ver 2.1    20/02/2008     Avoid '0' delay time better defined.
% ver 2.2    21/02/2008     Continuous phase delay for sinus type signals added.
% ver 2.3    14/04/2008     Added 'n_burst' parameter.
% ver 2.4    08/05/2008     Added 't' parameter.
% ver 2.5    17/08/2008     Fix delay added to signals to improve filtering process.
% ver 3.0    02/12/2008     Check Plane wavefront possibility added (1/fs step).
% ver 3.0.1  29/12/2008     Elimination of unnecessary info. messages.
% ver 3.1    16/01/2009     Change in function name: 'f_gen_planewave' -> 'f_THS_gen_planewave'.
% ver 3.2    27/02/2009     's_delay' parameter added.


if isempty(theta) || isnan(theta)
    theta
    disp(' :(   "theta" vector is empty!!'); error(' ');
end
%--------------------------------------------------------------------------
% Re-define wavefront location.
     Nx = max(size(x));
  x_ref = min(x);             % Zero phase reference coordinate [m].
theta_r = theta*(pi/180);
if abs(x_ref) > 0
      x = abs(x_ref) + x;     % Redefine 'x' axis so '0' delay corresponds 2 'x_ref' value.
else
      x = max(x)+x;           % Redefine 'x' axis so '0' delay corresponds 2 minimum 'x' value (negative coord eg. -0.01 m).
end
%--------------------------------------------------------------------------
% Calculate delay time [s].
if (Nx == 1) && ~q_flag
        disp(' (o_o)  Warning: Delay 4 single-point is 0. '); disp(' ');
end
delta_t = x*(sin(theta_r)/c); % Delay time 2 apply 2 each signal in wavefront [s].
% if min(delta_t) == 0
%     delta_t = delta_t + 1/fs; % Avoid '0' initial time 4 fixing phase spectrum problems!
% end    
%--------------------------------------------------------------------------
% Generate input signal.
   f_quiet = 1;
        Ps = zeros(N,Nx);
if s_type ~= 1
    s = f_gen_signal(N,n_burst,s_type,p_max,f0,fs,0,t);     
    if s_delay   
        % Add fix delay 2 signal to avoid filtering problems.
        fprintf('Adding fix delay of: %.2f us  to improve filtering...\n',s_delay*10^6);  
        s = f_delay_signal(fs,N,s_delay,s,f_quiet);    
    end
    % disp('Filtering excitation signal for Plane Wave...')
    s = f_ideal_bp_filter(s,f_min,f_max,fs,1);
    %--------------------------------------------------------------------------
    % Create PWLB for generic signal.
    if Nx == 1
        Ps = f_delay_signal(fs,N,delta_t,s,f_quiet);
    else%-------------------------------------------
        % Check sampling frequency delay critera.
        delta_ave = mean(abs(diff(delta_t)));
        if (1/fs <= delta_ave) || (delta_ave == 0) 
            for j = 1:Nx    
                Ps(:,j) = f_delay_signal(fs,N,delta_t(j),s,f_quiet);
            end
        else
         fprintf('\n :( Error: Plane wavefront conformation not possible... \n');
         fprintf('    Required time_step = %.3f us > %.3f us = 1/fs. \n',delta_ave*10^6,10^6/fs);
         fprintf('    Increase fs at least to: %.2f MHz \n',(1/delta_ave)/10^6);
            error(' ');        
        end
    end%-------------------------------------------
else
    %--------------------------------------------------------------------------
    % Create PWLB for sinus type signals.
    phi_r = -delta_t*(2*pi*f0);  % Phase delay vector for signals.
    for j = 1:Nx    
        Ps(:,j) = f_gen_signal(N,s_type,s_type,p_max,f0,fs,phi_r(j),t);
    end
end             



 



