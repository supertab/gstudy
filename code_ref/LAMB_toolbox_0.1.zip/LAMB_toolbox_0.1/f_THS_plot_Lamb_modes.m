function f_THS_plot_Lamb_modes(mode_type,mode,f,Cph,Cg,color,f0,Cph0,Cg0)
% Plotting function for Lamb modes.
% Parameters:
%            S_z = THS data matrix or dell array.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    09/05/2008
% ver 1.1    15/01/2009     Change in function name: 'f_find_mode_freq' --> 'f_THS_find_mode_freq'.


%--------------------------------------------------------------------------
% Plotting loaded available data.
if mode_type == 1
    % Plot Anti-simetric modes               
    figure(991); plot(f,Cph,color); text(f(1),Cph(1),[' ',mode],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',14);    
    figure(992); plot(f,Cg,color);  text(f(1),Cg(1),[' ',mode],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',14);
    drawnow;
elseif mode_type == 0
    % Plot Simetric modes               
    figure(991); plot(f,Cph,color); text(f(1),Cph(1),[' ',mode],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',14);
    figure(992); plot(f,Cg,color);  text(f(1),Cg(1),[' ',mode],'VerticalAlignment','top','HorizontalAlignment','left','FontSize',14);
    drawnow;
else
    disp(':(  Wrong value in "mode_type" vector. See Lamb curves loaded data...'); error(' ');
end

%--------------------------------------------------------------------------
% Plotting seleted bandwidth data.
if ~(isempty(f0) || isempty(f0) || isempty(f0))
    if mode_type == 1
        % Plot Anti-simetric modes               
        figure(991); plot(f0,Cph0,'g.'); plot(f0,Cph0,'go');   
        figure(992); plot(f0,Cg0,'g.'); plot(f0,Cg0,'go');  
        drawnow;
    elseif mode_type == 0
        % Plot Simetric modes               
        figure(991); plot(f0,Cph0,'c.'); plot(f0,Cph0,'co');   
        figure(992); plot(f0,Cg0,'c.'); plot(f0,Cg0,'co');  
        drawnow;
    else
        disp(':(  Wrong value in "mode_type" vector. See Lamb curves loaded data...'); error(' ');
    end 
end

