function [R] = f_solve_ellipse(a,b,fi)
% Resolve ellipse coordinate points for a given inclination angle and ellipse main axis.
% Ellipse equation:
%           x^2     y^2
%          ----- + -----  =  1
%           a^2     b^2
%
% Parameters:
%            a = Ellipse major semi-axis [m].
%            b = Ellipse minor semi-axis [m].
%           fi = Inclination angle from ellipse origin to ellipse point of interest [Grad].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
%
% ver 1.0    26/01/2009

if     fi == 0     R = a;
elseif fi == pi/2  R = b;
else
     R_min = min([a b]);
     R_max = max([a b]);
       R_s = R_min/1000;      
         R = (R_min:R_s:R_max)';        
         y = real(asin((R/b)*sin(fi))) - real(acos((R/a)*cos(fi)));    
[y_min,ii] = min(abs(y));
         R = R(ii);
end




%------------------------------------------------------------
% Old code.
% [R,fval,exitflag] = fzero(@f,[a b],[],a,b,fi)   % <-- Calling sequence...
%
% function [R] = f(R,a,b,fi)      % <-- Function definition. 
%
%  R = real(asin((R/b)*sin(fi))) - real(acos((R/a)*cos(fi)));
%
%


