function [h] = f_IRMc_IR_RB_point (P,a,b,c,t,N,zone,t_max)     
% Funcion que computa la Respuesta Impulsional 'h' (Rigid-Baffle)
% p/un punto de coordenadas P(x,y,z) ref. a un elemento rectangular
% situado en el Origen O(0,0,0) y perpendicular al eje 'Z'.
% Basada en paper:  "J.L.San Emeterio & L.Ullate" *****
% Donde:
%      P(x,y,z) = Coord. del punto de campo a calcular [mm].
%             a = Semi-ancho de la aperura rectangular [mm].
%             b = Semi-alto de la aperura rectangular [mm].
%             c = Velocidad del sonido en el aire [mm/s].
%             N = Nro. de puntos de la traza 'h'.
%          zone = Zona de computo (1,2,3,4).
%         t_max = Tiempo maximo de duracion de la traza 'tiempo de vuelo max.' 
%                 c/10% de margen extra ver  -> 'f_cal_t_max_time_2'
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    29/10/2004   Version m�s simple de  'f_cal_IR_z_line'
% ver 2.0     3/11/2004   Agregado de coord. en todos los cuadrante del ele.
% ver 3.0     5/11/2004   Esta ver. asume p/los cal. q/ 'O' = 'O_ele' = (0,0,0)
% ver 4.0    28/11/2004   Correc. de la amp. de 'h(t)' x el factor:  h = h*(c/(2000*pi));
% ver 5.0     3/01/2005   Agreg. devol. indice 'i_T0'
% ver 6.0     7/07/2005   Elimin. devol. indices p/aumento de velocidad, 'i_T0,i_TD'
% ver 6.1    05/06/2006   Cambio en forma paso coord: (x),(y),(z) -> P(x,y,z) vector.
% ver 6.2    28/01/2008   Uso de vectores columna p/'h'.
% ver 6.3    16/12/2008   Paso de [mm] --> [m] (Ver linea 87 mas abajo).
% ver 7.0    12/01/2009   Change in name: 'f_cal_IR_RB_point' --> 'f_IRMc_IR_RB_point'.
% ver 7.0.1  16/01/2009   Add of detection of null 'h'.

     h = zeros(N,1);
     
    % Definiciones fundamentales de las distancias desde el punto de campo 'P':
    % Distancias 'rectas a las extensiones de los lados del elemento'
    d1 = abs(P(1)) - a;   
    d2 = abs(P(2)) - b;   % Obs. aqui se incluyen todos los cuadrantes ref. al 1ero.
    d3 = abs(P(1)) + a;   % en cual se basan los calculos del paper.
    d4 = abs(P(2)) + b;   % el abs(), produce esta referenciacion...
    
    TA = (sqrt(d1^2 + d2^2 + P(3)^2))/c;   % Tiempos a los vertices 'A','B','C' y 'D'
    TB = (sqrt(d2^2 + d3^2 + P(3)^2))/c;
    TC = (sqrt(d1^2 + d4^2 + P(3)^2))/c;
    TD = (sqrt(d3^2 + d4^2 + P(3)^2))/c;   % Tiempo max. del punto 'P' a la sup. del elemento
    
    TS1 = (sqrt(d1^2 + P(3)^2))/c;         % Tiempos a los lados: 'S1', 'S2','S3' y 'S4'
    TS2 = (sqrt(d2^2 + P(3)^2))/c;
    TS3 = (sqrt(d3^2 + P(3)^2))/c;
    TS4 = (sqrt(d4^2 + P(3)^2))/c;
   
     T0 = abs(P(3))/c;                     % Tiempo minimo de 'P' a la sup. del elemento.


    % Calculo de los angulos alfa   (FUNCIONES OPTIMIZADAS ******************** 
           [i_T0,i_TD] = f_IRMc_time_indexes (N,t,T0,TD);

     [alfa_r_1,alfa_1] = f_IRMc_alfa_i_opt2 (c,i_T0,i_TD,N,T0,TS1,TD,t,P(3),d1);
     [alfa_r_2,alfa_2] = f_IRMc_alfa_i_opt2 (c,i_T0,i_TD,N,T0,TS2,TD,t,P(3),d2);
     [alfa_r_3,alfa_3] = f_IRMc_alfa_i_opt2 (c,i_T0,i_TD,N,T0,TS3,TD,t,P(3),d3);
     [alfa_r_4,alfa_4] = f_IRMc_alfa_i_opt2 (c,i_T0,i_TD,N,T0,TS4,TD,t,P(3),d4);


    % Cal. de 'h' segun la zona de 'P' ****************************************
    switch zone    
      case 1
        [h] = f_IRMc_h_I_opt (i_T0,i_TD,N,t,TA,TB,TC,TD, alfa_1,alfa_2,alfa_3,alfa_4);  % Cal. 'h' dentro de la zona I
        
      case 2
        [h] = f_IRMc_h_II_opt (i_T0,i_TD,N,t,TA,TB,TC,TD  ,TS2,  alfa_1,alfa_2,alfa_3, alfa_4,alfa_r_4);  % Cal. 'h' dentro de la zona II

      case 3
        [h] = f_IRMc_h_III_opt (i_T0,i_TD,N,t,TA,TB,TC,TD  ,TS1,  alfa_1,alfa_2, alfa_3,alfa_r_3, alfa_4);  % Cal. 'h' dentro de la zona III

      case 4
        [h] = f_IRMc_h_IV_opt (i_T0,i_TD,N,t,TA,TB,TC,TD  ,T0,  alfa_1,alfa_2,alfa_3,alfa_4, alfa_r_1,alfa_r_2,alfa_r_3,alfa_r_4);  % Cal. 'h' dentro de la zona IV
        
        
      otherwise
         %f_pichichitus(8192);
         fprintf(' :( Zone error: zone = %i \n',zone); error(' ');
    end
    
%-------------------------------------------------------------------------    
    h = h*(c/(2*pi));  % Paso de 'omega',[rad] -> h(t)[m/s].
%%%    h = h*(c/(2000*pi));  % Paso de 'omega',[rad] -> h(t)[m/s]. El 1000 ex xque 'c' esta pasa de: [mm/s] -> [m/s]
%-------------------------------------------------------------------------    

    
% % Debug code only ------------------------------------------------------
%         figure(10)
%         plot(h)
%         plot(h,'r.')
%                
%         figure(222) % <------ esta pueden ser las problematicas
%         plot(alfa_1,'b')
% %        plot(alfa_2,'r')
%         plot(alfa_3,'m')
% %        plot(alfa_4,'k')
%         %---------------------
%   
%         figure(30)
%         plot(alfa_r_1,'b.')
% %        plot(alfa_r_2,'r.')
%         plot(alfa_r_3,'m.')
% %        plot(alfa_r_4,'k.')        
% 
% %       drawnow        
%--------------------------------------------------------------------------
    
%--------------------------------------------------------------------------
% COMENTED FOR SPEED IMPROVEMENT!!!
%--------------------------------------------------------------------------
    if ( (min(h) < -0.000001) || (max(h) > c) || (max(h) == 0) )  % RECORDAR QUITAR LUEGO EL...'max(h)...'
        disp('(o_o) Null: Null or NEGATIVE "h" !!.......................');  
        disp('      Check t_max parameter or increase fs... ');
        error(' ');
    end    

    


