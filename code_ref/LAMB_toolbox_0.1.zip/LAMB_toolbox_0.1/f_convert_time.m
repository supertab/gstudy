function [minutes,seconds] = f_convert_time(time)
% Conversion of time [s] to minutes and secods.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   09/05/2008

minutes = floor(time/60);
seconds = time - minutes*60;

