function [Ps] = f_resample_data(N,N2,fs,fs2,t,t2,Ps,f_quiet)
% Oversample or downsample a data set 'Ps'.
% Obs.: 
%              N = Longitude of input signals.
%             N2 = Longitude of output signals.
%             fs = Input's sampling frequency [Hz].
%            fs2 = Output's sampling frequency [Hz].
%              t = Input time vector @fs sampling frequency.
%             t2 = Ouput time vector @fs2 sampling frequency; fs2 >=< fs.
%             Ps = Data-structure:  
%                  1) Cell-3D matrix  Ps = cell{Nt,1}(Nx,Ny,N);
%                  2) 2D-Matrix:      Ps = zeros(N,Nx);
%                  3) 3D-Matrix:      Ps = zeros(Nx,Ny,N);
%                  4) 4D-Matrix:      Ps = zeros(Nt,Nx,Ny,N);
%            
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
%
% ver 1.0    26/12/2008
% ver 2.0    08/01/2009     Change on reception field dimensions: [Nx Ny]=size(X_field) --> S_z = zeros(Nx,Ny,N)
% ver 2.1    28/02/2009     Change in name:  'f_over_sample_data'  -->  'f_resample_data'.
% ver 2.2    06/12/2009     Adaptation 4 LAMB program ver 0.1 (2D matrix detection).


if (fs == fs2) 
    if ~f_quiet
        fprintf(' :|  Nothing to do!... fs = fs2 = %.2f [Hz] \n',fs);
    end
else
    %----------------------------------------------------------------------
    if fs2 > fs 
        if ~f_quiet
            fprintf(' Oversampling data.... \n');
        end
    else
        if ~f_quiet
            fprintf(' Downsampling data.. \n');
        end
    end
    if ~f_quiet
        fprintf('     fs = %d MHz ->  fs2 = %d MHz \n',fs/10^6,fs2/10^6);
        fprintf('      N = %i    ->  N2 = %i \n\n',N,N2);
    end
    s = zeros(N,1);
    if iscell(Ps)
        %------------------------------------
        % Cell+3D matrix data type.
        Nt = max(size(Ps));
        [Nx2,Ny2,n] = size(Ps{1});
        A = zeros(Nx2,Ny2,N2);
        for k = 1:Nt
            for i = 1:Nx2       
                for j = 1:Ny2
                    s(:,:) = Ps{k,1}(i,j,:);          % Extract signal at field point (i,j).
                    A(i,j,:) = interp1(t,s,t2,'cubic'); % Change signal sampling frequency: fs -> fs_IRM.
                end   
            end
            Ps{k,1} = A;
        end
    else
        %------------------------------------
        D = ndims(Ps);
        if D == 2  % 2D Matrix type.
            [Nx2,n] = size(Ps');
            A = zeros(N2,Nx2);
            for j = 1:Nx2
                s(:,1) = Ps(:,j);                 % Extract signal at vector point (i,1).
                A(:,j) = interp1(t,s,t2,'cubic'); % Change signal sampling frequency: fs -> fs_IRM.
            end
            clear Ps;  % Delete old data.
            Ps = A;
        %------------------------------------
        elseif D == 3  % 3D Matrix type.
            [Nx2,Ny2,n] = size(Ps);
            A = zeros(Nx2,Ny2,N2);
            for j = 1:Nx2
                for i = 1:Ny2
                    s(:,:) = Ps(i,j,:);                 % Extract signal at field point (i,j).
                    A(i,j,:) = interp1(t,s,t2,'cubic'); % Change signal sampling frequency: fs -> fs_IRM.
                end
            end
            clear Ps;  % Delete old data.
            Ps = A;
        %------------------------------------
        elseif D == 4  % 4D Matrix data type!
            [Nt2,Nx2,Ny2,n] = size(Ps);
            A = zeros(Nt2,Nx2,Ny2,N2);
            for k = 1:Nt2
                for j = 1:Nx2
                    for i = 1:Ny2
                          s(:,:) = Ps(k,j,i,:);             % Extract signal at field point (k,j,i).
                      A(k,j,i,:) = interp1(t,s,t2,'cubic'); % Change signal sampling frequency: fs -> fs_IRM.
                    end
                end
            end
            clear Ps;  % Delete old data.
            Ps = A;
        %------------------------------------
        else
            fprintf(':( Error: wrong size of "Ps" matrix: ndim[Ps] = %i \n',D)
            error(' ');
        end
    end
    %----------------------------------------------------------------------
end




