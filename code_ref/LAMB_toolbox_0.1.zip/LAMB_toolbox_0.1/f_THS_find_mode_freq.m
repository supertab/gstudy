function  [Nf,wm] = f_THS_find_mode_freq(f_cph_mapping,f,fm,mode)
% This funtion returns the corresponding frequency vector for mode 'm'
% according to the selected frequency limits.
% Obs.:       
%      f_cph_mapping = Flag 4 frequency-phace velocity mapping tool.
%                      0 -> Disable
%                      1 -> Enable mapping -> 's_type = sinusoidal' only.
%                  f = Desired frequencies in bandwidth to compute.
%                 fm = Actual frequecies present in mode [Hz].
%          mode_type = Type of Lamb modes.
%                      0 -> Simetric
%                      1 -> Anti-simetric
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    07/05/2008
% ver 1.1    15/01/2009     Change in function name: 'f_find_mode_freq' --> 'f_THS_find_mode_freq'.

%--------------------------------------------------------------------------
if (max(f) > max(fm)) && ~f_cph_mapping
    fprintf(' (o_o)  Warning:  f_max > %i  in %s Lamb curve limit \n',max(fm),mode)
    pause
end
if (min(f) < min(fm)) && ~f_cph_mapping
    fprintf(' (o_o)  Warning:  f_min < %i  in %s Lamb curve limit \n',min(fm),mode)
    pause
end
% Find indexs in operative BW and convert it to final frequencies.
i = find(f >= min(fm) & f <= max(fm));
if ~isempty(i)
    wm = (2*pi)*f(i);
    Nf = max(size(wm));
else
    Nf = [];   % There are no frequencies within the selected BW for the present mode.
    wm = 0;   
end
%1




