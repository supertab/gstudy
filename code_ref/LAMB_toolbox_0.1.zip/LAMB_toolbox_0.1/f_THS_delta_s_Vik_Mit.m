function [d_delta_s] = f_THS_delta_s_Vik_Mit(k0,w0,h,alfa,beta)
% This funtion calculates the derivatives of dispersion relations from Viktorov.
% 
% Obs.:      w0 = Angular frequency vector [rad/s].
%            k0 = Wavenumber vector [Rad/m].
%             h = d/2 Half plate thickness [m].
%        k_alfa = sqrt( (k0.^2) - ((w0/alfa).^2) );  Longitudinal wavenumber [Rad/m].
%        k_beta = sqrt( (k0.^2) - ((w0/beta).^2) );  Tranverse wavenumber [Rad/m].
%          alfa = Longitudinal bulk wave velocity [m/s].
%          beta = Transversal bulk wave velocity [m/s].
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    23/09/2007   


%--------------------------------------------------------------------------
% Dispersion function and its derivative for simmetric modes.
    k_alfa = sqrt( (k0.^2) - ((w0/alfa).^2) );     % Longitudinal Lamb wavenumber vector [Rad/m].
    k_beta = sqrt( (k0.^2) - ((w0/beta).^2) );     % Transversal Lamb wavenumber vector [Rad/m].
  delta_s1 = ((((k0.^2)+(k_beta.^2)).^2).*cosh(k_alfa*h).*sinh(k_beta*h)) - ((4.*(k0.^2).*k_alfa.*k_beta).*sinh(k_alfa*h).*cosh(k_beta*h)); 
  
%--------------------------------------------------------------------------  
   delta_k = real(k0)/10000;   
        k0 = k0 + delta_k;
        
    k_alfa = sqrt( (k0.^2) - ((w0/alfa).^2) );     % Longitudinal Lamb wavenumber vector [Rad/m].
    k_beta = sqrt( (k0.^2) - ((w0/beta).^2) );     % Transversal Lamb wavenumber vector [Rad/m].
  delta_s2 = ((((k0.^2)+(k_beta.^2)).^2).*cosh(k_alfa*h).*sinh(k_beta*h)) - ((4.*(k0.^2).*k_alfa.*k_beta).*sinh(k_alfa*h).*cosh(k_beta*h)); 
%--------------------------------------------------------------------------    
   
 d_delta_s = (delta_s2 - delta_s1)./delta_k;
 


 
 
 
 
 
 
 
 