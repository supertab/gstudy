function [c,ro,Z0,lambda_air0,x2,X2,Y2,N2,t2,Ps2,theta_min,theta_max,theta_s,p_max,num_p,num_s,num_p_s,ang_alfa_1,ang_beta_1,ang_gamma_1,f_cph_mapping] = f_FIRST_main_3v1_2(T_amb,Hr,P,emitter_type_1,ele_order_1,OA,N_ele_1,N_s_ele_1,a2_1,b2_1,p_1,R_1,O,plate_mat,d,x_w,y_w,p_max,a,r_type,theta_min,theta_max,theta_s,ang_alfa_1,ang_beta_1,ang_gamma_1,fs,fs_IRM,f0,f_min,f_max,t_min,t_max,v_amp_1,s_type,s_delay,n_burst,ele_amp_type_1,ele_delay_type_1,ang_deflec_1,f_cph_mapping,f_FIRST_filter,f_norm_ps,f_pause,f_font,f_title,f_plot_1,f_plate_handle,f_delete_figs_1)
%--------------------------------------------------------------------------
% 'f_FIRST_main_3v1_2'
% Program for calculation of the acoustic fields emitted by rectangular apertures (single & arrays).
% Obs.: Code based on version 3.1.2 
%       All dimensions in [m].
% Parameters:
%            OA = OA_1 = Location of central point (origin) of emitter array 
% 
%            r_type = Region type
%                     0. Conventional "rectangular" regions; this include: single point; line and plane.
%                     1. Square/Rectangular circle filled.
%                     2. Circular/Ellipse circle filled.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 3.1.2  26/11/2009    Using IRM core: 'Main_FIRST_Ps_plane_3v1_2.m' (16/11/2006)


%--------------------------------
% REMEBER 2 RE-CHECK THS:  2.3 Determinate new time axis 4IRM (d1/c shifted  &  d2/c longer)
% ..........???
%--------------------------------


if s_type >= 0 % Set dummy parameter 4 THS and exit.
    x2 = 0; X2 = 0; Y2 = 0; N2 = 0; t2 = 0; Ps2 = 0; num_p = 1; num_s = 1; num_p_s = 1;  
    [c,atte_air_dB,ro,Z0] = f_cal_air_properties(T_amb,Hr,P,f0);
              lambda_air0 = c/f0;
else 
%--------------------------------------------------------------------------
disp('--------------------------------------------')
disp('1.0 Starting FIRST module')
disp('--------------------------------------------')
f_FIRST_handle = 1040;    % Main handle number for the FIRST figures.
%--------------------------------------------------------------------------
% 1.0.1.1 Check and define IRM parameters
[a0,b0,c,ro,Z0,lambda_air0,s_type,theta_min,theta_max,theta_s,O,OA,R_1,ang_deflec_1,ang_alfa_1,ang_beta_1,ang_gamma_1,f_cph_mapping] = f_FIRST_check_input_data(T_amb,Hr,P,emitter_type_1,OA,a2_1,b2_1,R_1,O,d,x_w,y_w,a,ang_alfa_1,ang_beta_1,ang_gamma_1,fs_IRM,f0,f_min,f_max,t_min,t_max,v_amp_1,s_type,ele_amp_type_1,ele_delay_type_1,ang_deflec_1,f_cph_mapping);
%--------------------------------------------------------------------------
% 1.0.1.2 Determinate possition of array emission elements 4 IRM.
                        O2 = [0 0 0]; % Auxiliar origin 4 IRM calculations.
[O_c_ele,O_ele,ang_ele,a0] = f_FIRST_cal_coord_eles(emitter_type_1,ele_order_1,O2,N_ele_1,N_s_ele_1,a0,p_1,R_1,0);
%figure(f_plate_handle); hold on; grid on; plot3(O_ele(:,1),O_ele(:,2),-O_ele(:,3),'bo'); plot3(O_ele(1,1),O_ele(1,2),-O_ele(1,3),'mo');
%-------------------------------------------------------
% 1.0.1.3 Determinate coordinates of IRM excitation field.
                      D = 0; phi = 0; psi = 0;
                     sx = a*sqrt(3);        % Step size between field grid points (X-axis) eg. 0.25 mm.
                     sy = a*sqrt(3);        % Step size between field grid points (Y-axis) eg. 0.25 mm.
              P_field_1 = [0 0 OA(3)-d/2];  % This point corresponds actually 2 the plate origin 'O'. 
[x,X,Y,Z,Nx,Ny,num_p,num_s,num_p_s,boundary] = f_cal_plano_campo(r_type,a,O2,ele_order_1,D,P_field_1,x_w,y_w,sx,sy,0,ang_beta_1,0,R_1,phi,psi,0); %,f_plate_handle);
                      Y = (-1)*Y;           % Invert IRM 'Y-axis' because it's inverse from 'THS' definition. 
%figure(f_plate_handle); plot3(X,Y,-Z,'g.'); plot3(X(1),Y(1),Z(1),'k+');

%--------------------------------------------------------------------------
% 1.0.2.1 Rotate, move & plot 'ficticious' array-elements: [0 ang_beta_1 0].
 [x2,y2,z2] = f_rotate_matrix(O_ele(:,1),O_ele(:,2),O_ele(:,3),180,ang_beta_1,0);
% Define auxiliary array origin 4 plotting purposes only. Rotation around Y-axis available by now.
        OA2 = [OA(3)*sin(ang_beta_1*pi/180) 0 OA(3)*cos(ang_beta_1*pi/180)];       
O_ele2(:,1) = x2 + OA2(1);   % Move rotated eles, to new origin.
O_ele2(:,2) = y2 + OA2(2);
O_ele2(:,3) = z2 + OA2(3);
figure(f_plate_handle);  hold on; grid on;
plot3(O_ele2(:,1),O_ele2(:,2),O_ele2(:,3),'bs'); 
plot3(O_ele2(1,1),O_ele2(1,2),O_ele2(1,3),'r.'); 
plot3(OA2(1),OA2(2),OA2(3),'r+'); 
%-------------------------------------------------------
% 1.0.2.2 Rotate, move & plot 'ficticious' IRM field points on plate location.
         X1 = X; Y1 = Y; Z1 = Z - P_field_1(3);          % 1t. move points to (0,0,0).
 [X2,Y2,Z2] = f_rotate_matrix(X1,Y1,Z1,0,-ang_beta_1,0); % Rotate main field matrix coordinates.
 [x2,y2,z2] = f_rotate_matrix(x,zeros(num_s,1),zeros(num_s,1),0,-ang_beta_1,0); % Rotate vector w/X-coords. for Y-strips.
         Z2 = Z2 + d/2;            % Move rotated eles. 2 plate surface (only Z-coord.).
figure(f_plate_handle); plot3(X2,Y2,Z2,'r.'); plot3(X2(1),Y2(1),Z2(1),'k+');
for i = 1:num_p  % Plot excitation circle boundarys.
    [xc,yc] = f_cal_circle([X(i) Y(i)],a,36);  
         zc = O(3)*ones(max(size(xc),1));
         plot3(xc,yc,zc,'b');
end
%--------------------------------------------------------------------------
% 1.0.2.3 Draw plate & emission field boundary
[cph_Rayleigh,Alfa,Beta,ro_plate,lambda,mu,sigma,plate_type] = f_mat_properties_2(1,plate_mat); % Determinate 'plate_type' parameter only.
plate_color = 2;
  plate_dim = [0.400 0.100 d];  %  plate_dim = [2.5*max(X_field) max(X_field) d];  % Other possible of plate dims [6*x_w2 6*y_w2 2*P_field_2(3)].
f_THS_draw_plate(num_p,num_s,a,p_max,d,plate_type,O,plate_dim,plate_color,f_plate_handle,f_font,f_title);

%--------------------------------------------------------------------------
% 1.0.3.1 Return limit points 'P_near' & 'P_far' 4 IRM emission/reception fields: O_ele & [X,Y,Z].
  [Nx0 Ny0] = size(O_ele(:,1));
    [Nx Ny] = size(X);
[D3_min,D3_max,P3_near,P3_far] = f_IRM_find_limits(Nx0,Ny0,O_ele(:,1),O_ele(:,2),O_ele(:,3),Nx,Ny,X,Y,Z); 
%--------------------------------------------------------------------------
% 1.0.3.2 Determinate tentative trace longitudes...
             t = 0;  
trace_duration = t_max;
[N2,t_max2,t2] = f_cal_t_max_time(fs_IRM,c,D3_min,D3_max,trace_duration,t);
fprintf('1.0.3.2 N2 = %i \n',N2);
%-------------------------------------------------------
% 1.0.4.0 Pre-process input for IRM.
[N,Nf,f_s,f,t,s_a,ele_amp,ele_delay] = f_FIRST_pre_process_input(ele_order_1,N_ele_1,ele_amp_type_1,ele_delay_type_1,c,R_1,O2,O_c_ele,ang_deflec_1,v_amp_1,n_burst,s_type,s_delay,Nx,Ny,N2,t2,fs_IRM,f0,f_min,f_max,f_FIRST_filter,f_plot_1,f_FIRST_handle,f_font);

%--------------------------------------------------------------------------
% 1.0.5.0 Estimate IRM calculation time...
[minutes,seconds,N_ele,Npts] = f_IRM_estimate_time(T_amb,Hr,P,O2,N_ele_1,1,1,1,1,0,0,Nx,Ny,Nx,Ny,N,Nf,fs_IRM,f_s,f,t,[X(1) Y(1) Z(1)],-ang_beta_1,f_pause);

%--------------------------------------------
% 1.0.6.0 Start calculations of pressures in plate region (Ps).
% If  'baffle = 0'  ->  Riggid-Baffle; if not... Soft-Baffle.
fprintf('1.0.6.0 Starting...\n');
baffle = 0; 
[et,Ps] = f_FIRST_IRM_init (T_amb,Hr,P,baffle,N_ele,O_ele,ang_ele,ele_amp,ele_delay,a0,b0,X,Y,Z,fs_IRM,f_s,f_min,f,Nf,N,t,t_max,s_a);
[minutes,seconds] = f_convert_time(et);
fprintf(' FIRST done!  tt = %i:%.1f \n',minutes,seconds);
%--------------------------------------------
% 1.0.7.0 Re-arrange final field matrix format.
fprintf('1.0.7.0 ');
[N2,t2,Ps2,p_max] = f_FIRST_post_process_output(r_type,N,t,t_min,t_max,fs_IRM,fs,X,Ps,p_max,f_norm_ps,f_pause,f_plot_1,f_FIRST_handle+5,f_font);

%--------------------------------------------
if f_delete_figs_1
    delete(f_FIRST_handle+1);
    delete(f_FIRST_handle+2);
     figure(f_FIRST_handle+3); delete(f_FIRST_handle+3);
    delete(f_FIRST_handle+4);
    delete(f_FIRST_handle+5);
end

%--------------------------------------------------------------------------
end % End FIRST module.
%--------------------------------------------------------------------------
%1;


