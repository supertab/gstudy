function f_IRM_draw_emission_elements(a,b,Nx2,Ny2,X2,Y2,z2,f_plot_eles,f_handle)
% Draw emission elements boundaries!
% Parameters:
%            plate_O = Plate origin [m].
%          plate_dim = Plate dimesions [m].
%        plate_color = Plate color type: 1,2,3 & 4. 
%                      Other numbers -> plain color w/no possibility of interp shading.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    19/01/2009
% ver 1.1    19/02/2009    'f_plot_eles' flad added.


%-----------------------------
% Draw emission elements!
if f_plot_eles
    b_color = 'c';
    if f_plot_eles
        if Nx2*Ny2 > 1000
            fprintf('(o_o) Warning: number of N_eles = %i is to high... \n',Nx2*Ny2);
            answer = f_input('      Do you like still plotting ?',0,1);
            if (answer == 'y') || (answer == 'Y')
                for i2 = 1:Nx2
                    for j2 = 1:Ny2
                        P_field = [X2(i2,j2) Y2(i2,j2) z2];
                        f_draw_boundary(P_field,2*a,2*b,0,0,0,b_color,f_handle);
                    end
                end
            end
        else
            n = 1;
            for i2 = 1:Nx2
                for j2 = 1:Ny2
                    P_field = [X2(i2,j2) Y2(i2,j2) z2];
                    if f_impar(n,2); b_color = 'c'; else b_color = 'y'; end;
                    f_draw_boundary(P_field,2*a,2*b,0,0,0,b_color,f_handle);
                    n = n+1;
                end
            end
        end
    end
end

%-----------------------------
% Indicate 1st. emission element.
plot3(X2(1,1),Y2(1,1),z2,'r.'); 



