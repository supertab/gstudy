function [S_feature,steering] = f_FRM_plot_2(Vs_feature_type,Vs_delay_type,N3,fs3,t3,Vs3_3_2,steering,Nt,Ns,theta,a,p_max,num_p,f_title,axis_font,f_delete_figs,f_pol_coord,f_norm_plots,f_dB_plots,f_pause,f_plot,f_handle)
% Plot features for aperture reception digram.
%
% Parameters:
%             Vs3_4 = zeros(N3,Nt);  % Final array output matrix signals for steering angle vector 'theta'.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    04/02/2009
% ver 1.1    21/02/2009     Inter program 'f_pause' added.
% ver 1.2    28/02/2009     Change in parameter 'fs_IMR' --> 'fs' because of use downsampled data.
% ver 1.2.1  04/03/2009     Rad. diagram 'polar plots' added.
% ver 2.0    14/12/2009     Adaptation for LAMB program ver 0.1 + 'f_handle' added.

%---------------------------------------------------------------------------------------------------------------    
% 4.2 Plot features for aperture reception digram.
h1 = figure(f_handle+5); hold on; grid on;
if ~f_pol_coord
    set(get(gcf,'CurrentAxes'),'FontSize',axis_font);
end
if f_title     
    title(['Aperture reception diagram @p-max = ',num2str(p_max),'Pa; a = ',num2str(a*1000),' mm; num_p = ',num2str(num_p)],'FontSize',f_title); 
end

%-----------------------------------
% Assign correct magnitudes to axis.
   f_label = cell(2,1);
f_label{1} = 'Steering ang [Deg]';
f_label{2} = 'V'; 
   E_const = 1;  % Cal. energy of signals using 'e_const' value.
 S_feature = zeros(Nt,Ns);
%   S_delay = zeros(Nt,Ns);
for k = 1:Nt
    for l = 1:Ns
                               s(:,1) = Vs3_3_2(k,l,:);
        [S_feature(k,l),delay] = f_s_feature(Vs_feature_type,[],theta(k),E_const,N3,fs3,t3,s,steering,0,0,f_norm_plots,f_dB_plots,axis_font,f_label,h1,0);
    end
end

%-----------------------------------
% Plot rad. diagram.
if f_pol_coord
   th_max = max(steering)
     th_s = 1;
    figure(h1); hold off; grid off;
    for k = 1:Nt
        f_polar(steering*(pi/180),S_feature(k,:),'b');%,[-th_max th_max th_s]);
        if k == 1  hold on; end;
        drawnow;
    end
else
    figure(h1); hold on; grid on;
    for k = 1:Nt
        fprintf(' theta(%i@%i) = %.1f�\n',k,Nt,theta(k))
        if (k == 1) && (Nt == 1)
            plot(steering,S_feature(k,:));    
            plot(steering,S_feature(k,:),'g.');
        elseif (k == 1) && (Nt > 1)
            plot(steering,S_feature(k,:),'g');
        else
            plot(steering,S_feature(k,:),'b');  % set(gca,'XDir','reverse');
        end
        [y0,ii] = max(S_feature(k,:));
             x0 = steering(ii);
        text(x0,y0,[num2str(theta(k)) '�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',axis_font);    
    end
end

%-----------------------------------
if f_delete_figs && f_pause
    disp('Program paused. Press any key to continue...');
    pause;  
    delete(figure(h1));
elseif f_delete_figs
    delete(figure(h1));
end
