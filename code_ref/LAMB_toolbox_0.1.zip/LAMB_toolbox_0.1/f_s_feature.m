function [s_feature,s_delay] = f_s_feature(feature,delay_type,theta,E_const,N,fs,t,Signal,X,Y,f_plot,f_norm_plots,f_dB_plots,axis_font,f_label,h1,h2)
% Extract features (max.value; p2p; energy & delay) from a given column signal's matrix 'Signal'.
% Obs.:
%             h ~ 0 -> Plot feature in y-axis
%             h = 0 -> Plot feature in z-axis
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    05/02/2009
% ver 1.1    14/12/2009     'f_plot' flag added.

if f_plot && h2 >0
    figure(h2); hold on; grid on; set(get(gcf,'CurrentAxes'),'FontSize',axis_font); xlabel(f_label{1},'FontSize',axis_font);
end
if f_plot && h1 >0
    figure(h1); hold on; grid on; set(get(gcf,'CurrentAxes'),'FontSize',axis_font); xlabel(f_label{1},'FontSize',axis_font);
end

[d1,d2] = size(X);
if (d1 > 1) && (d2 > 1) % Is X a matrix?
    x = X(1,1); y = Y(1,1); % Yes!
else
    x = X(1,1); y = 0;      % No, X is a vector.
end

if feature >= 0
    switch round(feature)
        case 0 % Max. +value detection.
            [s_feature] = f_s_max(theta,Signal,x,y,h1,axis_font);
            if f_plot && h1 >0
                if  y == 0  ylabel('Max. pick ','FontSize',axis_font);
                else        zlabel('Max. pick ','FontSize',axis_font); end;
            end
        case 1 % Pick-to-pick value.
            [s_feature] = f_s_p2p(theta,Signal,x,y,h1,axis_font);
            if f_plot && h1 >0
                if y  == 0  ylabel('Pick-2-pick ','FontSize',axis_font);
                else        zlabel('Pick-2-pick ','FontSize',axis_font); end;
            end                
        case 2 % Signal's energy calculation.
            [s_feature] = f_s_energy(E_const,theta,Signal,x,y,h1,axis_font);
            if f_plot && h1 >0
                if f_dB_plots
                    if y == 0   ylabel('Power [dB]','FontSize',axis_font);
                    else        zlabel('Power [dB]','FontSize',axis_font); end;
                else
                    if y == 0   ylabel('Power [W]','FontSize',axis_font);
                    else        zlabel('Power [W]','FontSize',axis_font); end;
                end
            end
        otherwise % Time instant (photo); index between 1:N.
            N = length(t);
            if feature <= N
                [s_feature] = f_s_photo(theta,t,feature,Signal,x,y,h1,axis_font);
                if f_plot && h1 >0
                    if y == 0  ylabel('Instant value ','FontSize',axis_font);
                    else       zlabel('Instant value ','FontSize',axis_font); end;
                end
            else
                fprintf(':( Error: Time instant outside t_max! \n');
                fprintf('N = %i   n = %i',N,feature); 
                if f_plot && h1 >0,  delete(figure(h1));  error(' ');  end
            end
    end
else
    fprintf(':( Error: Feature type must be an integer >= 0 \n');
    fprintf('feature  = %f \n',feature); 
    if f_plot && h1 >0,  delete(figure(h1));  error(' ');  end
end
%-----------------------------------
% Appy normalization if required.
if f_norm_plots
    s_feature = s_feature/max(max(s_feature));
end
%-----------------------------------
% dB conversion if required
if f_dB_plots
    if round(feature) == 2 % dB conversion 4 energy calculations
        s_feature = 10*log10(s_feature);  
    else % dB conversion 4 amplitude calculations
        s_feature = 20*log10(s_feature);
    end
end
%-----------------------------------
% Is X a matrix?
if f_plot && h1 > 0
    if (d1 > 1) && (d2 > 1)  surf(X,Y,s_feature);% Yes!
    else  plot(X,s_feature); plot(X,s_feature,'g.'); end
end

%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
if ~isempty(delay_type)
    %----------------------------------------------------------------------
    s_delay = f_s_delay(theta,delay_type,N,fs,Signal,t,h2,x,y,axis_font);
    if f_plot && h2 > 0
        figure(h2); 
        if y == 0   ylabel('s_delay [us]','FontSize',axis_font);
        else        zlabel('s_delay [us]','FontSize',axis_font); end;
        % Is X a matrix?
        if (d1 > 1) && (d2 > 1),    surf(X,Y,s_delay*10^6);% Yes!
        else  plot(X,s_delay*10^6); plot(X,s_delay*10^6,'r.'); end
    end
    %----------------------------------------------------------------------
else
    s_delay = 0;
end
