function [Ps_max] = f_cal_Ps_max(theta,Ps,x,y,axis_font)
% Funcion que extrae los val. max. y pap. de un "Prisma de datos"
% dado en el plano de exploracion computado de 'H'
%
% ver 1.0   26/07/2004
% ver 2.0   16/11/2006   Agregado 'min' y 'pap'
% ver 3.0   09/02/2008   Deteccion de maximos en matrices 2D.


disp('0. Calculating maximum pick data...');

[xs ys N] = size(Ps);
if N > 1
    %----------------------------------------------------------------------
    % Deteccion de maximos en matrices 3D.
    Ps_max = zeros(xs,ys);
    for i = 1:xs
        for j = 1:ys
            Ps_max(i,j) = max(Ps(i,j,:));
        end
    end
    if (x(1) ~= 0) && (y(1) ~= 0)
        text(x,y,max(max(Ps_max)),['Max. pick [Pa] @',num2str(theta),'�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',axis_font);
    end
else
    %----------------------------------------------------------------------
    % Deteccion de maximos en matrices 2D.
    [nro_s,N] = size(Ps);
       Ps_max = zeros(nro_s,1);
    for i = 1:nro_s
        Ps_max(i,1) = max(Ps(i,:));
    end
    if (x(1) ~= 0)
        [y,ii] = max(Ps_max);
        text(x(ii),y,[num2str(theta),'�'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',axis_font);
    end
end




