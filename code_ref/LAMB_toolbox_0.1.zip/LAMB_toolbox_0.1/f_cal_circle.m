function [xc,yc] = f_cal_circle(O,R,N)
% Funcion que calcula las coord del un circulo
% Donde:
%        O = Coord. del centro
%        R = Radio.
%        N = Nro. de puntos del circulo.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   02/06/2006
% ver 2.0   23/01/2008    Version simplicada


theta_s = 2*pi/N;      % paso angular entre puntos [Rad.]
  theta = (0:theta_s:(2*pi))';
     xc = O(1) + R.*cos(theta);
     yc = O(2) + R.*sin(theta);

