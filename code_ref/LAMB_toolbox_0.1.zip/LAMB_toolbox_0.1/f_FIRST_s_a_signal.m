function [s_a,s_v] = f_FIRST_s_a_signal(n_burst,v_type,v_amp,N,fs,f0,f_min,f_max,t,t_delay,f_plot,f_handle,f_font)
% Funcion de calculo de la se�al de aceleracion utilizada 's_a', por el algoritmo IRM
% a partir de la se�al de velocidad 's_v'.
% Donde:
%         v_type = tipo de se�al de velocidad a usar 
%          v_amp = amplitud de la se�al de velocidad [m/s]
%              N = nro. de puntos de la se�al
%             fs = frecuencia de muestreo [Hz]          
%             f0 = frecuencia central del AB de la se�al
%              t = vector de tiempos de la se�al[s]
%        t_delay = Demora inicial de la se�al de entrada [s]
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0   20/10/2005
% ver 2.0   05/06/2006   Agreg. tiempo duracion se�al.
% ver 3.0   28/01/2008   Elim. parametro 'v_duracion' 
% ver 3.1   03/02/2008   Redifinicion tiempo p/se�al tipo '2'. Arranque en: '0' no en 't_min'.
% ver 3.2   14/04/2008   Agreg. parametro 'n_burst'.
% ver 3.3   06/03/2009   Agreg. parametro 't_delay'.
% ver 3.4   27/11/2009   Adaptation for LAMB program ver 0.1

if f_plot
    if (f_handle <= 0) || isempty(f_handle)
        f_handle = 999003; figure(f_handle); hold on; grid on;    
    end
end
%--------------------------------------------------------------------------
switch(v_type)
       case 0  % Uso de se�al experimental de velocidad: 'load v_s_ref_270_C2'
            fs_m = 100*10^6;    % Frecuencia de muestreo de la se�al experimental [Hz].
           [s_v] = f_cal_s_m(fs_m,fs,N,v_amp); 
           fprintf(' Using experimental "v_signal"  @fs = %.2f MHz \n',fs_m/10^6);
       %-------------------------------------------------------------------
       case 1  % senoidal
           [s_v] = f_cal_s_cw(N,fs,f0,v_amp,t);           
       %-------------------------------------------------------------------
       case 2  % pulsada
               k = 2  % <- x ajuste a ojo de 'ps' experimental. Ohterwise: 1.437 y 3.833  Cte's de control exp. ver paper J.L.Emeterio
              t2 = (0:1/fs:(N-1)/fs)';  % <- Redifinicion del vector de tiempos: arranque desde '0' no de 't_min'.
           [s_v] = f_cal_s_p(N,fs,f0,k,v_amp,t2);
       %-------------------------------------------------------------------           
       case 3  % burst-senoidal
           % Type of windowing to apply. 
           if n_burst >= 0   w_type = 0;  % 0 -> Rectangular. 
           else              w_type = 1;  % 1 -> Sinusoidal.
           end           
           [s_v] = f_s_burst_sin(v_amp,f0,t,n_burst,w_type);           
       %-------------------------------------------------------------------       
       case 4  % burst-cuadrada (val_medio = 0)
            % If   n_burst < 0  ->  Anti-simmetric type.
            % If   n_burst > 0  ->  Simmetric type.
            % Else n_burst == 0 ->  Simmetric type @n_burst = 10.            
           w_type = 0;
           [s_v] = f_s_burst_square(v_amp,f0,t,n_burst,w_type);
       %-------------------------------------------------------------------            
       case 5  % burst-chirp
           t_end = 15*10^-6         % Time for ending chirp [s].
           if max(t) < t_end
               disp('Error:  t_end > t_max  in f_s_chirp_sin function...');  
               error(' ');
           else
           [s_v] = f_s_chirp_sin(v_amp,t_end,N,f_min,f_max,fs);                       
        end
       %-------------------------------------------------------------------
       case 6  % pulsada2  (seno enventanado x envolvente medida!)
            fs_m = 100*10^6;         % Frecuencia de muestreo de la se�al experimental
           [s_v] = f_cal_s_p2(N,fs_m,fs,f0,t);
       %-------------------------------------------------------------------
       otherwise
            disp(':( Error: Tipo de se�al de entrada no definido..!')
            error(' ');
end  


%--------------------------------------------------------------------------
% If seleted, add fix delay 2 signal to avoid filtering problems.
if t_delay   
    f_quiet = 1;
    fprintf(' Adding fix delay of: %.2f us  to improve filtering...\n',t_delay*10^6);  
    s_v = f_delay_signal(fs,N,t_delay,s_v,f_quiet);    
end
%--------------------------------------------------------------------------
% Filtrado de se�al de velocidad
if (f_min ~= 0) && (f_max ~= 0)
    s_v_fil = f_ideal_bp_filter(s_v,f_min,f_max,fs,0);
end    

%--------------------------------------------------------------------
% Calculo se�al de aceleracion
  s_a = fs*diff(s_v_fil); % Obs. estrictamente debemos mult. x 'fs'; si bien luego dividiresmos tambien x 'f' durante el cal.  de 'ps'.
                          % Ver. line 74 de 'f_cal_Ps_plane_2D_5'.
[m,i] = max(abs(s_a));
if i > 11 
    n_level = norm(s_a(i-10:i))/norm(s_a(i-10:i-1));  % Indice de posible sobre pico (x efecto de la derivacion) del ultimo pto. de 'a'
else
    n_level = norm(s_a(1:i))/norm(s_a(1:i-1));
end
if (m > fs) || (n_level >= 1.01)
    if i == 1
        s_a(i) = 0;
    else
        s_a(i) = (s_a(i-1)+s_a(i+1))/2;   % corte de posible pico indeseado de la se�al, paso umbrales limites
    end
end
                  
s_a(N) = s_a(N-1);   % Add 1 extra point to aceleration signal to have same long than 's_v'.  


%--------------------------------------------------------------------
% Plot of signals
if f_plot
    figure(f_handle); hold on; grid on;
    xlabel('t [s]','FontSize',f_font);  ylabel('Surface velocity [m/s]','FontSize',f_font); 
    plot(t,s_v);  plot(t,s_v_fil,'b');  plot(t,s_v_fil,'g.');

    figure(f_handle+1); hold on; grid on; 
    xlabel('t [s]','FontSize',f_font);  ylabel('Surface aceleration [m/s^2]','FontSize',f_font); 
    plot(t,s_a);  plot(t,s_a,'r.');
end 

%1;



