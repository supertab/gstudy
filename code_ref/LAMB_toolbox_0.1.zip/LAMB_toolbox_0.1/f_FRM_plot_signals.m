function [Vs3_2] = f_FRM_plot_signals(Nxc3,Nyc3,X3,Y3,Z3,Vs3_2,Nt,N,fs,t,f_plot,f_handle)
% This function plots the array's sensor received received signals.
% Parameters:
%              Nxc3,Nyc3 = Number of receiver elements (X,Y) on reception aperture (array).
%               X3,Y3,Z3 = Coodinates of reception field (Array sensor points).
%                  Vs3_2 = Vs3_2(Nt,Nxc3,Nyc3,N3) Final (composed & converted) array signals.
%                     Nt = Number of incident angles. 
%                     N3 = Number of points of signals.
%                     fs = Sampling frequency [Hz].
%                      t = Time vector for signals [s].
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            � Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    07/01/2010



%-----------------------------------------------
% Plot final array signals if seleted. 
if f_plot
    figure(f_handle+323); hold on; grid on;
  f_quiet = 1;
       nc = 1;
      fs2 = 100*10^6; %50*10^6;
    delay = 0; %-50*10^-6
    level = 0.000414;
       t2 = (min(t):1/fs2:max(t))';
       N2 = max(size(t2));
    color = 'bgrcmk';
    fprintf(' Plotting received signals @fs = %.1f MHz\n',fs2/10^6);
    for k = 1:Nt
        M = max(max(max((Vs3_2(k,:,:,:)))));
        for i = 1:Nxc3
            for j = 1:Nyc3
                s(1,:) = Vs3_2(k,i,j,:);
                    s2 = f_resample_data(N,N2,fs,fs2,t,t2,s(:),f_quiet);
%                figure(f_handle+323);  plot(t,s + i*j*2*M,color(nc));  drawnow;
                figure(f_handle+323);  plot(t2+delay,s2 + i*j*2*M+level,color(nc));  drawnow;
                if i == 1 && j == 1
                    [mm,ii] = max(s2);  m = i*j*2*M+level;
                    text(t2(ii)+delay,m,[num2str([X3(i,j) Y3(i,j) Z3(i,j)]) ' m'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',14);    
                end
                if i == Nxc3 && j == 1
                    [mm,ii] = max(s2);  m = i*j*2*M+level;
                    text(t2(ii)+delay,m,[num2str([X3(i,j) Y3(i,j) Z3(i,j)]) ' m'],'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',14);    
                end
            end
        end
    end
    if nc < 6, nc = nc + 1;
    else       nc = 1;  end;
end
2;
