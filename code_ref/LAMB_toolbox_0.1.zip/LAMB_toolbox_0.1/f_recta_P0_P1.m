function [m,b,y_aux] = f_recta_P0_P1(O_ref,P0,P1,x_aux)
% Funcion que calcula una recta que pasa por 2 puntos dados:
% 'P0' y 'P1' referidos al sistema de coord. c/origen en 'O_ref'.
%
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  prego@eel.upc.edu
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    22/02/2009    


% Reference points to given Origin 'O'
   P0 = P0 - O_ref;
   P1 = P1 - O_ref;

    m = (P1(1,2)-P0(1,2))/(P1(1,1)-P0(1,1));
    b = P0(1,2) - m*P0(1,1);
y_aux = m*x_aux + b;

