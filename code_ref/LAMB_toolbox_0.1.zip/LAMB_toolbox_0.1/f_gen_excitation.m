function [Ps,p_flag] = f_gen_excitation(O,s_type,s_delay,n_burst,r_type,a_type,num_p,num_s,num_p_s,x,X,Y,x_w,y_w,c,theta,N,f0,f_min,f_max,fs,p_max,t,p_flag,q_flag)
% This function generates a finite plane wave (FPW) excitation field for a given incidence angle 'theta'.
% Parameters:
%            O  =  Central point of excitation field.
%       s_type  =  Signal type.
%       s_delay =  Initial commonn delay time for excitation signals [s].
%      n_burst  =  Number of cicles in burst-type signal (only used w/burst signals).
%       r_type  =  Region type.
%       a_type  =  Apodizing amplitude profile type. If  's_type = 0'  they don't apply.
%        num_p  =  Total number of points in excit field. 
%        num_s  =  Number of Y-strip lines in excit. field.
%      num_p_s  =  Number of 'points' by Y-strip line.
%        [X,Y]  =  Excitation field coordinates [m].
%          x_w  =  With of region in 'x' direction [m].
%          y_w  =  With of region in 'y' direction [m].
%            c  =  Velocity of acoustic signal eg. air @21�C: 343.81 [m/s].
%        theta  =  Excit. field incidence angle [Deg�].
%            N  =  Number of time points in signal trace.
%           f0  =  Signal's BW-central frequency [Hz].
%        f_min  =  Inferior BW-frequeny limit for integration [Hz].
%        f_max  =  Superior BW-freq. limit [Hz].         
%           fs  =  Sampling frequency [Hz].
%        p_max  =  Maximun excitation pressure [Pa].
%            t  =  Signal's temporal axis [s].
%       p_flag  =  Plotting flag.
%       q_flag  =  No-delay warning flag.
%
%
% Author:     Jose Luis Prego Borges (JLPB)
%            from Universitat Politecnica de Catalunya at Barcelona, Spain
%            email:  joseluis.jujuy@gmail.com
%            Copywrite:  JLPB & The Silicon-Cactus Corp.
%            :)
%
% ver 1.0    04/02/2008
% ver 2.0    07/02/2008     Time parameter added 4 interpolation of 'Ps' signals.
% ver 3.0    14/02/2008     Structure of function rebuilded.
% ver 3.1    14/04/2008     Added 'n_burst' parameter.
% ver 3.1.1  16/01/2009     Change in function name: 'f_gen_planewave' -> 'f_THS_gen_planewave'.
% ver 3.1.2  27/02/2009     's_delay' parameter added.


%------------------------------------------------------------------
% Construct PW main signal matrix.
[Ps_x] = f_THS_gen_planewave(c,theta,N,f0,f_min,f_max,fs,t,p_max,x,s_type,s_delay,n_burst,q_flag);

%------------------------------------------------------------------
% Convert X-line matrix 'Ps_x' to -> 'Ps' field excitation matrix.
% Where 'num_p' is the total number of 'points' in the excitation field.
if (x_w > 0) && (y_w > 0)
    %------------------------------------
    % Fill bidimensional excitation field.
    Ps = zeros(N,num_p);   
     n = 1;
    for i = 1:num_s
        index = num_p_s(i) + n - 1;
        for j = n:index
            Ps(:,j) = Ps_x(:,i);
        end
        n = index + 1;
    end     
else
    if y_w > 0 
        %------------------------------------
        % Fill 1D Y-line type excit. field.
           Ps = zeros(N,num_p);   
        for j = 1:num_p
            Ps(:,j) = Ps_x;
        end             
    else
        %------------------------------------
        % Fill 1D X-line type excit. field.
        Ps = Ps_x;
    end
end

%------------------------------------------------------------------
% If seleted, apodice field matrix 'Ps'.
if (num_p > 1) && (a_type ~= 0) && (s_type ~= 0) && (r_type ~= 0) && (x_w ~= 0)% <- Meaning: Apodice if not loading; and region isn't single 'point'.
    [Ps] = f_apodice_field(a_type,r_type,num_p,num_s,num_p_s,O,x_w,y_w,X,Y,Ps);
end
    
%----------------------------------------------
% Plotting of field signal's maximum.
if p_flag
    axis_font = 12;
    [Pm] = f_cal_Ps_max(0,Ps',0,0,12);
    figure(9991); hold on; grid; 
    view(0,0); % view([25 30]);
    plot3(X,Y,Pm,'b'); plot3(X,Y,Pm,'g.'); plot3(X(1),Y(1),Pm(1),'ro');
    xlabel('Number of excitation y-strip','FontSize',axis_font);
    zlabel('Y-strip maximum excitation pressure [Pa]','FontSize',axis_font);
    
    delay_type = 0 %2
    [Pd] = f_cal_Ps_delay(0,delay_type,N,fs,Ps',t,9992,0,0,12);
    figure(9992); hold on; grid;  
    view(0,0);  %view([25 30]);
    plot3(X,Y,Pd*10^6,'r'); plot3(X,Y,Pd*10^6,'b.'); plot3(X(1),Y(1),Pd(1)*10^6,'go');
    xlabel('Number of excitation y-strip','FontSize',axis_font);
    zlabel('Y-strip signal delay [us]','FontSize',axis_font);
        
    pause; delete(figure(9991)); delete(figure(9992));
    fprintf('(o_o) Warning: p_flag  now deactivated... \n')
end
p_flag = 0; % Ok! Show apodization profiles just one time :)




